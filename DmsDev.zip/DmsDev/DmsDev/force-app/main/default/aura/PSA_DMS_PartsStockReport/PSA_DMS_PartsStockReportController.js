({
	init: function (component, event, helper) {
         component.set("v.firstLoading",true);
        component.set('v.columns', [
            {label: 'Store Name', fieldName: 'storeName', type: 'text',initialWidth:110},
            {label: 'Store Code', fieldName: 'storeCode', type: 'text',initialWidth:110},
            {label: 'Part Number', fieldName: 'partNumber', type: 'text',initialWidth:120},
            {label: 'Part Description', fieldName: 'partDescription', type: 'text',initialWidth:140},
            {label: 'HSN', fieldName: 'HSN', type: 'text',initialWidth:80},
            {label: 'Active', fieldName: 'Active', type: 'text',initialWidth:70},
            {label: 'GST Tax Category', fieldName: 'gstTaxCategory', type: 'text', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Part Category', fieldName: 'partCategory', type: 'text',initialWidth:120},
            {label: 'OEM Part Identification', fieldName: 'OEMpartIdentification', type: 'text', cellAttributes: { alignment: 'center' },initialWidth:120},
            {label: 'NDP', fieldName: 'NDP', type: 'currency', cellAttributes: { alignment: 'center' }, sortable:true,initialWidth:120},
            {label: 'List Price', fieldName: 'sellingPrice', type: 'currency', cellAttributes: { alignment: 'center' },initialWidth:120},
            {label: 'MRP', fieldName: 'MRP', type: 'currency', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Open Quantity', fieldName: 'openQuantity', type: 'number', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Receipt Quantity', fieldName: 'receiptQuantity', type: 'number', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Invoiced Quantity', fieldName: 'invoicedQuantity', type: 'number', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Closing Quantity', fieldName: 'closingQuantity', type: 'number', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Opening Value', fieldName: 'openingValue', type: 'currency', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Receipt Value', fieldName: 'receiptValue', type: 'currency', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Issue Value', fieldName: 'issueValue', type: 'currency', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'Closing Value', fieldName: 'closingValue', type: 'currency', cellAttributes: { alignment: 'center' },initialWidth:100},
            {label: 'ABC Identification', fieldName: 'ABC', type: 'text', cellAttributes: { alignment: 'center' },initialWidth:120},
            {label: 'FMS Identification', fieldName: 'HML', type: 'text', cellAttributes: { alignment: 'center' },initialWidth:120},
            
        ]);
        helper.getSupplierlist(component, event,null);
            // helper.wrapperdataloading(component, event, helper);
    },
      next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var receiptslist = component.get("v.receipts");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var receiptslist = component.get("v.receipts");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
         /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var accountList = component.get("v.receipts");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.getSupplierlist(component, event,null);
    },
     downloadCsv : function(component,event,helper){  
         debugger;
        var stockData = component.get("v.orderwrapper"); 
        
        var csv = helper.convertArrayOfObjectsToCSV(component,stockData);   
        if (csv == null){return;} 
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_self'; // 
        hiddenElement.download = 'ExportData.csv';  
        document.body.appendChild(hiddenElement); 
        hiddenElement.click(); 
    },
     bookingdetailsearch: function(component, event, helper) {   
         debugger;
        console.log("" + event.getSource().get("v.value"));
        var searchkeyword = event.getSource().get("v.value") == undefined ? null : event.getSource().get("v.value");
        var selectedValue=component.get("v.selectedsearchfieldvalue");
        if(searchkeyword=="" ||searchkeyword==null ||searchkeyword=='undefined' && (selectedValue !='YTD' && selectedValue !='MTD'))
        {
          helper.getSupplierlist(component, event,null)         
        }
        else{
        helper.getSupplierlist(component, event,searchkeyword);	
        
        }
    },
   
        
})