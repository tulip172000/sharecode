({
    doInit : function(component, event, helper) {
        //debugger;
        var getElement = component.get('v.menuItem');     
        var validateMenuEvent = component.getEvent("validateMenu");
        var userM = component.get("v.userMenuAccess");
        for (var i = 0; i < userM.length; ++i) {
            if (getElement == userM[i].PSA_Community_Menu__c 
                && userM[i].PSA_Access__c == true) {
                component.set("v.condition", true);
                validateMenuEvent.setParams({ "validation": true, 
                                             "validationItem" : getElement,
                                             "defaultItem" : userM[i].PSA_Is_Default_Menu__c});
                validateMenuEvent.fire();
              }
        }
    }    
    /*
	doInit : function(component, event, helper) {
		var getElement = component.get('v.menuItem');     
        var validateMenuEvent = component.getEvent("validateMenu");
		var action = component.get("c.getUserMenuAccess");
        action.setCallback(this, function(response) {
            var state = response.getState();

            if (state === "SUCCESS") {
                var userResponse = response.getReturnValue();
                component.set("v.userMenuAccess", userResponse);
                var userM = component.get("v.userMenuAccess");
                
                for (var i = 0; i < userM.length; ++i) {
                    if (getElement == userM[i].PSA_Community_Menu__c 
                       && userM[i].PSA_Access__c == true) {
                        component.set("v.condition", true);
                        validateMenuEvent.setParams({ "validation": true, "validationItem" : getElement });
                        validateMenuEvent.fire();
                    }
                }
            }
        });
        $A.enqueueAction(action);
	},*/
})