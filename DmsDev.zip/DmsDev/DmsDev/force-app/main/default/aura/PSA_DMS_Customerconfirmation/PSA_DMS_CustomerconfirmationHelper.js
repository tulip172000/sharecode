({
	 validatePartForm : function(component, event, helper){
        debugger;
        var isValid = true;
		component.set("v.dateTimeErrmsg",'');
        $A.util.removeClass(startTime,"disp-block");
        $A.util.addClass(startTime,"disp-none");
	
    if(startTime =='--None--' || startTime == '' || startTime == null){
            component.set("v.dateTimeErrmsg",'This is a required field');
            $A.util.removeClass(startTime,"disp-none");
            $A.util.addClass(startTime,"disp-block");
            isValid = false;
        }
         return isValid;
     }
})