({
	doInit : function(component, event, helper) {
        //helper.Createpayment(component, event, helper);
		helper.paymentinfo(component, event); 
        helper.getpaymentmodevalues(component, event, helper);
        helper.getpaymentparticularvalues(component, event, helper);        
	},
    
    decreasebalance : function(component, event, helper) {
		var sellingprice = component.find("sellingprice").get("v.value");
		var amtrec = component.find("PayAmtid").get("v.value")
		var balamt = component.get("v.balanceamount");
		var balance;
        if(amtrec > balamt){
            helper.errortoast(component, event, helper, "Please enter only due amount!");
        }
        else{
            if(balamt == null || balamt == 0){
                balance = sellingprice - amtrec;
            }
            else{
                balance = balamt - amtrec;
            }
            var balamt = component.get("v.balanceamount");
            if(amtrec == "" && amtrec == undefined )
                component.find("balAmtid").set("v.value", balamt);
            else
                component.find("balAmtid").set("v.value", balance); 
        }
		   
	},        
    
    Savepayment:function(component,event,helper){
        var isvalid = true;
        var particular =  component.get("v.selectedparticular");
        var mode =  component.get("v.selectedmode");
        var amtrec = component.get("v.amountreceived");
        var balamt = component.get("v.balanceamount");
        var paydate = component.get("v.paymentdate");
        if(particular == "Select"){
            helper.errortoast(component, event, helper, 'Please select particular!');
            isvalid = false;
        }
        else if(mode == "Select"){
            helper.errortoast(component, event, helper, 'Please select mode of payment!');
            isvalid = false;
        }
        else if(amtrec == undefined || amtrec == "" || amtrec == null){
            helper.errortoast(component, event, helper, 'Please enter received amount!');
            isvalid = false;
        }
        else if(paydate == undefined || paydate == "" || paydate == null){
            helper.errortoast(component, event, helper, 'Please enter payment date!');
            isvalid = false;
        }
        
        if(isvalid){
            helper.saverequest(component, event, helper);
        }
    }
})