({
	getdeliverychecklist :function(component, event){
        var booknum=component.get("v.bookingorderid");
         var action = component.get("c.getchecklist");
           action.setParams({
            "booknum"	:booknum
        })
          action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                 if(storeResponse.length >0){
                console.log('dealer Info >>>>'+JSON.stringify(storeResponse));
                //component.set("v.supplierName1", storeResponse);
                 var accessory =storeResponse[0].PSA_Accessory_Fitment_Complete__c;
                var batt =storeResponse[0].PSA_Battery_Warranty_Card__c;
                var duplkey =storeResponse[0].PSA_Duplicate_Key__c;
                var triangle =storeResponse[0].PSA_Emergency_Reflector_Triangle__c;
                var firstaid =storeResponse[0].PSA_First_Aid_Kit__c;
                var gatepass =storeResponse[0].PSA_Gate_Pass__c;
                var insurance =storeResponse[0].PSA_Insurance_Cover_Note__c;
                var manual =storeResponse[0].PSA_Owners_Manual__c;
                var guide =storeResponse[0].PSA_Quick_Start_Guide__c;
                var challan =storeResponse[0].PSA_RTO_Challan__c;
                var saleLetter =storeResponse[0].PSA_Sale_Letter__c;
                var headlight =storeResponse[0].PSA_Spare_Headlight_Bulb__c;
                var wheel =storeResponse[0].PSA_Spare_Wheel__c;
                var toolkit =storeResponse[0].PSA_Tool_Kit__c;
                var vehfunc =storeResponse[0].PSA_Vehicle_Functionality_Explained__c;
                var saleinv =storeResponse[0].PSA_Vehicle_Sale_Invoice__c;
                var warrantyguide =storeResponse[0].PSA_Warranty_Info_Guide__c;
                var delchecklistrmks=storeResponse[0].PSA_DeliveryChecklistRemarks__c
                component.set("v.battery",batt);
                component.set("v.key",duplkey);
                component.set("v.Gatepass",gatepass);
                component.set("v.challan",challan);
                component.set("v.invoice",saleinv);
                component.set("v.letter",saleLetter);
                component.set("v.bulb",headlight);
                component.set("v.covernote",insurance);
                component.set("v.sparewheel",wheel);
                component.set("v.toolkit",toolkit);
                component.set("v.firstaid",firstaid);
                component.set("v.warrantyinfo",warrantyguide);
                component.set("v.quickstart",guide);
                component.set("v.ownermanual",manual);
                component.set("v.reflectortriangle",triangle);
                component.set("v.vehfunctionality",vehfunc);
                 component.set("v.accessory",accessory);
                  component.set("v.remark",delchecklistrmks);
                 }
                else{
                     component.set("v.disableSave",true);
                }
                
            }
        });
        $A.enqueueAction(action);
    },
     showSuccessToast : function(component, event, helper){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": "Delivery Checklist Successfully saved",
            "type": "success"
        });
        toastEvent.fire();  
    },
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid=component.get("v.bookingorderid");
         var action = component.get("c.checkDeliveryStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
               
                component.set("v.disableSave",true);
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
    
  MAX_FILE_SIZE: 4500000,
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    uploadHelper: function(component, event,parentid) {
        debugger;
        var fileInput = component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
        var objFileReader = new FileReader();
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
            self.uploadProcess(component, file, fileContents,parentid);
        });
        objFileReader.readAsDataURL(file);
    },
    checkfilesize: function(component, event) {
        var fileInput = component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }else{
            component.set('v.fileName',file.name);
        }
        var objFileReader = new FileReader();
        
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
        });
        
        objFileReader.readAsDataURL(file);
    },
    errorToast : function(component, event, Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": Message
        });
        toastEvent.fire();
    },
    uploadProcess: function(component, file, fileContents,parentid) {
        var startPosition = 0;
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '',parentid);
    },
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId,parentid) {
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.saveChunk");
        action.setParams({
            parentId: parentid,
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        action.setCallback(this, function(response) {
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state == "SUCCESS") {
                helper.showSuccessToast(component, event, helper);
            }
            
        });
        $A.enqueueAction(action);
    },
    fetchdocumenturl : function(component, event,helper) {
         var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.fetchdocumenturl");
        action.setParams({ 
            "bookingId" : bookingid
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state == "SUCCESS") {
                console.log('response.getReturnValue()'+response.getReturnValue());
                component.set('v.attachurl',storeResponse);
               
                var attachment= storeResponse;
               
                 var pdfurl ='../PSA_viewRcfile?Id='+attachment;
                 window.open(pdfurl,"_blank","width=600, height=550"); 
            }
        });
        $A.enqueueAction(action);
    },
   
})