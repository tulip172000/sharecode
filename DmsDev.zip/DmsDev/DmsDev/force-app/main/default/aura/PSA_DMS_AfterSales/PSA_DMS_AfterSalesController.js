({
	onTabSelect : function(component, event, helper) {
        debugger;
        component.set("v.repairOrderDetailView", false);
        component.set("v.BookingOrderDetailView", false);
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
    },
    
    handleBookingOrderIdPass : function(component, event, helper) {        
        var Id = event.getParam("currentMonthlyOrderIdoem");
        component.set("v.BookingorderId", Id);  
        component.set("v.BookingOrderDetailView", true);
    },
     handleFeedbackOrderIdPass : function(component, event, helper) { 
         component.set("v.currTab", 'repairOrder'); 
          component.set("v.repairOrderDetailView", true);
        var Id = event.getParam("Id");
        component.set("v.repairOrderId", Id); 
          var activate = component.find('repairOrder');
        var deactivate = component.find('feedback');
         $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
       
        
    },
    
    handleRepairOrderIdPass : function(component, event, helper) {
        debugger;
        var Id = event.getParam("Id");
        component.set("v.repairOrderId", Id);
        component.set("v.repairOrderDetailView", true);
        
    },
    LabourListView : function(component, event, helper) {
        component.set("v.Labourlist", true);
        var lmdvbool = event.getParam("listPage");
        component.set("v.LabourMasterDetailView", lmdvbool);
    },
        warrantyListView : function(component, event, helper) {
        component.set("v.Claimlist", true);
        var lmdvbool = event.getParam("listPage");
        component.set("v.ClaimStatusDetailView", lmdvbool);
    },
     handleLabourIdPass : function(component, event, helper) {    
        var Labid = event.getParam("LabourId");
        component.set("v.LabourMasterId", Labid);
        component.set("v.LabourMasterDetailView", true);
    },
      handleClaimStatusIdPass : function(component, event, helper) {    
        var Labid = event.getParam("LabourId");
        component.set("v.ClaimstatusId", Labid);
        component.set("v.ClaimStatusDetailView", true);
    },
     ROordersearch: function(component, event, helper) { 
        debugger;   
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
      //component.set("v.invoice",pot) ;
          if(pot == null || pot == 'undefined' || pot==""){
            var childCmp = component.find("repairordercomp");
            childCmp.getrepairorders();
        }
        else{               
        var action = component.get('c.searchroorders');
        action.setParams({          
            'ordernumber' : pot
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {               
                var records =response.getReturnValue();
                component.set("v.ROlist", records);   
            }
        });
        $A.enqueueAction(action);
            } 
    }, 
    
    repairsCount: function(component, event, helper){
        debugger;
          var rpcount = event.getParam("Id");
        component.set("v.RepairCount",rpcount);
    },
     handledisplayListPage : function(component, event, helper) {
         
        var listPage = event.getParam("listPage");
        
        if(listPage){
            component.set("v.repairOrderDetailView", false);
             
            
        }
    },
    handlevalidateMenu : function(component, event, helper) {
        debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
        	component.set("v.currTab", validationItem);            
        }
    },
    
    
})