({ 
    
    cancel : function(component, event, helper) {
        component.set("v.id", "");
        component.set("v.createGRN", false);
        component.set("v.vehicleGRN", false);
    },
    backtolist : function(component, event, helper) {
        
        var eventListPage = component.getEvent("vehiclerlistview");
        eventListPage.fire();
    },
    ClearErrmsg : function(component, event, helper) {
        var arrivaldatval = component.find("arrivaldate").get('v.value');
        if(arrivaldatval !=''){
              component.set("v.arrivalErrorMsg",'');
        }
    },
    opentechForm: function(component, event, helper) {
         component.set('v.subdisable',false);
        document.getElementById("myModal").style.display = "block";
        helper.createObjectData(component, event);
    },  
    CloseUploadFile: function(component, event, helper) {
        debugger;
       
        document.getElementById("myModal").style.display = "none";
        var childCmp = component.find("uplaodfileattach");
        if(childCmp.length)
            
            for(var i=0; i<childCmp.length; i++)
                childCmp[i].closevalue();
        else
            childCmp.closevalue(); 
        
         component.set('v.filessizetotal','0');
    },
    create : function(component, event, helper) {
        var arrivaldat = component.find("arrivaldate");
        var arrivaldatval = arrivaldat.get('v.value');
        var pod  = component.find("pod");
        var pod = pod.get('v.value');
        var validity = component.find("arrivaldate").get("v.validity");
        arrivaldat.reportValidity();
        if(validity.valid == true)
        {
            if(helper.validateArrivalDate(component)) {
                component.set("v.spinner", true);
                var action = component.get("c.createGRN");
                action.setParams({
                    "salesOrderObj" : component.get("v.selectedLookUpRecord"),
                    "vehObj" : component.get("v.vehicleReceiptRecord"),
                    "arrivalDate" : arrivaldatval,
                    "pod" :pod,
                    "vrid" :component.get("v.vehicleid"),
                  //  "cg" : v.selectedLookUpRecord[0].PSA_CGST__c
                    
                });
                
              // var cg =component.get("v.selectedLookUpRecord"); alert(cg[0].PSA_CGST__c);
                action.setCallback(this, function(response){
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        var value = response.getReturnValue();
                        var msg = $A.get("$Label.c.Vehicle_GRN_Create_Success");
                        helper.successToast(component, event, helper, msg);
                        //  component.set("v.id", "");
                        component.set("v.createGRN", false);
                        //  component.set("v.vehicleGRN", false);
                        component.set("v.GRNnumber", value.PSA_GRN_number__c);
                        component.set("v.spinner", false);
                        component.find("arrivaldate").set('v.value', arrivaldatval);
                        component.find("arrivaldate").set("v.disabled",true);
                         component.find("pod").set('v.value', pod);
                        component.find("pod").set("v.disabled",true);
                          component.set("v.allocated", true);
                    }else{
                        var msg = $A.get("$Label.c.Vehicle_GRN_Create_Error");
                        helper.errorToast(component, event, helper, msg);
                        component.set("v.spinner", false);
                    }
                });
                $A.enqueueAction(action);
            }
            
        }else{
            var msg = $A.get("$Label.c.Vehicle_GRN_Fill_Arrival_Date_Error");
            helper.errorToast(component, event, helper, msg);
        }
    },
    
    save : function(component, event, helper) {
        component.set("v.spinner", true);
        var action = component.get("c.updateGRN");
        action.setParams({
            "vehObj" : component.get("v.vehicleReceiptRecord")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var msg = $A.get("$Label.c.Vehicle_GRN_Update_Success");
                helper.successToast(component, event, helper, msg);
                component.set("v.id", "");
                component.set("v.createGRN", false);
                component.set("v.vehicleGRN", false);
                component.set("v.spinner", false);
              
            }else{
                var msg = $A.get("$Label.c.Vehicle_GRN_Update_Error");
                helper.errorToast(component, event, helper, msg);
                component.set("v.spinner", false);
            }
        });
        $A.enqueueAction(action);
    },
    
    doInit : function(component, event, helper) {
        
        component.set("v.GRNDate", new Date());
        //  helper.createObjectData(component, event);
        if(component.get("v.id"))
        {
            var action = component.get("c.loadVehilceReceipt");
            action.setParams({
                "id" : component.get("v.id")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var value = response.getReturnValue();
                    component.set("v.selectedLookUpRecord", value);
                     //component.set("v.selectedLookUpRecord1", value.VehicleReciept__r);
                   // var x=value[0].VehicleReciept__r;
                
                    if(value)
                        component.set("v.vehicleReceiptRecord", value.VehicleReciept__r[0]);
                }
            });
            $A.enqueueAction(action);
        }
        
    },
    
    damageChange : function(component, event, helper) {
        if(!component.get("v.vehicleReceiptRecord.PSA_Report_Damage__c"))
        {
            component.set("v.vehicleReceiptRecord.PSA_Report_Damage_Reason__c", null);
            component.set("v.vehicleReceiptRecord.PSA_Report_Damage_Decription__c", null);
        }
    },
    shortageChange : function(component, event, helper) {
        if(!component.get("v.vehicleReceiptRecord.PSA_Report_Shortage__c"))
        {
            component.set("v.vehicleReceiptRecord.PSA_Report_Shortage_Reason__c", null);
            component.set("v.vehicleReceiptRecord.PSA_Report_Shortage_Description__c", null);
        }
    },
    addNewRow : function(component, event, helper) {
        helper.createObjectData(component, event);
    },
      errorsave : function(component, event, helper) {
          component.set('v.fileserror',true);
          component.set('v.filescheck',false);
    },
    removeDeletedRow: function(component, event, helper) {
        var index = event.getParam("indexVar");
        var filesize = event.getParam("deleteAmount");
        var AllRowsList = component.get("v.PartsSelListEdit");
        AllRowsList.splice(index, 1);
        component.set("v.PartsSelListEdit", AllRowsList);
        var totalsize=  component.get("v.filessizetotal");
        var FinalAmt = 0;
        if(totalsize>0)
        FinalAmt= parseInt(totalsize) - parseInt(filesize);
        component.set('v.filessizetotal',FinalAmt);
         component.set('v.fileserror',false);
         component.set('v.filescheck',true);
    },
    totalfizemethod: function(component, event, helper) {
        var filesize = event.getParam("OrderAmountcurr");
        var totalsize=  component.get("v.filessizetotal");
        var FinalAmt = parseInt(filesize) + parseInt(totalsize);
        component.set('v.filessizetotal',FinalAmt);
        component.set('v.filescheck',true);
        component.set('v.fileserror',false);
        
    },
    createUpload : function(component, event, helper) {
        debugger;
        var childCmp = component.find("uplaodfileattach");
        if(childCmp.length)
            for(var i=0; i<childCmp.length; i++)
                childCmp[i].checkValidation();
        else
            childCmp.checkValidation();

        var totalsize=  component.get("v.filessizetotal");
        if(totalsize>20000000){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "Error",
                "message": 'Total Files Size exceed 20 MB',
            });
            toastEvent.fire();
        }else{
            var isvalid=component.get('v.filescheck');
        }
        
        if(isvalid)
        {   
            component.set('v.filessizetotal','0');
             component.set('v.subdisable',true);
            helper.createfiles(component, event);  
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "Success",
                "message": 'files uploaded Successfully',
            });
            toastEvent.fire();
        }
        var errordisplay= component.get('v.fileserror');
        if(errordisplay)
        { 
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "Error",
                "message": 'Please attach files in all rows',
            });
            toastEvent.fire();
        }
        
    }
})