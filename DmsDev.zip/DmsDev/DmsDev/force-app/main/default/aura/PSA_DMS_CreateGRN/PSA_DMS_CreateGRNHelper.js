({
	successToast : function(component, event, helper, msg) {
		var toastEvent = $A.get("e.force:showToast");
    toastEvent.setParams({
        "type": "success",
        "message": msg
    });
    toastEvent.fire();
	},
     validateArrivalDate : function(component, event, helper) {
         debugger;
      var isarrivalvalid =true;    
      var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
    var RowItemList = component.get("v.selectedLookUpRecord");
      var invdate=  RowItemList.PSA_Invoice_Date__c;
  
      var arrivaldatval = component.find("arrivaldate").get('v.value');
      var grndatevalfmt = component.find("grndate").get('v.value');
      var grndateval = ($A.localizationService.formatDate(grndatevalfmt, "YYYY-MM-DD"));
         component.set("v.arrivalErrorMsg",'');
        $A.util.removeClass(arrivaldatval,"disp-block");
        $A.util.addClass(arrivaldatval,"disp-none");
         if((arrivaldatval > today)){
             isarrivalvalid= false;
              component.set("v.arrivalErrorMsg",'Arrival date should not be future date.');
            $A.util.removeClass(arrivaldatval,"disp-none");
            $A.util.addClass(arrivaldatval,"disp-block");
            var msg = $A.get("$Label.c.Vehicle_GRN_Future_Arrival_Date_Error");
              this.errorToast(component, event, helper, msg);
         }if(arrivaldatval < invdate){
             isarrivalvalid= false;
              component.set("v.arrivalErrorMsg",'Arrival date should not less than invoice date.');
           
         }
         if(arrivaldatval == ''|| arrivaldatval =='undefined' || arrivaldatval == null){
              isarrivalvalid= false;
               component.set("v.arrivalErrorMsg",'Please select arrival date.');
         }
         return isarrivalvalid;
        
     },
    
    errorToast : function(component, event, helper, msg) {
		var toastEvent = $A.get("e.force:showToast");
    toastEvent.setParams({
        "type": "error",
        "message": msg
    });
    toastEvent.fire();
	},
    createObjectData: function(component, event) {
        var RowItemList = component.get("v.PartsSelListEdit");
        RowItemList.push({
            'sobjectType ': 'Attachment',
            'Body':''
        });
        component.set("v.PartsSelListEdit", RowItemList);
        
    },
    createfiles: function(component, event) {
       
       var childCmp22 = component.find("uplaodfileattach");
       if(childCmp22.length)
            for(var i=0; i<childCmp22.length; i++)
                childCmp22[i].savefiles();
        else
            childCmp22.savefiles();
    },
     closeform: function(component, event) {
       var childCmp33 = component.find("uplaodfileattach");
       if(childCmp33.length)
            for(var i=0; i<childCmp22.length; i++)
                childCmp22[i].closevalue();
        else
            childCmp33.closevalue();
    },
})