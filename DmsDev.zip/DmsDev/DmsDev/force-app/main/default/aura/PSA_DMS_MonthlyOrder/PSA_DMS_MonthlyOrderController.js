({
    doInit : function(component, event, helper) {
     //   component.set("v.spinner", true);
        var forecastTimeline = parseInt($A.get("$Label.c.MonthlyOrder_Forecast_timeline"));
        var submitTimeline = parseInt($A.get("$Label.c.MonthlyOrder_Submit_timeline"));
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        var today = new Date();
      //  var submitDay = new Date();
        today.setDate(today.getDate() + forecastTimeline);
        var month = today.getMonth();
        var monthName = months[month];
        var year = today.getFullYear();
     //   submitDay.setDate(submitDay.getDate() + submitTimeline);
      //  if(submitDay.getMonth() != today.getMonth())
      //      component.set("v.submitDisable", true);
        component.set("v.month", month);
        var findMonth = component.find(month);
        $A.util.removeClass(findMonth, 'disable');
        $A.util.addClass(findMonth, 'activetab'); 
        component.set("v.year", year);
        var halfyear = year.toString();
        component.set("v.halfyear", halfyear.slice(2));
        component.set("v.monthName", monthName);
        component.set("v.monthNameHalf", monthName.slice(0,3));
        if(today.getDate() > 27)
        today.setDate(today.getDate() - 3);
        var f1 = today;
        f1.setMonth(f1.getMonth() + 1);
        var fmonth1 = f1.getMonth();
        var fyear1 = f1.getFullYear();
        fyear1 = fyear1.toString();
        var fmonthfull1 = months[fmonth1];
        
        var f2 = today;
        f2.setMonth(f2.getMonth() + 1);
        var fmonth2 = f2.getMonth();
        var fyear2 = f2.getFullYear();
        fyear2 = fyear2.toString();
        var fmonthfull2 = months[fmonth2];
        
        var f3 = today;
        f3.setMonth(f3.getMonth() + 1);
        var fmonth3 = f3.getMonth();
        var fyear3 = f3.getFullYear();
        fyear3 = fyear3.toString();
        var fmonthfull3 = months[fmonth3];
        
        var f4 = today;
        f4.setMonth(f4.getMonth() + 1);
        var fmonth4 = f4.getMonth();
        var fyear4 = f4.getFullYear();
        fyear4 = fyear4.toString();
        var fmonthfull4 = months[fmonth4];
        
        var f5 = today;
        f5.setMonth(f5.getMonth() + 1);
        var fmonth5 = f5.getMonth();
        var fyear5 = f5.getFullYear();
        fyear5 = fyear5.toString();
        var fmonthfull5 = months[fmonth5];
        
        var f6 = today;
        f6.setMonth(f6.getMonth() + 1);
        var fmonth6 = f6.getMonth();
        var fyear6 = f6.getFullYear();
        fyear6 = fyear6.toString();
        var fmonthfull6 = months[fmonth6];
        
        component.set("v.fMonth1", fmonthfull1);
        component.set("v.fMonth2", fmonthfull2);
        component.set("v.fMonth3", fmonthfull3);
        component.set("v.fMonth4", fmonthfull4);
        component.set("v.fMonth5", fmonthfull5);
        component.set("v.fMonth6", fmonthfull6);
        component.set("v.fMonthhalf1", fmonthfull1.slice(0,3));
        component.set("v.fMonthhalf2", fmonthfull2.slice(0,3));
        component.set("v.fMonthhalf3", fmonthfull3.slice(0,3));
        component.set("v.fMonthhalf4", fmonthfull4.slice(0,3));
        component.set("v.fMonthhalf5", fmonthfull5.slice(0,3));
        component.set("v.fMonthhalf6", fmonthfull6.slice(0,3));
        component.set("v.fyear1", fyear1);
        component.set("v.fyear2", fyear2);
        component.set("v.fyear3", fyear3);
        component.set("v.fyear4", fyear4);
        component.set("v.fyear5", fyear5);
        component.set("v.fyear6", fyear6);
        component.set("v.fyearhalf1", fyear1.slice(2));
        component.set("v.fyearhalf2", fyear2.slice(2));
        component.set("v.fyearhalf3", fyear3.slice(2));
        component.set("v.fyearhalf4", fyear4.slice(2));
        component.set("v.fyearhalf5", fyear5.slice(2));
        component.set("v.fyearhalf6", fyear6.slice(2));
        console.log('yoyo1');
        helper.getItemProducts(component, event, helper);
        helper.getForecast1(component, event, helper);
        helper.getFirmOrder(component, event, monthName);
        helper.getDemoProducts(component, event, helper);
        helper.getDealerobjective(component, event, helper);
        helper.getVariantList(component, event, helper);
    },
    
    handleAddDeleteRowsDemo : function(component, event, helper) {
        
        var addDelete = event.getParam("addDelete");
        var rowNumber = event.getParam("rowNumber");
        var demoItems = component.get("v.demoItems");
            if(addDelete == "add")
            {
                demoItems.push({
                    'sobjectType': 'OrderItem',
                    'Product2.PSA_Brand__c': '',
                    'Product2.PSA_Variant__c': '',
                    'Product2.PSA_Ext_Colour__c': '',
                    'Product2.Exterior_Color__c': '',
                    'Product2.Interior_Color__c': '',
                    'Product2.Metallic_Non_Metallic__c':''
                    
                });
            }else if(addDelete == "del")
            {
                demoItems.splice(rowNumber, 1);
            }
        component.set("v.demoItems", demoItems);
    },
    
    handleAddDeleteRows : function(component, event, helper) {
        var brand = event.getParam("brand");
        var addDelete = event.getParam("addDelete");
        var rowNumber = event.getParam("rowNumber");
        var productId = event.getParam("productId");
        var productList = component.get("v.productList");
        var quantityList = component.get("v.quantityList");
        var f1quantityList = component.get("v.f1quantityList");
        var f2quantityList = component.get("v.f2quantityList");
        var f3quantityList = component.get("v.f3quantityList");
        var f4quantityList = component.get("v.f4quantityList");
        var f5quantityList = component.get("v.f5quantityList");
        var f6quantityList = component.get("v.f6quantityList");
        
        if(addDelete == "del")
            if(typeof productId !== 'undefined' && productId != "")
            {
                var index = productList.indexOf(productId);
                productList.splice(index,1);
                quantityList.splice(index,1);
                f1quantityList.splice(index,1);
                f2quantityList.splice(index,1);
                f3quantityList.splice(index,1);
                f4quantityList.splice(index,1);
                f5quantityList.splice(index,1);
                f6quantityList.splice(index,1);
            }
        
        if(brand == component.get("v.model1"))
        {
            var CitreonSE21ItemList = component.get("v.CitreonSE21ItemList");
            if(addDelete == "add")
            {
                CitreonSE21ItemList.push({
                    'sobjectType': 'OrderItem',
                    'Product2.PSA_Brand__c': component.get("v.model1"),
                    'Product2.PSA_Variant__c': '',
                    'Product2.PSA_Ext_Colour__c': '',
                    'Product2.Exterior_Color__c': '',
                    'Product2.Interior_Color__c': '',
                    'Product2.Metallic_Non_Metallic__c':'',
                    'Product2.Interior_Trim_Type__c':'',
                    'Product2.Roof__c':'',
                    'Product2.Pack__c':''                    
                });
            }else if(addDelete == "del")
            {
                CitreonSE21ItemList.splice(rowNumber, 1);
            }
            component.set("v.CitreonSE21ItemList", CitreonSE21ItemList);
        }else if(brand == component.get("v.model2")){
            var CitreonC84ItemList = component.get("v.CitreonC84ItemList");
            if(addDelete == "add")
            {
                CitreonC84ItemList.push({
                    'sobjectType': 'OrderItem',
                    'Product2.PSA_Brand__c': component.get("v.model2"),
                    'Product2.PSA_Variant__c': '',
                    'Product2.PSA_Ext_Colour__c': '',
                    'Product2.Exterior_Color__c': '',
                    'Product2.Interior_Color__c': '',
                    'Product2.Metallic_Non_Metallic__c':'',
                    'Product2.Interior_Trim_Type__c':'',
                    'Product2.Roof__c':'',
                    'Product2.Pack__c':''                      
                });
            }else if(addDelete == "del")
            {
                CitreonC84ItemList.splice(rowNumber, 1);
            }
            component.set("v.CitreonC84ItemList", CitreonC84ItemList);
            
            
        }
        
        helper.triggerChart(component, event, helper);
        
    },
    
    
    saveOrder : function(component, event, helper) {
        helper.saveOrderHelper(component, event, helper, "save");
    },
    
    submitOrder : function(component, event, helper) {
        component.set("v.spinner", true);
        var OrderId = component.get("v.OrderId");
        var action = component.get("c.submitFirmOrder");
        action.setParams({
            "OrderId": OrderId,
            "sc21Target":component.get("v.delearobjective.sc21total"),
            "c84Target":component.get("v.delearobjective.C84total")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.OrderId", value.Id);
                component.set("v.OrderStatus", value.Status);
                var msg = $A.get("$Label.c.MonthlyOrder_Submit_Success");
                helper.showSuccess(component, event, helper, msg);
                component.set("v.spinner", false);
                
            }else{
                var msg = $A.get("$Label.c.MonthlyOrder_Submit_Error");
                helper.showError(component, event, helper, msg);
                component.set("v.spinner", false);
            }
        });
        $A.enqueueAction(action);
    },
    
    handleAddProducts : function(component, event, helper) {
        var productId = event.getParam("productId");
        var orderItemQuantity = event.getParam("orderItemQuantity");
        var f1Quantity = event.getParam("f1Quantity");
        var f2Quantity = event.getParam("f2Quantity");
        var f3Quantity = event.getParam("f3Quantity");
        var f4Quantity = event.getParam("f4Quantity");
        var f5Quantity = event.getParam("f5Quantity");
        var f6Quantity = event.getParam("f6Quantity");
        var productList = component.get("v.productList");
        var quantityList = component.get("v.quantityList");
        var f1quantityList = component.get("v.f1quantityList");
        var f2quantityList = component.get("v.f2quantityList");
        var f3quantityList = component.get("v.f3quantityList");
        var f4quantityList = component.get("v.f4quantityList");
        var f5quantityList = component.get("v.f5quantityList");
        var f6quantityList = component.get("v.f6quantityList");
        
        var index = productList.indexOf(productId);
        if(index == -1)
        {
            productList.push(productId);
            quantityList.push(orderItemQuantity);
            f1quantityList.push(f1Quantity);
            f2quantityList.push(f2Quantity);
            f3quantityList.push(f3Quantity);
            f4quantityList.push(f4Quantity);
            f5quantityList.push(f5Quantity);
            f6quantityList.push(f6Quantity);
            component.set("v.productList", productList);
        }else{
            quantityList.splice(index,1,orderItemQuantity);
            f1quantityList.splice(index,1,f1Quantity);
            f2quantityList.splice(index,1,f2Quantity);
            f3quantityList.splice(index,1,f3Quantity);
            f4quantityList.splice(index,1,f4Quantity);
            f5quantityList.splice(index,1,f5Quantity);
            f6quantityList.splice(index,1,f6Quantity);
        }
        
        component.set("v.quantityList", quantityList);
        component.set("v.f1quantityList", f1quantityList);
        component.set("v.f2quantityList", f2quantityList);
        component.set("v.f3quantityList", f3quantityList);
        component.set("v.f4quantityList", f4quantityList);
        component.set("v.f5quantityList", f5quantityList);
        component.set("v.f6quantityList", f6quantityList);
        
        helper.triggerChart(component, event, helper);
    },
    
    handleremoveProducts : function(component, event, helper) {
        var productId = event.getParam("productId");
        var productList = component.get("v.productList");
        var quantityList = component.get("v.quantityList");
        var f1quantityList = component.get("v.f1quantityList");
        var f2quantityList = component.get("v.f2quantityList");
        var f3quantityList = component.get("v.f3quantityList");
        var f4quantityList = component.get("v.f4quantityList");
        var f5quantityList = component.get("v.f5quantityList");
        var f6quantityList = component.get("v.f6quantityList");
        
        var index = productList.indexOf(productId);
        if(index != -1)
        {
            productList.splice(index,1);
            quantityList.splice(index,1);
            f1quantityList.splice(index,1);
            f2quantityList.splice(index,1);
            f3quantityList.splice(index,1);
            f4quantityList.splice(index,1);
            f5quantityList.splice(index,1);
            f6quantityList.splice(index,1);
            component.set("v.productList", productList);
            component.set("v.quantityList", quantityList);
            component.set("v.f1quantityList", f1quantityList);
            component.set("v.f2quantityList", f2quantityList);
            component.set("v.f3quantityList", f3quantityList);
            component.set("v.f4quantityList", f4quantityList);
            component.set("v.f5quantityList", f5quantityList);
            component.set("v.f6quantityList", f6quantityList);
        }
        
        helper.triggerChart(component, event, helper);
        
    },
    
    changeSE21Div : function(component, event, helper) {
        if(!component.get("v.CitreonSE21Div"))
        {
            component.set("v.CitreonC84Div", false);
            component.set("v.CitreonSE21Div", true);
            component.set("v.carType", component.get("v.model1"));
        }else
        {
            component.set("v.CitreonSE21Div", false);
        }
    },
    
    changeC84Div : function(component, event, helper) {
        if(!component.get("v.CitreonC84Div"))
        {
            component.set("v.CitreonSE21Div", false);
            component.set("v.CitreonC84Div", true);
            component.set("v.carType", component.get("v.model2"));
        }else
        {
            component.set("v.CitreonC84Div", false);
        }
    },
    
    sendForReview : function(component, event, helper) {
        helper.saveOrderHelper(component, event, helper, "review");
    },
    
    
    openDemoVehicle : function(component, event, helper) {
        var qtyListDemo = [];
        var qty = 0;
        var quantityList = component.get("v.quantityList");
        if(typeof quantityList !== 'undefined' && quantityList.length > 0)
            for(var i=0; i<quantityList.length; i++)
                qty = qty+quantityList[i];
        qtyListDemo.push(qty);
        for(var i=1; i<7; i++)
        {	var qty = 0;
            var fq = "v.f"+i+"quantityList";
            var quantityList = component.get(fq);
            if(typeof quantityList !== 'undefined' && quantityList.length > 0)
                for(var j=0; j<quantityList.length; j++)
                {
                    qty = qty+quantityList[j];
            		qtyListDemo.push(qty);
                }
        }
        component.set("v.qtyListDemo", qtyListDemo);
        component.set("v.demoPopup", true);
        var modal = document.getElementById('myModal'); 
        modal.style.display = "block"; 
    },
    closeDemoVehicle : function(component, event, helper) {
        var modal = document.getElementById('myModal'); 
        modal.style.display = "none"; 
        component.set("v.demoPopup", false);
        component.set("v.spinner", true);
        helper.getForecast1(component, event, helper);
        helper.getDemoProducts(component, event, helper);
    },
    AddDemoItems : function(component, event, helper) {
        helper.saveOrderHelper(component, event, helper, "save");
        var modal = document.getElementById('myModal'); 
        modal.style.display = "none"; 
        component.set("v.demoPopup", false);
    },
})