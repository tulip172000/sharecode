({
    getDemoProducts : function(component, event, helper) {
        var months1 = [];
        var months2 = [];
        var year1 = component.get("v.year");
        var year2 = year1+1;
        months1.push(component.get("v.monthName"));
        var orderTypes = [];
        var demoItems = [];
        var SE21demoItems = [];
        var C84demoItems = [];
        for(var i=1; i<7; i++)
        {
            var year = "v.fyear"+i;
            var month = "v.fMonth"+i;
            if(component.get(year) == year1)
                months1.push(component.get(month));
            else
                months2.push(component.get(month));
        }   
        var action = component.get("c.getDemoItemProducts");
        action.setParams({
            "months1": months1,
            "months2": months2,
            "year1": year1,
            "year2": year2
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                
                component.set("v.demoProductsItem", value);
                for(var key in value)
                {
                    orderTypes.push(key);
                    var items = value[key].itemList;
                    if(typeof items != 'undefined' && items != null)
                        for(var i=0; i<items.length; i++)
                        {console.log(items[i].Product2.PSA_Brand__c);
                            if(items[i].Product2.PSA_Brand__c == component.get("v.model2"))
                            {
                                C84demoItems.push(items[i]);
                                demoItems.push(items[i]);
                            }
                            else if(items[i].Product2.PSA_Brand__c == component.get("v.model1"))
                            {
                                SE21demoItems.push(items[i]);
                                demoItems.push(items[i]);
                            }
                        }
                }
                
                if(demoItems == "")
                {
                    demoItems.push({
                        'sobjectType': 'orderItem',
                        'Product2.PSA_Variant__c': '',
                        'Product2.PSA_Ext_Colour__c': '',
                        'Product2.Exterior_Color__c': '',
                        'Product2.Interior_Color__c': '',
                        'Product2.Metallic_Non_Metallic__c':''
                        
                    });
                }
                component.set("v.C84demoItems", C84demoItems);
                component.set("v.SE21demoItems", SE21demoItems);
                component.set("v.demoItems", demoItems);
                component.set("v.orderTypes", orderTypes);
                
                
            }
            component.set("v.spinner", false);
        });
        $A.enqueueAction(action);
    },
    
    
    getItemProducts : function(component, event, helper) {
        console.log('yoyo2');
        var months1 = [];
        var months2 = [];
        var year1 = component.get("v.year");
        var year2 = year1+1;
        months1.push(component.get("v.monthName"));
        
        for(var i=1; i<7; i++)
        {
            var year = "v.fyear"+i;
            var month = "v.fMonth"+i;
            if(component.get(year) == year1)
                months1.push(component.get(month));
            else
                months2.push(component.get(month));
        }   
        var action = component.get("c.getLineItemProducts");
        action.setParams({
            "months1": months1,
            "months2": months2,
            "year1": year1,
            "year2": year2
        });console.log('yoyo3');
        action.setCallback(this, function(response){console.log('yoyo4');
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                if(value == null)
                {
                    var CitreonSE21ItemList = component.get("v.CitreonSE21ItemList");
                    CitreonSE21ItemList.push({
                        'sobjectType': 'orderItem',
                        'Product2.PSA_Variant__c': '',
                        'Product2.PSA_Ext_Colour__c': '',
                        'Product2.Exterior_Color__c': '',
                        'Product2.Interior_Color__c': '',
                        'Product2.Metallic_Non_Metallic__c':'',
                        'Product2.Interior_Trim_Type__c':'',
                        'Product2.Roof__c':'',
                        'Product2.Pack__c':''                            
                    });
                    var CitreonC84ItemList = component.get("v.CitreonC84ItemList");
                    CitreonC84ItemList.push({
                        'sobjectType': 'orderItem',
                        'Product2.PSA_Variant__c': '',
                        'Product2.PSA_Ext_Colour__c': '',
                        'Product2.Exterior_Color__c': '',
                        'Product2.Interior_Color__c': '',
                        'Product2.Metallic_Non_Metallic__c':'',
                        'Product2.Interior_Trim_Type__c':'',
                        'Product2.Roof__c':'',
                        'Product2.Pack__c':''                            
                    }); 
                    component.set("v.CitreonSE21ItemList", CitreonSE21ItemList);
                    component.set("v.CitreonC84ItemList", CitreonC84ItemList);
                }
                else
                {
                    var CitreonSE21ItemList = [];
                    var CitreonC84ItemList = [];
                    var productList = [];
                    var items = value;
                    for(var i=0; i<items.length; i++)
                    {
                        productList.push(items[i].Product2.Id);
                        if(items[i].Product2.PSA_Brand__c == component.get("v.model2"))
                            CitreonC84ItemList.push(items[i]);
                        else if(items[i].Product2.PSA_Brand__c == component.get("v.model1"))
                            CitreonSE21ItemList.push(items[i]);
                    }
                    component.set("v.productList", productList);
                    if(typeof CitreonSE21ItemList !== 'undefined' && CitreonSE21ItemList.length > 0)
                        component.set("v.CitreonSE21ItemList",CitreonSE21ItemList);
                    else{
                        var CitreonSE21ItemList = component.get("v.CitreonSE21ItemList");
                        CitreonSE21ItemList.push({
                            'sobjectType': 'orderItem',
                            'Product2.PSA_Variant__c': '',
                            'Product2.PSA_Ext_Colour__c': '',
                            'Product2.Exterior_Color__c': '',
                            'Product2.Interior_Color__c': '',
                            'Product2.Metallic_Non_Metallic__c':'',
                            'Product2.Interior_Trim_Type__c':'',
                            'Product2.Roof__c':'',
                            'Product2.Pack__c':''                                
                        });
                        component.set("v.CitreonSE21ItemList", CitreonSE21ItemList);
                    }
                    if(typeof CitreonC84ItemList !== 'undefined' && CitreonC84ItemList.length > 0)
                        component.set("v.CitreonC84ItemList",CitreonC84ItemList);
                    else{
                        var CitreonC84ItemList = component.get("v.CitreonC84ItemList");
                        CitreonC84ItemList.push({
                            'sobjectType': 'orderItem',
                            'Product2.PSA_Variant__c': '',
                            'Product2.PSA_Ext_Colour__c': '',
                            'Product2.Exterior_Color__c': '',
                            'Product2.Interior_Color__c': '',
                            'Product2.Metallic_Non_Metallic__c':'',
                            'Product2.Interior_Trim_Type__c':'',
                            'Product2.Roof__c':'',
                            'Product2.Pack__c':''                                
                        });
                        component.set("v.CitreonC84ItemList", CitreonC84ItemList);
                    }
                }
            }
        });console.log('yoyo5');
        $A.enqueueAction(action); console.log('yoyo6');
    },
    
    getItemProducts2 : function(component, event, helper) {
        var months1 = [];
        var months2 = [];
        var year1 = component.get("v.year");
        var year2 = year1+1;
        months1.push(component.get("v.monthName"));
        
        for(var i=1; i<7; i++)
        {
            var year = "v.fyear"+i;
            var month = "v.fMonth"+i;
            if(component.get(year) == year1)
                months1.push(component.get(month));
            else
                months2.push(component.get(month));
        }   
        var action = component.get("c.getLineItemProducts");
        action.setParams({
            "months1": months1,
            "months2": months2,
            "year1": year1,
            "year2": year2
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                if(value == null)
                {
                    var CitreonSE21ItemList = component.get("v.CitreonSE21ItemList");
                    CitreonSE21ItemList.push({
                        'sobjectType': 'orderItem',
                        'Product2.PSA_Variant__c': '',
                        'Product2.PSA_Ext_Colour__c': '',
                        'Product2.Exterior_Color__c': '',
                        'Product2.Interior_Color__c': '',
                        'Product2.Metallic_Non_Metallic__c':'',
                        'Product2.Interior_Trim_Type__c':'',
                        'Product2.Roof__c':'',
                        'Product2.Pack__c':''                            
                    });
                    var CitreonC84ItemList = component.get("v.CitreonC84ItemList");
                    CitreonC84ItemList.push({
                        'sobjectType': 'orderItem',
                        'Product2.PSA_Variant__c': '',
                        'Product2.PSA_Ext_Colour__c': '',
                        'Product2.Exterior_Color__c': '',
                        'Product2.Interior_Color__c': '',
                        'Product2.Metallic_Non_Metallic__c':'',
                        'Product2.Interior_Trim_Type__c':'',
                        'Product2.Roof__c':'',
                        'Product2.Pack__c':''                            
                    }); 
                    component.set("v.CitreonSE21ItemList", CitreonSE21ItemList);
                    component.set("v.CitreonC84ItemList", CitreonC84ItemList);
                }
                else
                {
                    var CitreonSE21ItemList = [];
                    var CitreonC84ItemList = [];
                    var productList = [];
                    var items = value;
                    for(var i=0; i<items.length; i++)
                    {
                       // productList.push(items[i].Product2.Id);
                        if(items[i].Product2.PSA_Brand__c == component.get("v.model2"))
                            CitreonC84ItemList.push(items[i]);
                        else if(items[i].Product2.PSA_Brand__c == component.get("v.model1"))
                            CitreonSE21ItemList.push(items[i]);
                    }
                   // component.set("v.productList", productList);
                    if(typeof CitreonSE21ItemList !== 'undefined' && CitreonSE21ItemList.length > 0)
                        component.set("v.CitreonSE21ItemList",CitreonSE21ItemList);
                    else{
                        var CitreonSE21ItemList = [];
                        CitreonSE21ItemList.push({
                            'sobjectType': 'orderItem',
                            'Product2.PSA_Variant__c': '',
                            'Product2.PSA_Ext_Colour__c': '',
                            'Product2.Exterior_Color__c': '',
                            'Product2.Interior_Color__c': '',
                            'Product2.Metallic_Non_Metallic__c':'',
                            'Product2.Interior_Trim_Type__c':'',
                            'Product2.Roof__c':'',
                            'Product2.Pack__c':''                                
                        });
                        component.set("v.CitreonSE21ItemList", CitreonSE21ItemList);
                    }
                    if(typeof CitreonC84ItemList !== 'undefined' && CitreonC84ItemList.length > 0)
                        component.set("v.CitreonC84ItemList",CitreonC84ItemList);
                    else{
                        var CitreonC84ItemList = [];
                        CitreonC84ItemList.push({
                            'sobjectType': 'orderItem',
                            'Product2.PSA_Variant__c': '',
                            'Product2.PSA_Ext_Colour__c': '',
                            'Product2.Exterior_Color__c': '',
                            'Product2.Interior_Color__c': '',
                            'Product2.Metallic_Non_Metallic__c':'',
                            'Product2.Interior_Trim_Type__c':'',
                            'Product2.Roof__c':'',
                            'Product2.Pack__c':''                                
                        });
                        component.set("v.CitreonC84ItemList", CitreonC84ItemList);
                    }
                }
            }
        });
        $A.enqueueAction(action); 
    },
    
    saveOrderHelper : function(component, event, helper, type) {
        var forecastTimeline = parseInt($A.get("$Label.c.MonthlyOrder_Forecast_timeline"));
        component.set("v.spinner", true);
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        var today = new Date();
        today.setDate(today.getDate() + forecastTimeline);
        var month = today.getMonth();
        var monthName = months[today.getMonth()];
        var year = today.getFullYear();
        var OrderId = component.get("v.OrderId");
        var productList = component.get("v.productList");
        var quantityList = component.get("v.quantityList");
        var f1quantityList = component.get("v.f1quantityList");
        var f2quantityList = component.get("v.f2quantityList");
        var f3quantityList = component.get("v.f3quantityList");
        var f4quantityList = component.get("v.f4quantityList");
        var f5quantityList = component.get("v.f5quantityList");
        var f6quantityList = component.get("v.f6quantityList");
        var fMonth1 = component.get("v.fMonth1");
        var fMonth2 = component.get("v.fMonth2");
        var fMonth3 = component.get("v.fMonth3");
        var fMonth4 = component.get("v.fMonth4");
        var fMonth5 = component.get("v.fMonth5");
        var fMonth6 = component.get("v.fMonth6");
        var fyear1 = component.get("v.fyear1");
        var fyear2 = component.get("v.fyear2");
        var fyear3 = component.get("v.fyear3");
        var fyear4 = component.get("v.fyear4");
        var fyear5 = component.get("v.fyear5");
        var fyear6 = component.get("v.fyear6");
        var error = false;
        
        
        if(typeof productList == 'undefined' || productList.length == 0)
        {
            error = true;
            helper.showError(component, event, helper, "Order Qty is empty. Please select at least one model");
        }
        
        if(typeof quantityList !== 'undefined' && quantityList.length > 0)
        {
            error = true;
            for(var i=0; i<quantityList.length; i++)
            {
                if(quantityList[i] != 0 && quantityList[i] != "" && quantityList[i] != null)
                {
                    error = false;
                }
                
            }
            if(error == true)
                helper.showError(component, event, helper, "Please fill line item quantities with valuable Numbers to save the details");
            
        }
        if(!error)
        {
            var action = component.get("c.saveFirmOrder");
            action.setParams({
                "monthName": monthName,
                "year": year,
                "productList": productList,
                "quantityList": quantityList,
                "demomapFirm": component.get("v.demomapFirm")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var value = response.getReturnValue();
                    component.set("v.OrderId", value.Id);
                    component.set("v.OrderStatus", value.Status);
                    component.set("v.OrderReviewStatus", value.PSA_Review_Status__c);
                    component.set("v.C84Qty", value.C84_Total_Qty__c);
                    component.set("v.SE21Qty", value.SE21_Total_Qty__c);
                    this.getItemProducts2(component, event, helper);
                    this.getForecast1(component, event, helper);
                    this.getDemoProducts(component, event, helper);
                    this.getDealerobjective(component, event, helper);                    
                    this.triggerChart(component, event, helper);
                    if(type == "review")
                        this.sendForReview(component, event, helper);
                    else
                    {
                        var success = $A.get("$Label.c.MonthlyOrder_Save_Success");
                        helper.showSuccess(component, event, helper, success);
                    }
                }
            });
            $A.enqueueAction(action);
            this.saveForecastOrder(component, event, helper, fMonth1, fyear1, productList, f1quantityList, "f1", component.get("v.demofmap1"));
            this.saveForecastOrder(component, event, helper, fMonth2, fyear2, productList, f2quantityList, "f2", component.get("v.demofmap2"));
            this.saveForecastOrder(component, event, helper, fMonth3, fyear3, productList, f3quantityList, "f3", component.get("v.demofmap3"));
            this.saveForecastOrder(component, event, helper, fMonth4, fyear4, productList, f4quantityList, "f4", component.get("v.demofmap4"));
            this.saveForecastOrder(component, event, helper, fMonth5, fyear5, productList, f5quantityList, "f5", component.get("v.demofmap5"));
            this.saveForecastOrder(component, event, helper, fMonth6, fyear6, productList, f6quantityList, "f6", component.get("v.demofmap6"));
            //  this.saveDemoOrderItems(component, event, helper, fMonth1, fMonth2, fMonth3, fMonth4, fMonth5, fMonth6, fyear1, fyear2, fyear3, fyear4, fyear5, fyear6);
            
        }
    },
    
    saveForecastOrder : function(component, event, helper, monthName, year, productList, quantityList, fmonth, demofmap) {
        var action = component.get("c.saveFirmOrder");
        action.setParams({
            "monthName": monthName,
            "year": year,
            "productList": productList,
            "quantityList": quantityList,
            "demomapFirm": demofmap
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var SE21Qty = "v."+fmonth+"SE21Qty";
                var C84Qty = "v."+fmonth+"C84Qty";
                component.set(SE21Qty, value.SE21_Total_Qty__c);
                component.set(C84Qty, value.C84_Total_Qty__c);
            }
        });
        $A.enqueueAction(action);
    },
    
    getCarNames : function(component, event) {
        
        var action = component.get("c.getCarMethod");
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.carBrands", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
        
    },
    
    getFirmOrder : function(component, event, monthName) {
        var action = component.get("c.fetchFirmOrder");
        action.setParams({
            "month": monthName,
            "year": component.get("v.year")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                if(value != null)
                {
                    component.set("v.OrderId", value.Id);
                    component.set("v.OrderStatus", value.Status);
                    component.set("v.OrderReviewStatus", value.PSA_Review_Status__c);
                    component.set("v.C84Qty", value.C84_Total_Qty__c);
                    component.set("v.SE21Qty", value.SE21_Total_Qty__c);
                    var items = value.OrderItems;
                    var productIds = component.get("v.productList");      alert(productIds);                      
                    var quantities = [];
                    if(productIds != null)
                        for(var i=0; i<productIds.length; i++)
                            quantities.push(0);
                    if(items)
                    {
                    for(var i=0; i<items.length; i++)
                    {
                        var index = productIds.indexOf(items[i].Product2.Id);
                        quantities.splice(index,1,items[i].Quantity);
                    }
                    }
                    component.set("v.quantityList",quantities);           
                    
                    if(value.Status == 'Activated' || value.PSA_Review_Status__c == 'Internal Review Submitted' || value.PSA_Review_Status__c == 'Internal Review Approved' || value.PSA_Review_Status__c == 'First Review Submitted' || value.PSA_Review_Status__c == 'First Review Approved' || value.PSA_Review_Status__c == 'Final Review Approved' || value.PSA_Review_Status__c == 'Final Review Submitted')
                        component.set("v.disableAll", true);
                    if(value.Status == 'Activated' || value.PSA_Review_Status__c == 'Internal Review Submitted' || value.PSA_Review_Status__c == 'First Review Submitted' || value.PSA_Review_Status__c == 'Final Review Approved' || value.PSA_Review_Status__c == 'Final Review Submitted')
                        component.set("v.disableButton", true);
                }
            }
            component.set("v.spinner", false);
            
        });
        $A.enqueueAction(action);
    },
    
    getForecast1 : function(component, event, helper) {
        var action = component.get("c.fetchForecastOrder");
        action.setParams({
            "Month": component.get("v.monthName"),
            "year": component.get("v.year"),
            "fMonth1": component.get("v.fMonth1"),
            "fMonth2": component.get("v.fMonth2"),
            "fMonth3": component.get("v.fMonth3"),
            "fMonth4": component.get("v.fMonth4"),
            "fMonth5": component.get("v.fMonth5"),
            "fMonth6": component.get("v.fMonth6"),
            "fyear1": component.get("v.fyear1"),
            "fyear2": component.get("v.fyear2"),
            "fyear3": component.get("v.fyear3"),
            "fyear4": component.get("v.fyear4"),
            "fyear5": component.get("v.fyear5"),
            "fyear6": component.get("v.fyear6")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var fValues = value['fValues'];
                component.set("v.demomapFirm",value['demoItemMapFirm']);
                component.set("v.demofmap1",value['demoItemMap1']);
                component.set("v.demofmap2",value['demoItemMap2']);
                component.set("v.demofmap3",value['demoItemMap3']);
                component.set("v.demofmap4",value['demoItemMap4']);
                component.set("v.demofmap5",value['demoItemMap5']);
                component.set("v.demofmap6",value['demoItemMap6']);
                component.set("v.fmap1",fValues['fItemMap1']);
                component.set("v.fmap2",fValues['fItemMap2']);
                component.set("v.fmap3",fValues['fItemMap3']);
                component.set("v.fmap4",fValues['fItemMap4']);
                component.set("v.fmap5",fValues['fItemMap5']);
                component.set("v.fmap6",fValues['fItemMap6']);
                var fmap = fValues['fItemMap7'];
                if(fmap != null)
                    for(var key in fmap)
                    {
                        
                        component.set("v.f1SE21Qty", fmap["f1SE21"]!=null?fmap["f1SE21"]:0);
                        component.set("v.f2SE21Qty", fmap["f2SE21"]!=null?fmap["f2SE21"]:0);
                        component.set("v.f3SE21Qty", fmap["f3SE21"]!=null?fmap["f3SE21"]:0);
                        component.set("v.f4SE21Qty", fmap["f4SE21"]!=null?fmap["f4SE21"]:0);
                        component.set("v.f5SE21Qty", fmap["f5SE21"]!=null?fmap["f5SE21"]:0);
                        component.set("v.f6SE21Qty", fmap["f6SE21"]!=null?fmap["f6SE21"]:0);
                        component.set("v.f1C84Qty", fmap["f1C84"]!=null?fmap["f1C84"]:0);
                        component.set("v.f2C84Qty", fmap["f2C84"]!=null?fmap["f2C84"]:0);
                        component.set("v.f3C84Qty", fmap["f3C84"]!=null?fmap["f3C84"]:0);
                        component.set("v.f4C84Qty", fmap["f4C84"]!=null?fmap["f4C84"]:0);
                        component.set("v.f5C84Qty", fmap["f5C84"]!=null?fmap["f5C84"]:0);
                        component.set("v.f6C84Qty", fmap["f6C84"]!=null?fmap["f6C84"]:0);
                    }  
                window.setTimeout($A.getCallback(function() {
                    helper.addForecastQuantity(component,event,helper);
                }), 1000); 
            }
        });
        $A.enqueueAction(action);
    },
    
    addForecastQuantity : function(component, event, helper) {
        var q1list = [];
        var q2list = [];
        var q3list = [];
        var q4list = [];
        var q5list = [];
        var q6list = [];
        var fmap1 = component.get("v.fmap1");
        var fmap2 = component.get("v.fmap2");
        var fmap3 = component.get("v.fmap3");
        var fmap4 = component.get("v.fmap4");
        var fmap5 = component.get("v.fmap5");
        var fmap6 = component.get("v.fmap6");
        var productList = component.get("v.productList");
        if(typeof productList !== 'undefined' && productList.length > 0)
        {
            for(var i=0; i<productList.length; i++)
            {
                q1list.push(fmap1[productList[i]]);
                q2list.push(fmap2[productList[i]]);
                q3list.push(fmap3[productList[i]]);
                q4list.push(fmap4[productList[i]]);
                q5list.push(fmap5[productList[i]]);
                q6list.push(fmap6[productList[i]]);
            }
            component.set("v.f1quantityList", q1list);
            component.set("v.f2quantityList", q2list);
            component.set("v.f3quantityList", q3list);
            component.set("v.f4quantityList", q4list);
            component.set("v.f5quantityList", q5list);
            component.set("v.f6quantityList", q6list);
        }
    },
    
    showError : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
        component.set("v.spinner", false);
    },
    showSuccess : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "message": msg
        });
        toastEvent.fire();
    },
    
    sendForReview : function(component, event, helper) {
        var OrderId = component.get("v.OrderId");
        var OrderReviewStatus = component.get("v.OrderReviewStatus");
        var action = component.get("c.submitForReview");
        action.setParams({
            "OrderId": OrderId,
            "OrderReviewStatus": OrderReviewStatus
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.OrderReviewStatus", value.PSA_Review_Status__c);
                component.set("v.OrderStatus", value.Status);
                component.set("v.spinner", false);
                if(value.Status == 'Activated' || value.PSA_Review_Status__c == 'First Review Submitted' || value.PSA_Review_Status__c == 'Final Review Approved' || value.PSA_Review_Status__c == 'Final Review Submitted' || value.PSA_Review_Status__c == 'Internal Review Submitted')
                    component.set("v.disableAll", true);
                if(value.Status == 'Activated' || value.PSA_Review_Status__c == 'Internal Review Submitted' || value.PSA_Review_Status__c == 'First Review Submitted' || value.PSA_Review_Status__c == 'Final Review Approved' || value.PSA_Review_Status__c == 'Final Review Submitted')
                    component.set("v.disableButton", true);
                var success = $A.get("$Label.c.MonthlyOrder_Internal_Review_Submit_Success");
                if(value.PSA_Review_Status__c == 'Internal Review Submitted')
                    helper.showSuccess(component, event, helper, success);
                var success = $A.get("$Label.c.MonthlyOrder_First_Review_Submit_Success");
                if(value.PSA_Review_Status__c == 'First Review Submitted')
                    helper.showSuccess(component, event, helper, success);
                var success = $A.get("$Label.c.MonthlyOrder_Final_Review_Submit_Success");
                if(value.PSA_Review_Status__c == 'Final Review Submitted')
                    helper.showSuccess(component, event, helper, success);
            }
        });
        $A.enqueueAction(action);
    },
    
    getPreviousRecommendationms1 : function(component, event, helper, monthList) {
        var action = component.get("c.fetchPreviousOrderValues");
        action.setParams({
            "month": component.get("v.monthName"),
            "year": component.get("v.year")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.previousValues", value);
            }
        });
        $A.enqueueAction(action);  
    },
    
    
    getPreviousRecommendationms2 : function(component, event, helper, monthList) {
        var action = component.get("c.fetchPreviousOrderValues2");
        action.setParams({
            "month": component.get("v.monthName"),
            "year": component.get("v.year")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS") {
                var value = response.getReturnValue();
                var SE21 = 0;
                var C84 = 0;
                for(var i=0; i<value.length; i++)
                {
                    var val = value[i];
                    var month = val.PSA_Month_Year_Order__c;
                    var monthName = month.slice(0,3);
                    var year = val.Order_Year__c;
                    var halfyear = year.toString();
                    var Integer = monthList.indexOf(monthName+"'"+halfyear)+1;
                    var row1 = "r1c"+Integer;
                    document.getElementById(row1).innerHTML = val.SE21_Total_Qty__c;
                    var row2 = "r2c"+Integer;
                    document.getElementById(row2).innerHTML = val.C84_Total_Qty__c;
                    
                    SE21 +=val.SE21_Total_Qty__c;
                    C84 +=val.C84_Total_Qty__c;
                }
                document.getElementById("r1c13").innerHTML = (SE21/12).toFixed(0);
                document.getElementById("r2c13").innerHTML = (C84/12).toFixed(0);
            }
        });
        $A.enqueueAction(action);  
    },
    
    getPreviousRecommendationms3 : function(component, event, helper) {
        var action = component.get("c.fetchClosingStockValues");
        action.setParams({
            "month": component.get("v.monthName"),
            "year": component.get("v.year")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS") {
                var value = response.getReturnValue();
                document.getElementById("r1c14").innerHTML = 0;
                document.getElementById("r2c14").innerHTML = 0;
                document.getElementById("r1c15").innerHTML = value["sc21"];
                document.getElementById("r2c15").innerHTML = value["c84"];
                document.getElementById("r1c16").innerHTML = value["sc21AI"];
                document.getElementById("r2c16").innerHTML = value["c84AI"];
            }
        });
        $A.enqueueAction(action);  
    },
    
    getDealerobjective : function(component, event, helper) {
        debugger;
        var action = component.get("c.getdealerobjectiverecord");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.delearobjective", value);
                component.set("v.orderLimit", value.orderLimit);
                var achSE21Qty = Number.isFinite(component.get("v.SE21Qty"))?component.get("v.SE21Qty"):0;
                var achC84Qty = Number.isFinite(component.get("v.C84Qty"))?component.get("v.C84Qty"):0;
                var achQty = Number.isFinite((achSE21Qty+achC84Qty)/(value.sc21total+value.C84total)*100)? (achSE21Qty+achC84Qty)/(value.sc21total+value.C84total)*100:0;
                component.set("v.achSE21Qty", parseInt(Number.isFinite(component.get("v.SE21Qty")/value.sc21total*100)?component.get("v.SE21Qty")/value.sc21total*100:0));
                component.set("v.achC84Qty", parseInt(Number.isFinite(component.get("v.C84Qty")/value.C84total*100)?component.get("v.C84Qty")/value.C84total*100:0));
                component.set("v.achQty", parseInt(achQty));
            }
            component.set("v.spinner", false);
            
        });
        $A.enqueueAction(action);  
        
    }, 
    
    triggerChart : function(component, event, helper) {
        if(component.get("v.CitreonSE21Div"))
            var chartjs = component.find("chartjsSE21");
        else if(component.get("v.CitreonC84Div"))
            var chartjs = component.find("chartjsC84");
        else if(!component.get("v.CitreonC84Div") && !component.get("v.CitreonSE21Div"))
            var chartjs = component.find("chartObjCom");
        chartjs.chartMethod();
        
    },
    
    getVariantList : function(component, event, helper) {
        debugger;
        var action = component.get("c.fetchCarVariants");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.variantList", value);
            }
            
        });
        $A.enqueueAction(action);  
    },
})