({
    afterRender: function (component, helper) {
        this.superAfterRender();
        var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        var today = new Date();
        today.setDate(today.getDate() + 40);
        var monthList = [];
        for(var i=12; i>0; i--)
        {
            if(today.getDate() > 28)
                today.setDate(today.getDate()-3);
            today.setMonth(today.getMonth() - 1);
            var find = "t"+i;
            var month = today.getMonth();
            var monthName = months[month];
            var year = today.getFullYear();
            var halfyear = year.toString();
            document.getElementById(find).innerHTML = monthName+"'"+halfyear.slice(2);
            monthList.push(monthName+"'"+halfyear);
        }
        monthList.reverse();
        helper.getPreviousRecommendationms1(component, event, helper, monthList);
        helper.getPreviousRecommendationms2(component, event, helper, monthList);
        helper.getPreviousRecommendationms3(component, event, helper);
    },
    
})