({
    hlpBindderItems : function(component , event , helper) {
        var items_att = component.get("v.items");
        var item_att = component.get("v.item");
        // Data Mapper 
        var items_updated = [];
        for(var i =0 ; i < items_att.length ; i++){
            var arrayItem = items_att[0];
            if(item_att.Id == arrayItem.Id){
           //item_att.PSA_Damaged_Qty__c = component.get("v.item.PSA_Damaged_Qty__c");
                items_updated.push(item_att);
            }
            else{
                items_updated.push(arrayItem);
            }
        }
        // Not to write anything after this statment to fire an event
        helper.hlpeventCaller(component , event , helper);
    },
    hlpeventCaller : function(component , event , helper){

        var poevents = component.getEvent("poevent");
        poevents.setParams({
            "items" : component.get("v.items")
         });
         poevents.fire();
    },
     hlpRowtaxCalculation : function(component , event , helper){
        // get object details 
        var rowdetail = component.get("v.item");       
        //var freighcharges =  component.find("fr-ammount").set("v.value",0);  
        var frieghtamount =  component.find("fr-ammount").get("v.value");        
        // Test Data need be Delete This Block End Line
        /* Auto calculation logic at Row Level need to be Implemebt Here by doing parseInt */
        var netdealerprice = ((parseInt(rowdetail.PSA_Rate_per_unit__c) * parseInt(rowdetail.PSA_GST__c)) /100 )+parseInt(rowdetail.PSA_Rate_per_unit__c);
        component.find("netdealer-price").set("v.value",netdealerprice);
        var matiral_value = parseInt(rowdetail.PSA_Rate_per_unit__c) * parseInt(rowdetail.PSA_Quantity__c);
        component.find("material-value").set("v.value",matiral_value);
        var tax_amount = ((parseInt(rowdetail.PSA_Rate_per_unit__c) * parseInt(rowdetail.PSA_GST__c)) /100 ) * parseInt(rowdetail.PSA_Quantity__c);
        component.find("tax-amount").set("v.value",tax_amount);
        var invoiceamount = parseInt(matiral_value)+parseInt(tax_amount)+parseInt(frieghtamount);
        if(frieghtamount == null)
            //component.find("inv-ammount").set("v.value",0);
            component.find("fr-ammount").set("v.value",0);
         else
        	component.find("inv-ammount").set("v.value",invoiceamount);
         
         
     }
})