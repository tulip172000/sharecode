({
	 Binchanges : function(component, event, helper) {         
         helper.Binchangeshelper(component, event, helper);
	},
    
    Binchanges1 : function(component, event, helper) {
        helper.Binchangeshelper1(component, event, helper);
    },
    
    checknonevaluesmethod:function(component,event,helper){
        var bool = event.getParam("listPage"); 
        if(bool == false)
        	component.set('v.validationcheck',bool);
        else
            component.set('v.validationcheck',bool);
        
        if(component.get('v.validationcheck') == false){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'please complete required fields',
                "type": "Error"
            });
            toastEvent.fire();
        }
    },
    
    SaveTransferRecords:function(component,event,helper){ 
        var childCmp = component.find("bintransferrows");
        if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                childCmp[i].checkvalidation(); 
                if(component.get('v.validationcheck'))
                    childCmp[i].saverecords();
            } 
        }
        else
            childCmp.checkvalidation();
        
        var isvalid=component.get('v.validationcheck');
        if(isvalid)
        {              
            helper.savebintransfershelper(component,event); 
            var partnumberselectedrec = component.get("v.selectedBinRecord");
            var partnumberselectedrecId=partnumberselectedrec.Id;
            if(partnumberselectedrecId == undefined)
            	helper.Binchangeshelper1(component, event, helper);
            else
                helper.Binchangeshelper(component, event, helper);
            
            var cmpTarget = component.find('submitbtn');
            $A.util.removeClass(cmpTarget, 'disablebtn');
        }
        
    },
    
    Bintransfermerge:function(component,event,helper){
        var singlebinlist = event.getParam("ordlist");
        if(component.get("v.Finaltransferbins").length > 0){
			var arr = [];
        	var existingrecord = component.get("v.Finaltransferbins");
            for(var i=0; i<existingrecord.length; i++){
                arr.push(existingrecord[i]);
            }
        	arr.push(singlebinlist[0]);
            component.set("v.Finaltransferbins", arr);
        }
        else{
            component.set("v.Finaltransferbins", singlebinlist);
        }
        
        
    },
    
    canceltransfer:function(component,event,helper){
        component.set("v.Finaltransferbins", []);
        if(component.get("v.partnumbersearch") == true){
        var childCmp = component.find("partnumberid");
        childCmp.clearpill();
        }
        else{        
        	var childCmp = component.find("partdescid");
            childCmp.clearpill();
        }        
    }
})