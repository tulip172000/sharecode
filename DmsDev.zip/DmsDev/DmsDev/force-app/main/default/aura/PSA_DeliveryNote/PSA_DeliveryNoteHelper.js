({
    
     MAX_FILE_SIZE: 4500000, //Max file size 4.5 MB 
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
     
    uploadHelper: function(component, event) {
        debugger;
        
        // get the selected files using aura:id [return array of files]
        var fileInput = component.find("fuploader").get("v.files");
        // get the first file using array index[0]  
        var file = fileInput[0];
        var self = this;
        // check the selected file size, if select file size greter then MAX_FILE_SIZE,
        // then show a alert msg to user,hide the loading spinner and return from function  
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
         
        // create a FileReader object 
        var objFileReader = new FileReader();
        // set onload function of FileReader object   
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
             
            fileContents = fileContents.substring(dataStart);
            // call the uploadProcess method 
            self.uploadProcess(component, file, fileContents);
        });
         
        objFileReader.readAsDataURL(file);
    },
      uploadProcess: function(component, file, fileContents) {
        debugger;
        // set a default size or startpostiton as 0 
        var startPosition = 0;
        // calculate the end size or endPostion using Math.min() function which is return the min. value   
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
         
        // start with the initial chunk, and set the attachId(last parameter)is null in begin
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    
     uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        // call the apex method 'SaveFile'
        debugger;
        var parentIds=component.get("v.deliverynoteId");
      //  alert(parentIds);
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.SaveFile");
        action.setParams({
            parentId: parentIds,
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
         
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                // check if the start postion is still less then end postion 
                // then call again 'uploadInChunk' method , 
                // else, diaply alert msg and hide the loading spinner
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    var toastEvent = $A.get("e.force:showToast");
        			toastEvent.setParams({
            		"type": "Success",
            		"message": "file uploaded successfully"
        });
        toastEvent.fire();
                }
                // handel the response errors        
            } else if (state === "INCOMPLETE") {
                alert("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        // enqueue the action
        $A.enqueueAction(action);
    },
    
      
    
        uploadHelperfordeliverynote: function(component, event) {
        debugger;
        // get the selected files using aura:id [return array of files]
        var fileInput = component.find("deliverynoteuploader").get("v.files");
        // get the first file using array index[0]  
        var file = fileInput[0];
        var self = this;
        // check the selected file size, if select file size greter then MAX_FILE_SIZE,
        // then show a alert msg to user,hide the loading spinner and return from function  
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.secondfilename", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
         
        // create a FileReader object 
        var objFileReader = new FileReader();
        // set onload function of FileReader object   
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
             
            fileContents = fileContents.substring(dataStart);
            // call the uploadProcess method 
            self.uploadProcessdelnote(component, file, fileContents);
        });
         
        objFileReader.readAsDataURL(file);
    },
    
     
    
    
    
    
     uploadProcessdelnote: function(component, file, fileContents) {
        debugger;
        // set a default size or startpostiton as 0 
        var startPosition = 0;
        // calculate the end size or endPostion using Math.min() function which is return the min. value   
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
         
        // start with the initial chunk, and set the attachId(last parameter)is null in begin
        this.uploadInChunkdelnote(component, file, fileContents, startPosition, endPosition, '');
    },

     
    uploadInChunkdelnote: function(component, file, fileContents, startPosition, endPosition, attachId) {
        // call the apex method 'SaveFile'
        debugger;
        var parentIds=component.get("v.deliverynoteId");
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.Savedelnote");
        action.setParams({
            parentId: parentIds,
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
         
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                // check if the start postion is still less then end postion 
                // then call again 'uploadInChunk' method , 
                // else, diaply alert msg and hide the loading spinner
                if (startPosition < endPosition) {
                    this.uploadInChunkdelnote(component, file, fileContents, startPosition, endPosition, attachId);
                } 
                // handel the response errors        
            } else if (state === "INCOMPLETE") {
                alert("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        // enqueue the action
        $A.enqueueAction(action);
    },
    
     allotmentdetails : function(component, event){
         var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.fetchallotment");
        
        action.setParams({
            "booknum" :bookingid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
           
            if (state == "SUCCESS") {
                var storeResponse = response.getReturnValue();
                if(storeResponse.length>0){
                var allotmentnum=storeResponse[0].Name;
                var allotmentdt=storeResponse[0].PSA_AllotmentDate__c;
                component.set("v.allotmentnum",allotmentnum);
                component.set("v.allotmentDate",allotmentdt);
                }
    }         
        });
        $A.enqueueAction(action); 
     },
    
    getcustomerinfo : function(component, event){
         // this.getinsuranceinformation(component, event, helper);
        
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.getcustomerdetails");
        
        action.setParams({
            "booknum" :bookingid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var addr=storeResponse.PSA_Customer_Account__r.PersonMailingStreet;
                var fname=storeResponse.PSA_Customer_Account__r.FirstName;
                var lname=storeResponse.PSA_Customer_Account__r.LastName;
                var state=storeResponse.PSA_Customer_Account__r.PersonMailingState;
                var city=storeResponse.PSA_Customer_Account__r.PersonMailingCity;
                var country=storeResponse.PSA_Customer_Account__r.PersonMailingCountry;
                var postalcode = storeResponse.PSA_Customer_Account__r.PersonMailingPostalCode;
                var phone = storeResponse.PSA_Customer_Account__r.Phone;
                //  var email = storeResponse.Account.PSA_Company_Email__c;
                var mobile=storeResponse.PSA_Customer_Account__r.PersonMobilePhone;
                var mail=storeResponse.PSA_Customer_Account__r.PersonEmail;
                var custType=storeResponse.PSA_Customer_Account__r.Type;
                var customerId=storeResponse.PSA_Customer_Account__r.PSA_Customer_Id__c;
               // alert(custType);
                component.set("v.custType",custType);
                component.set("v.customerName",fname);
                // component.set("v.lastname",lname);
                component.set("v.customerId",customerId);
                component.set("v.Phone",phone);
                component.set("v.primarycontact",mobile);
                component.set("v.secondarycontact",mobile); 
                component.set("v.emailId",mail);
                
                component.set("v.customerState",state);
                component.set("v.custCity",city);
                // component.set("v.area",country);
                component.set("v.custPincode",postalcode);
                component.set("v.customerAddr",addr);    
                 
            }         
        });
        $A.enqueueAction(action); 
      
    },
    
    contactdetails: function(component, event){
        var bookingid=component.get("v.bookingorderid");
        //alert(bookingid);
        var action = component.get("c.fetchcontact");           
        action.setParams({
            "booknum" :bookingid
        });
        action.setCallback(this, function(response){
            
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();  
         
                if(storeResponse==null || storeResponse=='' || storeResponse=="undefined"){
                    component.set("v.vehicleUser","");
                    component.set("v.vehicletype","");
                    component.set("v.vehUsername","");
                    component.set("v.vehcontact","");
                    component.set("v.vehmobile",""); 
                    component.set("v.vehEmail","");
                    component.set("v.vehiclePin","");
                    component.set("v.vehicleCity","");
                    component.set("v.vehicleState","");
                }
                else
                {
                    var userid=storeResponse.PSA_UserId__c;
                    var username=storeResponse.LastName;
                   // alert('@@@@@'+username);
                    var type=storeResponse.PSA_Type__c;
                    var mobieno=storeResponse.MobilePhone;
                    var tel=storeResponse.Phone;
                    var mail=storeResponse.Email;
                    var state=storeResponse.MailingState;
                    var city=storeResponse.MailingCity;
                    var pincode=storeResponse.MailingPostalCode;
                    var addr=storeResponse.MailingStreet;
                    component.set("v.vehicleUser",userid);
                    component.set("v.vehicletype",type);
                    component.set("v.vehUsername",username);
                    component.set("v.vehcontact",tel);
                    component.set("v.vehmobile",mobieno); 
                    component.set("v.vehEmail",mail);
                    component.set("v.vehiclePin",pincode);
                    component.set("v.vehicleCity",city);
                   component.set("v.vehicleState",state);
                    component.set("v.vehUserAddr",addr);
                 }
            }
        });
        $A.enqueueAction(action);
       
    },
    
    getregdetails: function(component, event){
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.reginfo");
        var buttond =component.get("v.buttondis");
        action.setParams({
            "booknum" :bookingid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                
                var storeResponse = response.getReturnValue();
                var regno=storeResponse.PSA_Registration_Number__c;
                component.set("v.registration",regno);
                component.set("v.Refnumber",storeResponse.PSA_HSRP_Reference_Number__c);
                var regno=component.get("v.registration");
                var disableretail= component.get("v.disableretail");
      
        
            }
        });
        $A.enqueueAction(action);
       
        
    },
    
   Insudetails: function(component,event){
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.insurancedetails");
        action.setParams({
            "booknum" :bookingid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if (state == "SUCCESS") {
                 
                 var result = response.getReturnValue();
                 var company=result.PSA_Insurance_Company__c;
                 var coverdt=result.PSA_Insurance_Start_Date__c;
                 var amt=result.PSA_Insurance_Amount__c;
                 var type=result.PSA_Insurance_Type__c;
                component.set("v.insurancecomp",company);
                component.set("v.covernote",coverdt);
                component.set("v.Insuaranceamount",amt);
                component.set("v.InsurancePolicy",type);
                
            }
        });
        $A.enqueueAction(action);
              
    }, 
    deliverynote: function(component,event){
    var bookingid=component.get("v.bookingorderid");
         
     var action = component.get("c.deliverynote");
        
        action.setParams({
                "booknum" :bookingid
            });
        
          action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {    
         
               var storeResponse = response.getReturnValue();  
               var noteId=storeResponse.Id;
              
                 var notestatus= storeResponse.PSA_Delivery_Note_Status__c;
                
                 var canceldt= storeResponse.PSA_Delivery_Note_Cancel_Date__c;
                 var deliverydt= storeResponse.PSA_Delivery_Note_Date__c;
                 var deliverynote= storeResponse.PSA_Delivery_Note_No__c;
                 
                 var remarks= storeResponse.PSA_Remarks__c;
                 var validtpin= storeResponse.PSA_Validation_Pin__c;
                component.set("v.deliverynoteId",noteId)
                 component.set("v.Status",notestatus);
               
                if(notestatus=='cancelled')
                {
                   
                component.set("v.checkingRoStatus",true);
                component.set("v.disableCancel",true);
               component.set("v.checkgatepass",true);
                component.set("v.checkstaus",true);
                component.set("v.nodelivrynote",true);
               
                }
                 component.set("v.cancelDt",canceldt);
                 component.set("v.delvnoteDt",deliverydt);
                 component.set("v.delvNote",deliverynote);
                 
                 component.set("v.Remarks",remarks);
                 component.set("v.validationPin",validtpin);
               }
        });
        $A.enqueueAction(action);
    
	}, 
    
    validatepin: function(component,event)
    {
        
        var bookingid=component.get("v.bookingorderid"); 
     	var action = component.get("c.customerpinvalidate");
        action.setParams({
                "booknum" :bookingid,
            
            });
        
          action.setCallback(this, function(response){
            var state = response.getState();
             
            if (state == "SUCCESS") {  
                
               	var storeResponse = response.getReturnValue();
                var res=storeResponse.User_generated_Pin_DN__c;
                var pinmatch= component.find("validPin").get("v.value");
                if(pinmatch!=null&& pinmatch!='undefined'&& pinmatch!='')
                {
                     if(pinmatch.toString()  == res.toString())
                     {	
                       component.set("v.pinCheck",res.toString());
                       this.showSuccessToastDel(component,event,'PIN Valid Success');  
                       component.set("v.validornot",true);
                     }
				
                    else
                     {
                       this.showErrorToast(component,event,'Enter valid PIN');  
                     }
                }       
                else
                {
                  
                  this.showErrorToast(component,event,'Please Generate PIN');  
                }
             
    }
    
});
        $A.enqueueAction(action); 
       
    	return valid;
    }, 
    
    saveinformation: function(component,event)  
    {   
        debugger;
        var bookingid=component.get("v.bookingorderid"); 
        var rmks= component.find("rmks").get("v.value");
        var refnum= component.find("refnum").get("v.value");
       if((rmks!=null && rmks!='undefined' && rmks!='') || (refnum !=null && refnum!='undefined' && refnum!=''))
       {
       var action = component.get("c.UpdateSaveInfo");
        action.setParams({
            "booknum" 		:bookingid,
            "rmks"		:rmks,
            "refnum"    :refnum
           });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") { 
                        
                        if (component.find("deliverynoteuploader").get("v.files"))
                          {
                           this.uploadHelperfordeliverynote(component, event);
                          } 
                this.showSuccessToast(component, event);
            }
                  
});
        $A.enqueueAction(action); 

    }
     else
         {
           if (component.find("deliverynoteuploader").get("v.files")) 
           {
           this.uploadHelperfordeliverynote(component, event);
           this.showSuccessToast(component, event);
           }                 
          }  
    
        
    },
    
  showSuccessToast : function(component, event){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": "delivery note updated successfully",
            "type": "success"
        });
        toastEvent.fire();  
    },
    showSuccessToastDel : function(component, event,msg){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": msg,
            "type": "success"
        });
        toastEvent.fire();  
    },
    
     showErrorToast : function(component, event,msg){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error",
            "message": msg,
            "type": "error"
        });
        toastEvent.fire();  
    },   
    
    enablegeneratevehnote : function(component, event){
        
        
         debugger;
         var bookingid=component.get("v.bookingorderid"); 
         var action = component.get("c.getpredelstatus");
          action.setParams({
                "booknum": bookingid,
           });
        
          action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") { 
               var storeResponse = response.getReturnValue();
       if(storeResponse)
        {
        var bookingid=component.get("v.bookingorderid");
        var refnum= component.find("refnum").get("v.value");
        var action = component.get("c.Retailpress"); 
         action.setParams({
            "booknum" :bookingid,
             "refnum" :refnum
        });
        action.setCallback(this, function(response){
            
            var state = response.getState();
            if (state == "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.disableretail",true);
                component.set("v.nodelivrynote",true);
                component.set("v.hsrpdis",true);
                component.set("v.checkstaus",false);
                
            }
         });
                     $A.enqueueAction(action);
                    
                    this.showSuccessToastDel(component, event,'Retail Success');
                    
                }
            else
            {
            this.showErrorToast(component,event,'Please Save the PreDelivery CheckList with necessary Conditions');  
            }
                  }
              
                  
});
        $A.enqueueAction(action); 
    
            
    },
    
    getinvoicedetails: function(component, event){
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.invoiceinformation");
        
        action.setParams({
            "booknum" :bookingid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS")
               {
                var storeResponse = response.getReturnValue();
                var invoiceno=storeResponse.PSA_Invoice__r.invoice__c;
                var invdate=storeResponse.PSA_Invoice__r.PSA_Invoice_Date__c;
                 component.set("v.invoiceNo",invoiceno);
                 component.set("v.invoiceDt",invdate);
                 component.set("v.invoiceStatus",storeResponse.PSA_Status__c);
                
               }         
        });
        $A.enqueueAction(action); 
     },
    vdnSavedisable : function(component, event){
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.nonEditable");
        
        action.setParams({
            "booknum" :bookingid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            debugger;
           
            if (state == "SUCCESS") 
            {
                 var storeResponse = response.getReturnValue();
                 var bookingid=component.get("v.bookingorderid");
                 var pdfurl ='../CitroenVehicleDeliveryNote?id='+bookingid;
                 window.open(pdfurl,"_blank", "width=700, height=550");
                 component.set("v.disableCancel",false);
                component.set("v.checkgatepass",false);
                 component.set("v.delvnoteDt",storeResponse.PSA_Delivery_Note_Date__c);
                 component.set("v.delvNote",storeResponse.PSA_Delivery_Note_No__c);
                 component.set("v.Status",storeResponse.PSA_Delivery_Note_Status__c);
                 helper.getVDNcheck(component, event, helper);
        
           }         
        });
        $A.enqueueAction(action); 
 
        
    },
    getorder:  function(component, event){
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.orderinfo");
        
        action.setParams({
            "booknum" :bookingid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var booknumber=storeResponse.OrderNumber;
                var bookingDt=storeResponse.PSA_Booking_Date__c;
                if(storeResponse.PSA_Sales_Consultant__c !='undefined' && storeResponse.PSA_Sales_Consultant__c !=null && storeResponse.PSA_Sales_Consultant__c !='')
                {
                    var salescon=storeResponse.PSA_Sales_Consultant__r.Name;
                    component.set("v.salesconsultant",salescon);
                }
                    
                component.set("v.otfnum",booknumber);
                component.set("v.otfDate",bookingDt);
                component.set("v.Remarks",storeResponse.PSA_Remarks_DN__c);
               
                if(storeResponse.PSA_Retail__c)
                {
                     component.set("v.disableretail",true);
                     component.set("v.nodelivrynote",true);
                      component.set("v.hsrpdis",true);
                     component.set("v.checkstaus",false);
                    
                }
               
    }         
        });
        $A.enqueueAction(action); 
     },
    getVDNcheck:  function(component, event){
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.getVdncheckdisable");
        
        action.setParams({
            "booknum" :bookingid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                var orderno=storeResponse;
                component.set("v.savedis",orderno);
                 }
             var satus=component.get("v.savedis");
               if(satus==true){
            component.find("pin").set("v.disabled",true);
        }
            
        });
        $A.enqueueAction(action); 
     },
     DeliveryNoteDetails : function(component, event){
      var isvalid = true;
     var bookingid=component.get("v.bookingorderid");
     var action = component.get("c.deliverynote");
        action.setParams({
                "booknum" :bookingid
            });
        
          action.setCallback(this, function(response){
            var state = response.getState();
            if (state == "SUCCESS") {    
                debugger;
                var storeResponse = response.getReturnValue();
               if(storeResponse.length<0)
                {
                //Cancel_DN__c
                }
                else{
                 var noteId=storeResponse[0].Id;
                 var notestatus= storeResponse[0].PSA_Delivery_Note_Status__c;
                 var canceldt= storeResponse[0].PSA_Delivery_Note_Cancel_Date__c;
                 var deliverydt= storeResponse[0].PSA_Delivery_Note_Date__c;
                 var deliverynote= storeResponse[0].PSA_Delivery_Note_No__c;
                 if(notestatus=='cancelled')
                {
                    isvalid=false;
                component.set("v.checkingRoStatus",true);
                component.set("v.disableCancel",true);
                component.set("v.checkgatepass",true);
                component.set("v.checkstaus",true);
                component.set("v.nodelivrynote",true);
                component.set("v.disablesave",true);
                }
                 component.set("v.deliverynoteId",noteId)
                 component.set("v.Status",notestatus);
                 component.set("v.cancelDt",canceldt);
                 component.set("v.delvnoteDt",deliverydt);
                 component.set("v.delvNote",deliverynote);
                    //component.set("v.checkgatepass",false);
                   //this is for cancel deliverybutton after vdn is generated
                    if(storeResponse[0].Cancel_DN__c && isvalid){
                         component.set("v.disableCancel",false);
                        component.set("v.checkgatepass",false); 
                    }
                
                }  
                }         
        });
        $A.enqueueAction(action); 
  },
     fetchdocumenturl : function(component, event,helper) {
        var bookingid=component.get("v.bookingorderid");
        var action = component.get("c.fetchdocumenturl");
        action.setParams({ 
            "bookingId" : bookingid
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state == "SUCCESS") {
                console.log('response.getReturnValue()'+response.getReturnValue());
                component.set('v.attachurl',storeResponse); 
                var attachment= storeResponse;
                 var pdfurl ='../PSA_viewRcfile?Id='+attachment;
                 window.open(pdfurl,"_blank","width=600, height=550"); 
            }
        });
        $A.enqueueAction(action);
    },
     
})