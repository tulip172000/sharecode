({
    doInit: function(component, event, helper) {
        var partName11 = component.get("v.ProductInstance");
        var quantity=partName11.Quantity;
        component.find("Quantity").set("v.value", quantity);
         var stock=partName11.PSA_Stock__c;
        component.find("currentstock").set("v.value", stock);
        helper.getPartDetails123(component, event, helper);
        helper.getPartrate(component, event, helper);
    },
    recordChanges : function(component, event,helper) {
        debugger;
        var partName = component.get("v.selectedLookUpRecord");
        var partid=partName.Id;
       // var multiplefactor=partName.PSA_Multiplication_factor__c;
       // component.set("v.multifactor",multiplefactor);
         var Quantity = component.find("Quantity").get("v.value");
         var ratePerUnit = component.get("v.partRateperUnit");
        component.set("v.descrvisible",false);
        if(partid == "undefined" || partid == '' || partid == null){  
            if(Quantity==''||Quantity=='undefined'||Quantity==null){
                var TotalAmount = 0;
                var GSTamt=0;
            }
             else{
                var TotalAmount = Quantity* ratePerUnit;
                //var GST = component.find("GST").get("v.value");
                var CGST = component.find("CGST").get("v.value");
                var SGST = component.find("SGST").get("v.value");
                var IGST = component.find("IGST").get("v.value");
                var CESS =component.find("CESS").get("v.value");
        if(CGST === undefined){
            CGST = 0;
        }
         if(SGST === undefined){
            SGST = 0;
        }
         if(IGST === undefined){
            IGST = 0;
        }
         if(CESS === undefined){
            CESS = 0;
        }
     	 var GST = CGST+SGST; 
          var  GSTamt =(TotalAmount/100)*GST;
            }  
            	component.getEvent("partamount").setParams({
                "indexVar" : component.get("v.rowIndex"),
                "deleteAmount" : TotalAmount,"deleteGSTAmount" :GSTamt}).fire();
             component.find('PartNumber').set('v.value','');
            component.set("v.partDescription", '');
            component.set("v.UOM", '');
            component.set("v.HSNCode", '');
            component.set("v.GSTvalue", '');
            component.find("Quantity").set("v.value",'');
            component.find("currentstock").set("v.value",'');
            component.set("v.CESS", "");
            component.set("v.partRateperUnit",'');
            component.set("v.qyvisiable", true);
            component.set("v.MinOrderQty", "");
            component.set("v.NetDealerPrice", ""); 
            component.set("v.CGST", "");
            component.set("v.SGST", "");
            component.set("v.IGST", "");
             component.set("v.taxable", "");
             component.set("v.totaltax", "");
            component.set("v.totalordervalue", "");
            component.set("v.descrvisible",true);  
        }else{
             var isvalid=true;
           var partnum=partName.Id;
            var partschecklist=component.get('v.PartsSelListEdit');
            var x;
            for(x in partschecklist){
                if(partschecklist[x].PSA_Part_Number__c==partnum){
                    var Message='PartNumber Already Exist,Please delete it' ;
                    helper.showError(component,event,Message); 
                   isvalid=false;    
                }   
            }
            if(isvalid){
                 component.find('PartNumber').set('v.value',partnum);
            var partDesc = partName.PSA_Part_Description__c;
            var hsncode=partName.PSA_HSN_Code__c;
            var Unitmessure=partName.QuantityUnitOfMeasure;
          //  var taxvalue = partName.PSA_ProductPart_GST__c;
            var Cgst = partName.PSA_CGST__c;
            var Sgst = partName.PSA_SGST__c;
            var Igst = partName.PSA_IGST__c;
            var Cess = partName.PSA_CESS__c;
             var MOQ = partName.PSA_MOQ__c ;
            component.set("v.partDescription", partDesc);
            component.set("v.UOM", Unitmessure);
            component.set("v.HSNCode", hsncode);
              component.set("v.CESS", Cess);
            component.set("v.CGST", Cgst);
            component.set("v.SGST", Sgst);
            component.set("v.IGST", Igst);
             component.set("v.MinOrderQty", MOQ);
          //  component.set("v.GSTvalue", taxvalue);
            component.find("PartNumber").set("v.value", partid);
            component.set("v.Prdname", partName.PSA_Part_Number__c);
            var action=component.get('c.getPartrate');
            action.setParams({
                "partId" : partid
            });
            action.setCallback(this, function(response) {
                var responsevalue=response.getReturnValue();
                for(var i=0;i<responsevalue.length;i++){
                    var partRtem = responsevalue[i].UnitPrice;
                    var partnumber = responsevalue[i].Product2.PSA_Part_Number__c;                
                }
                component.set("v.partRateperUnit", partRtem);
                component.set("v.qyvisiable", false);     
                 component.set("v.partnumber1",partnumber);
                helper.getCurrentstock(component,event,helper);   
            });  
            $A.enqueueAction(action); 
        }
        var cssevent = component.getEvent("cssremoveevent");
         cssevent.fire();
        }
    },
    getTotalAmount : function(component, event) {
        debugger;
        var rowindex = component.get("v.rowIndex");
        var Quantity = component.find("Quantity").get("v.value");
       if(Quantity=='' || Quantity==null || Quantity=='undefined'){
            var qun=0; 
        }else{
            qun=Quantity;
        }
        var ratePerUnit = component.get("v.partRateperUnit");
        if(ratePerUnit == null || ratePerUnit == '' || ratePerUnit == "undefined"){
            
            var ratePerUnitvale=0;
        }else{
            ratePerUnitvale=ratePerUnit;
        }
        var TotalAmount = qun* ratePerUnitvale;
          var CGST = component.find("CGST").get("v.value");
         var SGST = component.find("SGST").get("v.value");
         var IGST = component.find("IGST").get("v.value");
          var CESS =component.find("CESS").get("v.value");
        if(CGST === undefined){
            CGST = 0;
        }
         if(SGST === undefined){
            SGST = 0;
        }
         if(IGST === undefined){
            IGST = 0;
        }
      if(CESS === undefined){
            CESS = 0;
        }
         var GST = CGST+SGST;
       // var GST = component.find("GST").get("v.value");
        var GSTamt =(TotalAmount/100)*GST;
         var totalordervalue=TotalAmount+GSTamt;
        //var curr = component.get("v.partTotalAmount");
        var curr = component.get('v.ProductInstance.TotalPrice');
        if(curr != ""){
            var currGST =(curr/100)*GST;
        }
        if(curr == ""){
            curr=0;
            var currGST = 0;
        }
        //var currGST = component.get("v.partGSTAmount");
        var Diffamnt = TotalAmount- curr;
        if(Diffamnt != "0" && curr != "0"){
            var eventListPage = component.getEvent("deleteOrderAmount");
            eventListPage.setParams({"OrderAmountcurr" : curr,"excludingAmountcurr" : currGST});
            eventListPage.fire();
            component.set('v.partTotalAmount',TotalAmount);
            component.set("v.partGSTAmount",GSTamt);
             component.set('v.taxable',TotalAmount);
            component.set("v.totaltax",GSTamt);
              component.set("v.totalordervalue",totalordervalue);
            var eventListPage = component.getEvent("getOrderAmount");
            eventListPage.setParams({"OrderAmountcurr" : TotalAmount,"excludingAmountcurr" : GSTamt});
            eventListPage.fire();
        }
        if(curr == "0"){
            component.set('v.partTotalAmount',TotalAmount);
            component.set('v.partGSTAmount',GSTamt);
             component.set('v.taxable',TotalAmount);
            component.set("v.totaltax",GSTamt);
              component.set("v.totalordervalue",totalordervalue);
            var eventListPage = component.getEvent("getOrderAmount");
            eventListPage.setParams({"OrderAmountcurr" : TotalAmount,"excludingAmountcurr" : GSTamt});
            eventListPage.fire();
        }
        component.set("v.NetDealerPrice", TotalAmount);
            if((Quantity <= 0)&&(Quantity != null)){
        }   
    },
            validateprice : function(component, event, helper) {   
         var charCode = event.getParams().keyCode;
             if ((charCode >= 1 && charCode <= 32)||(charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105)) { 
           return true;
          } 
        else{
             var message= 'Quantity should be greater than Zero';
            helper.showErrorToast(component,event,message);
             //component.find("MRP").set("v.value",'');
        }    
    },
    AddNewBlankRow : function(component, event, helper){
        var compEvent = component.getEvent('AddPartRowEvt');
        compEvent.fire();
    },
    inputchange : function(component, event, helper){
        debugger;
        var Quantity = component.find("Quantity").get("v.value");
        var partnumber = component.find("PartNumber").get("v.value"); 
        var ratePerUnit = component.get("v.partRateperUnit");   
        var CGST = component.find("CGST").get("v.value");
         var SGST = component.find("SGST").get("v.value");
         var IGST = component.find("IGST").get("v.value");
         var CESS =component.find("CESS").get("v.value");
     
             var TotalAmount = Quantity* ratePerUnit;
              var GST = CGST+SGST;
              var GSTamt =(TotalAmount/100)*GST;
            component.getEvent("partamount").setParams({
                "indexVar" : component.get("v.rowIndex"),
                "deleteAmount" : TotalAmount,"deleteGSTAmount" :GSTamt}).fire();
        var index = component.get("v.rowIndex");
        component.set("v.Prdname",'');
        component.find("PartNumber").set("v.value",'');
        component.find("Quantity").set("v.value",'');
        component.set("v.partDescription", '');
        component.set("v.UOM", '');
        component.set("v.HSNCode", '');
        component.set("v.GSTvalue", '');
        component.find("Quantity").set("v.value",'');
        component.find("currentstock").set("v.value",'');
        component.set("v.partRateperUnit",'');
        component.set("v.qyvisiable", true);
        component.set("v.BackOrderQty", '');
        component.set("v.MinOrderQty", "")
        component.set("v.PackQty", " ");
        component.set("v.NetDealerPrice",""); 
         component.set("v.Pillclear", ''); 
        component.set("v.CGST", " ");
        component.set("v.SGST","");
         component.set("v.IGST", "")
        component.set("v.CESS", " ");
        component.set("v.currentstock",""); 
         component.set("v.taxable", "");
             component.set("v.totaltax", "");
            component.set("v.totalordervalue", "");
    },
    lookupChanges : function(component, event, helper){
        //component.set("v.selectedLookUpRecord",'');
        component.set("v.qyvisiable",true); 
    },
    removeRow : function(component, event, helper){
        debugger;
        var Quantity = component.find("Quantity").get("v.value");
        var partnumber = component.find("PartNumber").get("v.value");
        var ratePerUnit = component.get("v.partRateperUnit");
         var CGST = component.find("CGST").get("v.value");
        var SGST = component.find("SGST").get("v.value");
       var IGST = component.find("IGST").get("v.value");
       var CESS =component.find("CESS").get("v.value");
        if(ratePerUnit == null || ratePerUnit == '' || ratePerUnit == "undefined"){
            var ratePerUnitvale=0;
        }else{
            ratePerUnitvale=ratePerUnit;
        }
        var TotalAmount = Quantity* ratePerUnitvale;
          var GST = IGST+CESS;
       // var GST = component.find("GST").get("v.value");
        var GSTamt =(TotalAmount/100)*GST;
         if((Quantity == '' ||Quantity==null||Quantity=='undefined')&&(partnumber== ''||partnumber==null||partnumber=='undefined')){
            component.getEvent("DeletePartRowEvt").setParams({
                "indexVar" : component.get("v.rowIndex"),
                "deleteAmount" : 0,"deleteGSTAmount" :0}).fire();
        }else{
            component.getEvent("DeletePartRowEvt").setParams({
                "indexVar" : component.get("v.rowIndex"),
                "deleteAmount" : TotalAmount,"deleteGSTAmount" :GSTamt}).fire();
        }
    }, 
       handleValidation : function(component, event, helper){
        debugger;
        var isvalid=true;
        var partname = component.find("PartNumber").get("v.value");
        //var partnameValue = partname.get("v.value");
        var Quantityval = component.find("Quantity").get("v.value");
       // var moqVal =component.find("MinOrderQty").get("v.value");
        var multiFACT =component.get("v.multifactor");
        if((partname == 'undefined' || partname == '' || partname == null )&&((Quantityval == ''||Quantityval=='undefined'||Quantityval==null))){
            var Message = 'please select the PartNumber and Quantity';
            helper.showError(component,event,Message);
            isvalid=false;    
        } 
          if((partname == 'undefined' || partname == '' || partname == null )&&(Quantityval != '')){
            var Message = 'please select the PartNumber';
            helper.showError(component,event,Message);
            isvalid=false;
            // isvalidparDetails = false;
        } 
            if((Quantityval == ''||Quantityval=='undefined'||Quantityval==null)&&(partname != '')){
            var Message=' Please Enter the Quantity' ;
            helper.showError(component,event,Message);  
            isvalid=false;
            //  isvalidparDetails = false;
        }
     /*   else{
     if(Quantityval > moqVal){
                var multires = Quantityval%moqVal;
                if(multires != 0){
               	  var Message=' Quantity should be in Mutliplication factor' ;
                	helper.showError(component,event,Message);
                  isvalid=false;
                }
        }else{
       if(Quantityval < moqVal){
                      var Message=' Quantity should be Greater than MOQ' ;
                            helper.showError(component,event,Message);
                          isvalid=false;
                    }  
            }
            }*/
     
        return isvalid;
    },
     onfocusPO : function(component, event, helper) {
       
       var cssevent = component.getEvent("cssevent");
         cssevent.fire();
    },
        descChanges : function(component, event,helper) {
            debugger;
        var partName = component.get("v.selectedLookUpRecordDesc");
        var partid=partName.Id;
          component.set("v.PartNumbr", false); 
              var ratePerUnit = component.get("v.partRateperUnit");
        if(partid == "undefined" || partid == '' || partid == null){
              var Quantity = component.find("Quantity").get("v.value"); 
           if(Quantity==''||Quantity=='undefined'||Quantity==null){
                var TotalAmount = 0;
                var GSTamt=0;
            }
            else{
                var TotalAmount = Quantity* ratePerUnit;
                //var GST = component.find("GST").get("v.value");
                var CGST = component.find("CGST").get("v.value");
                var SGST = component.find("SGST").get("v.value");
                var IGST = component.find("IGST").get("v.value");
                var CESS =component.find("CESS").get("v.value");
        if(CGST === undefined){
            CGST = 0;
        }
         if(SGST === undefined){
            SGST = 0;
        }
         if(IGST === undefined){
            IGST = 0;
        }
         if(CESS === undefined){
            CESS = 0;
        }
     	 var GST = CGST+SGST;
          var  GSTamt =(TotalAmount/100)*GST;
            }    
             component.getEvent("partamount").setParams({
                "indexVar" : component.get("v.rowIndex"),
                "deleteAmount" : TotalAmount,"deleteGSTAmount" :GSTamt}).fire();
              component.find('PartNumber').set('v.value','');
            component.set("v.partDescription", '');
            component.set("v.UOM", '');
            component.set("v.HSNCode", '');
            component.set("v.GSTvalue", '');
            component.find("Quantity").set("v.value",'');
            component.set("v.partRateperUnit",'');
            component.set("v.qyvisiable", true);
            component.find("currentstock").set("v.value",'');
            component.set("v.MinOrderQty", "");
            component.set("v.partnumber1",'');
            component.set("v.NetDealerPrice", "");
            component.set("v.CESS", "");
            component.set("v.CGST", "");
            component.set("v.SGST", "");
            component.set("v.IGST", "");
             component.set("v.allotedqty", "");
            component.set("v.invoiceqty", "");
              component.set("v.taxable", "");
             component.set("v.totaltax", "");
            component.set("v.totalordervalue", "");
            component.set("v.PartNumbr", true);  
        }else{
             var isvalid=true;
           var partnum=partName.Id;
            var partschecklist=component.get('v.PartsSelListEdit');
            var x;
            for(x in partschecklist){
                if(partschecklist[x].PSA_Part_Number__c==partnum){
                    var Message='PartNumber Already Exist,Please delete it' ;
                    helper.showError(component,event,Message); 
                   isvalid=false;    
                }   
            }
            if(isvalid){
                 component.find('PartNumber').set('v.value',partnum);

            var partDesc = partName.PSA_Part_Description__c;
            var hsncode=partName.PSA_HSN_Code__c;
            var Unitmessure=partName.QuantityUnitOfMeasure;
           // var taxvalue = partName.PSA_ProductPart_GST__c;
            var Cgst = partName.PSA_CGST__c;
            var Sgst = partName.PSA_SGST__c;
            var Igst = partName.PSA_IGST__c;
            var Cess = partName.PSA_CESS__c;
            var MOQ = partName.PSA_MOQ__c ;
            component.set("v.partDescription", partDesc);
            component.set("v.UOM", Unitmessure);
            component.set("v.HSNCode", hsncode);
            component.set("v.CESS", Cess);
            component.set("v.CGST", Cgst);
            component.set("v.SGST", Sgst);
            component.set("v.IGST", Igst);
            component.set("v.MinOrderQty", MOQ);
           // component.set("v.GSTvalue", taxvalue);
            component.find("PartNumber").set("v.value", partid);
            component.set("v.Prdname", partName.PSA_Part_Number__c);
            var action=component.get('c.getPartrate');
            action.setParams({
                "partId" : partid
            });
            action.setCallback(this, function(response) {
                var responsevalue=response.getReturnValue();
                for(var i=0;i<responsevalue.length;i++){
                    var partRtem = responsevalue[i].UnitPrice;
                    var partnumber = responsevalue[i].Product2.PSA_Part_Number__c;
                }
                component.set("v.partRateperUnit", partRtem);
                 component.set("v.Prdname", partnumber);
                component.set("v.qyvisiable", false);
                component.set("v.BackOrderQty", "0");
                 component.set("v.partnumber1",partnumber);  
                helper.getCurrentstock(component,event,helper);  
            });  
            $A.enqueueAction(action); 
        }
        var cssevent = component.getEvent("cssremoveevent");
         cssevent.fire();
        }
    },
})