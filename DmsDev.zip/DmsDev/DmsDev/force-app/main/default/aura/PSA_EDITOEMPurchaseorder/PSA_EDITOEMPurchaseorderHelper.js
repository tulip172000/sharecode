({
    getPartDetails123 : function(component, event) {   
        var partName11 = component.get("v.ProductInstance");
        var partName = partName11.PSA_Part_Number__c;
        component.set("v.selectedPart",partName);
        var action=component.get('c.fetchProductDetails');
        action.setParams({
            "partId" : component.get("v.selectedPart")
        });
        action.setCallback(this, function(response){
            var responsevalue = response.getReturnValue();
            for(var i=0;i<responsevalue.length;i++){
                var partDesc = responsevalue[i].PSA_Part_Description__c;
                var hsncode=responsevalue[i].PSA_HSN_Code__c;
                var Unitmessure=responsevalue[i].QuantityUnitOfMeasure;
                var prdname=responsevalue[i].PSA_Part_Number__c	;
                var Cgst = responsevalue[i].PSA_CGST__c;
                var Sgst = responsevalue[i].PSA_SGST__c;
                var Igst = responsevalue[i].PSA_IGST__c;
                var Cess = responsevalue[i].PSA_CESS__c;
                var MOQ = responsevalue[i].PSA_MOQ__c ;
                
            }
            if(responsevalue.length){ 
                component.set("v.MinOrderQty",MOQ );
                component.set("v.partDescription", partDesc);
                component.set("v.UOM", Unitmessure);
                component.set("v.HSNCode", hsncode);
                component.set("v.CESS", Cess);
                component.set("v.CGST", Cgst);
                component.set("v.SGST", Sgst);
                component.set("v.IGST", Igst);
                component.set("v.MinOrderQty", MOQ);
                component.set("v.Pillclear", prdname);
                component.set("v.Prdname", prdname);
                
            }else{
                component.set("v.qyvisiable", true);
            }           
            
        });
        $A.enqueueAction(action);
    },
    getPartrate : function(component, event) {
        var partName = component.get("v.ProductInstance");
        var partid=partName.Product2Id;
        component.find("PartNumber").set("v.value", partid); 
        var action=component.get('c.getPartrate');
        action.setParams({
            "partId" : partid
        });
        action.setCallback(this, function(response) {
            var responsevalue=response.getReturnValue();
            if(responsevalue.length>0){
                for(var i=0;i<responsevalue.length;i++){
                    var partRtem = responsevalue[i].PSA_Net_Dealer_Price__c;
                    component.set("v.partRateperUnit", partRtem);
                    component.set("v.qyvisiable", false);
                } 
            }else{
                component.set("v.BackOrderQty", "");
                component.set("v.MinOrderQty", "");
                component.find("IGST").set("v.value", '');
                component.find("SGST").set("v.value", '');
                component.find("CGST").set("v.value", '');
                component.find("CESS").set("v.value", '');
                
            }
        });  
        $A.enqueueAction(action); 
    }, 
    BackOrderQty :function(component, event) { 
        var partNumber = component.get("v.partnumber1");
        var action=component.get('c.fectchBackOrderQty');
        action.setParams({
            "partNum" : component.get("v.partnumber1")
        });
        action.setCallback(this, function(response){
            var responsevalue = response.getReturnValue();
            component.find("BackOrderQty").set("v.value", responsevalue);
        });
        $A.enqueueAction(action);
    },
    showError : function(component, event, Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": Message
        });
        toastEvent.fire();
        component.set("v.spinner", false);
    },
    getIntransistQty :function(component, event) {   
        debugger;
        var partNumber = component.get("v.partnumber1");
        var action=component.get('c.fectchTransistQuantity');
        action.setParams({
            "partNum" : component.get("v.partnumber1")
        });
        action.setCallback(this, function(response){
            var responsevalue = response.getReturnValue();
            component.find("intransitqty").set("v.value", responsevalue);
            //console.log('In Transist'+responsevalue);
        });
        $A.enqueueAction(action);
        
    },
    getCurrentstock :function(component, event) {   
        debugger;
        var partNumber = component.get("v.partnumber1");
        var action=component.get('c.OemCurrentStock');
        action.setParams({
            "partNum" : component.get("v.partnumber1")
        });
        action.setCallback(this, function(response){
            var responsevalue = response.getReturnValue();
            component.find("currentstock").set("v.value", responsevalue);
            //console.log('In Transist'+responsevalue);
        });
        $A.enqueueAction(action);
        
    },
    getOrderAmountfunction : function(component, event){
        
        var recid = component.get("v.OrderId");
         var action = component.get("c.getOrderAmount");
            action.setParams({
                "recordId" : component.get("v.OrderId")
            });       
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    component.set('v.potype',storeResponse.PSA_PoType__c);
                    var potype=storeResponse.PSA_PoType__c;
                      if(potype=='VCO Order'){
                        component.set('v.codedpart',true);
                    }
                    
                    
                }
            });
            $A.enqueueAction(action);
    },
})