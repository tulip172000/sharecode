({
	getndpvalue : function(component, event,helper) {
        var partnumber;
        if(partnumber == undefined)
        	partnumber = component.get("v.selectedLookUpRecord.PSA_Product__r.PSA_Part_Number__c");
        if(partnumber == undefined)
        	partnumber = component.get("v.selectedLookUpRecordDesc.PSA_Product__r.PSA_Part_Number__c");
        
		var action = component.get("c.getnetdealerprice");
            action.setParams({
                "partno" : partnumber
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    if(partnumber == undefined)
                    	component.set("v.ndp", "");
                    else
                        component.set("v.ndp", response.getReturnValue());
                }
            });
            $A.enqueueAction(action);
	},
    
    getavailablestockhelper : function(component, event,helper, partnumber, type){
        var action = component.get("c.getavailablestock");
        action.setParams({
            "partno" : partnumber
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                if(partnumber == undefined)
                    component.find("availablestock").set("v.value", "");
                else{
                    if(type == "pname")
                		component.find("availablestock").set("v.value", response.getReturnValue()); 
                    else if(type == "pdesc")
                        component.find("availablestockdesc").set("v.value", response.getReturnValue()); 
                	else
                        component.set("v.availabletransferstock", response.getReturnValue());                         
                }
            }
        });
        $A.enqueueAction(action);        
    },
    
    reduceindentvaluehelper : function(component, event,helper) {        
        var indentval = component.find("indentvalue").get("v.value");        
        var calctotalindentvalues = component.getEvent("reduceindenttotalvalues");
        calctotalindentvalues.setParams({
            "OemId" : indentval
        });
        calctotalindentvalues.fire();
    },
    
    calcindentvaluehelper : function(component, event, helper) {
		var indentqty = component.find("indentqty").get("v.value");
        var ndp = component.find("unitndp").get("v.value"); 
        var iqty = component.find("indentqty");
        if(indentqty != "" && indentqty != null){
        $A.util.addClass(iqty,"bordernone");
        $A.util.removeClass(iqty,"bordercolor");
        component.set("v.indenterrmsg", "");
        }
        else{
        	/*$A.util.removeClass(iqty,"bordernone");
        	$A.util.addClass(iqty,"bordercolor");*/
            component.set("v.indenterrmsg", "Please enter indent qty");
        }
        component.find("indentvalue").set("v.value", indentqty*ndp);
        component.set("v.partdetail.totalindentvalue", indentqty*ndp);
        var calctotalindentvalues = component.getEvent("indenttotalvalues");            
            calctotalindentvalues.fire();
        
        /*var minorder = component.find("minorderlevel").get("v.value");
        var maxorder = component.find("maxorderlevel").get("v.value");
		if(indentqty < minorder || indentqty > maxorder){
            var message = 'Your indent qty sould not be greater than max order level and lesser than min order level!';
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": message
            });
            toastEvent.fire();
        } */   
        
    },
    
    showToast : function(component,event,Message,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": Message,
            "type": type
        });
        toastEvent.fire();  
    }
})