({
    doInit : function(component, event, helper) {
      //  debugger;      
        var action = component.get("c.fetchLoginUserDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var userResponse = response.getReturnValue();
                component.set("v.userInfo", userResponse);              
            }
            
        });
        $A.enqueueAction(action);
        
    },	
    onHomeOption : function(component, event, helper) {
        component.set("v.dealerHome", true);
        component.set("v.vehicleProcurement", false);
        component.set("v.partsProcurement", false); 
        component.set("v.AfterSales", false);
        component.set("v.Sales", false);
        component.set("v.learning", false); 
    },    
    onVehicleOption : function(component, event, helper) {
        component.set("v.vehicleProcurement", false);
        component.set("v.dealerHome", false);	
        component.set("v.vehicleProcurement", true);
        component.set("v.partsProcurement", false); 
        component.set("v.AfterSales", false); 
        component.set("v.Sales", false); 
        component.set("v.learning", false); 
    },
    onLearningOption : function(component, event, helper) {
        component.set("v.vehicleProcurement", false);
        component.set("v.dealerHome", false);	
        component.set("v.vehicleProcurement", false);
        component.set("v.partsProcurement", false); 
        component.set("v.AfterSales", false); 
        component.set("v.Sales", false); 
        component.set("v.learning", true); 
    },
    onPartsOption : function(component, event, helper) {
         component.set("v.partsProcurement", false); 
        component.set("v.dealerHome", false);
        component.set("v.vehicleProcurement", false);
        component.set("v.partsProcurement", true); 
        component.set("v.AfterSales", false); 
        component.set("v.Sales", false); 
        component.set("v.learning", false); 
    },
    onServiceOption : function(component, event, helper) {
        component.set("v.AfterSales", false);
        component.set("v.dealerHome", false);
        component.set("v.vehicleProcurement", false);
        component.set("v.partsProcurement", false); 
        component.set("v.AfterSales", true); 
        component.set("v.Sales", false); 
        component.set("v.learning", false); 
    },
    onSalesOption : function(component, event, helper) {
        component.set("v.Sales", false); 
        component.set("v.dealerHome", false);
        component.set("v.vehicleProcurement", false);
        component.set("v.partsProcurement", false); 
        component.set("v.AfterSales", false); 
        component.set("v.Sales", true); 
        component.set("v.learning", false); 
    },
    showMyAccount : function(component, event, helper) {
        component.set("v.showMyAccount", true); 
    },
    openUserDetails : function(component, event, helper) {
        var userId = component.get("v.userInfoId"); 
        window.open('/dmsindia/s/profile/'+userId,'_top');
    },
    openNav : function(component, event, helper) {
        document.getElementById("sideNavigation").style.width = "180px";
        document.getElementById("sideNavigation").style.opacity = "1";
        document.getElementById("sideNavigation").style.visibility = "visible";
        document.getElementById("content-wrapper").style.marginLeft = "180px";
        $("#sideNavigationIcons").css("display","none");
        $("#hamburger-menu").css("display","none");
    },
    closeNav : function(component, event, helper) {
        document.getElementById("sideNavigation").style.width = "0";
        document.getElementById("sideNavigation").style.opacity = "0";
        document.getElementById("sideNavigation").style.visibility = "hidden";
        document.getElementById("content-wrapper").style.marginLeft = "60px";
        $("#sideNavigationIcons").css("display","block");
        $("#hamburger-menu").css("display","block");
    },
    handlevalidateMenu : function(component, event, helper) {
       // debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
          var defaultItem = event.getParam("defaultItem");
        var Vpvalue = component.get("v.vehicleProcurement"); 
        if(validationItem == "Sales" && defaultItem == true){
            component.set("v.vehicleProcurement", false);
            component.set("v.partsProcurement",false );
            component.set("v.AfterSales", false);
            component.set("v.Sales", true);
            component.set("v.learning", false);
        }
        if(validationItem == "AfterSales"  && defaultItem == true){
            component.set("v.vehicleProcurement", false);
            component.set("v.partsProcurement", false);
            component.set("v.AfterSales", true);
            component.set("v.Sales", false);
            component.set("v.learning", false);
        }
        
        if(validationItem == "partsProcurement"  && defaultItem == true){
            component.set("v.vehicleProcurement", false);
            component.set("v.partsProcurement", true);
            component.set("v.AfterSales", false);
            component.set("v.Sales", false);
            component.set("v.learning", false);
        }
        if(validationItem == "vehicleProcurement"  && defaultItem == true){
            component.set("v.vehicleProcurement", true);
            component.set("v.partsProcurement", false);
            component.set("v.AfterSales", false);
            component.set("v.Sales", false);
            component.set("v.learning", false);
        }
        if(validationItem == "learning"  && defaultItem == true){
            component.set("v.vehicleProcurement", false);
            component.set("v.partsProcurement", false);
            component.set("v.AfterSales", false);
            component.set("v.Sales", false);
            component.set("v.learning", true);
        }
        
    },
})