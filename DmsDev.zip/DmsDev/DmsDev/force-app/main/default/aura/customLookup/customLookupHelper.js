({
	searchHelper : function(component,event,getInputkeyWord) {
       //debugger;
     var action = component.get("c.fetchLookUpValues");
        var objectAPIName = component.get("v.objectAPIName");
        
        var query = '';
        if(component.get("v.customQuery"))
            query = component.get("v.query");       
      // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'ObjectName' : component.get("v.objectAPIName"),
            'query' : query
                      });
      // set a callBack    
        action.setCallback(this, function(response) {
          $A.util.removeClass(component.find("mySpinner"), "slds-show");
            var state = response.getState();
           
            if (state === "SUCCESS") {
              
                var storeResponse = response.getReturnValue();
        
              // if storeResponse size is equal 0 ,display No Result Found... message on screen.                }
                if (storeResponse.length == 0) {
                    component.set("v.Message", 'No Result Found...');
                } else {
                    component.set("v.Message", '');
                }
                // set searchResult list with return value from server.
                component.set("v.listOfSearchRecords", storeResponse);
                    var searchresults = component.get("v.listOfSearchRecords");
                
                    const result = [];
                    const map = new Map();
                    for (const item of searchresults) {
                        if(item.PSA_Product__r.PSA_Part_Number__c != ""){
                            if(!map.has(item.PSA_Product__r.PSA_Part_Number__c)){
                                map.set(item.PSA_Product__r.PSA_Part_Number__c, true);
                                result.push(item);
                            }
                        }
                        else{
                            if(!map.has(item.PSA_Dealer_Parts_Association__r.PSA_Part_Number__c)){
                                map.set(item.PSA_Dealer_Parts_Association__r.PSA_Part_Number__c, true);
                                result.push(item);
                            }
                        }
                    }
                    if(result.length > 0){
                        if(component.get("v.objectAPIName") == 'PSA_BinPosition__c' && result.length > 5){
                            result.splice(5,result.length);
                            component.set("v.listOfSearchRecords", result);
                        }
                        else{
                            component.set("v.listOfSearchRecords", result);
                        }
                        
                    }
                
            }
 
        });
      // enqueue the Action  
        $A.enqueueAction(action);
    
	},
    
})