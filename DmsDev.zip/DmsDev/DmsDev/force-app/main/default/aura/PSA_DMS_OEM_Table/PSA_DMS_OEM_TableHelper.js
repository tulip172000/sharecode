({
    oemdata : function(component, event, helper) {
    debugger;
    var orderType = component.get("v.orderType");
    var action = component.get('c.getOrders');
    action.setParams({
        'orderType' : orderType 
    });
    action.setCallback(this, function(response){
        var state = response.getState();
        if(state == 'SUCCESS') {
            var records =response.getReturnValue();
            component.set("v.invoicescount", records.length);
            console.log('Local PO records'+JSON.stringify(records));
            component.set("v.orders", records);
            
           for(var i=0;i<records.length;i++){
            var vendorpo ='Local PO' ;
               var vendorco='Co-Dealer';
            
            if(vendorpo === records[i].PSA_PoType__c)
            {
                component.set("v.disVar", true);
                 
            }
               if(vendorpo === records[i].PSA_PoType__c)
               {
                   component.set("v.disVar1", true); 
               
        }
           }
           /* var potypec1=records.PSA_PoType__c;
            
            if(potypec1=='Local PO'){
                 component.set("v.disVar", false);
            }
            else{
                component.set("v.disVar", true);
            }*/
            component.set("v.totalSize", component.get("v.orders").length);
            component.set("v.start",0);
            var pageSize = component.get("v.pageSize");
            component.set("v.end",pageSize-1);
            var paginationList = [];
            if(response.getReturnValue().length < pageSize){
                paginationList=response.getReturnValue();
            }
            else{
                for(var i=0; i< pageSize; i++){
                    paginationList.push(response.getReturnValue()[i]); 
                } 
            }
            
            component.set('v.paginationList', paginationList);
            if(response.getReturnValue().length==0){
                component.set('v.norecords', true);
            }
            this.helperMethodPagination(component, event,'1');
            component.set("v.spinner", false);
             var icount = component.get("v.invoicescount");
            var compEvent = component.getEvent("partSupplierCount");        
                    compEvent.setParams({"Id" : icount});        
                    compEvent.fire();
        }
    });
    $A.enqueueAction(action);
},
  showSuccessToast : function(component,event,Message){
      var toastEvent = $A.get("e.force:showToast");
      toastEvent.setParams({
          "title": "Success!",
          "message": Message,
          "type": "success"
      });
      toastEvent.fire();  
  },
    	 Codealerdata : function(component, event, helper) {
           var action = component.get("c.getCodealerOrders");
    action.setCallback(this, function(response){
        var state = response.getState();
        if (state === "SUCCESS") {
            var records = response.getReturnValue();
            component.set("v.CodealerList", records);
        }
    });
    $A.enqueueAction(action);
		
	},
   helperMethodPagination : function(component, event, pageNumber){
       debugger;
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.orders").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
        if(pageNumber<=7){ 
            
            for(var i=1; i<= totalpage; i++){
              
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                  paginationPageNumb.push(i);
            }
            
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
               paginationPageNumb.push(i);
           
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
 })