({    	
    doInit : function(component, event, helper) { 
        
        helper.invoicePaymentinfo(component, event);
        helper.paymentinfo(component, event);
    },
    generateGatePass : function(component,event,helper){
        var workOrderId = component.get("v.repairOrderId")
        var recordId = event.target.id;               
        var pdfurl ='../PSA_AfterSales_GatePass?Id='+workOrderId;
        window.open(pdfurl,"_blank","width=600, height=550"); 
    },
    addNewRow : function(component, event, helper) {  
        helper.createEmptyRow(component, event);
    },
    Addpayment : function(component, event, helper) {  
        component.set('v.visiblechild',true);
        helper.createEmptyRow(component, event);
        component.set('v.visibleaddbutton',false);
        component.set('v.nopaymentrecords',false);
    },
    cancelpaymentrow : function(component, event, helper) {  
        component.set('v.visiblechild',false);
        component.set('v.visibleaddbutton',true);
        var paymentlen= component.get('v.PaymentList');
        var paylen=paymentlen.length;
        if(paylen==0 ||paylen=='' || paylen=='undefined' || paylen==null){
            component.set('v.nopaymentrecords',true);
        }
        component.set('v.paymentrowslist',[]);
    },
    removeDeletedRow : function(component, event, helper) {
        var index = event.getParam("indexVar");        
        var paymentlist = component.get("v.paymentrowslist");
        paymentlist.splice(index, 1);
        component.set("v.paymentrowslist", paymentlist);
    },
    Savepayment:function(component,event,helper){
        var isvalid = true;
        var childCmp = component.find("createpaymentrows"); 
        //helper.saverequest(component, event, helper);
        if(childCmp.length)
            for(var i=0; i<childCmp.length; i++){
                isvalid = childCmp[i].checkValidationpaymts();
                if(!isvalid){
                    return isvalid;
                }
            }
        else
            isvalid = childCmp.checkValidationpaymts();
        if(isvalid){
            debugger;
            var Amount=0;
            var isbalamount=true;
            var Balanceamt=component.get('v.balanceAmt');
            var paymentrowslist=component.get('v.paymentrowslist');
            var x;
            for(x in paymentrowslist){
                Balanceamt-= paymentrowslist[x].Payment_Amount__c;
                
            }
            
            if(Balanceamt==0 || Balanceamt>0 ){
                
                helper.saverequest(component, event, helper);
            }else{
                helper.errortoast(component, event, helper, 'Balance should not be Negative');
                
            }
            
            
        }
    },
    
    printReceiptPDF:function(component,event,helper){
        var recordId = event.getSource().get("v.value");
        var invNum = component.get("v.invoiceNumber");
        var invD = component.get("v.invoiceD");
        var invM = component.get("v.invoiceM");
        var invY = component.get("v.invoiceY");
        var invAmt = component.find("invoiceamt").get("v.value");
        var balAmt = component.find("balance").get("v.value");
        var pdfurl ='../PSA_PaymentReceiptPDF?id='+recordId+'&invAmt='+invAmt+'&balAmt='+balAmt+'&invNum='+invNum+'&invD='+invD+'&invM='+invM+'&invY='+invY;
        //+'&invNum='+invNum+'&invDat='+invDat;
        window.open(pdfurl,"_blank", "width=600, height=550"); 
    },
})