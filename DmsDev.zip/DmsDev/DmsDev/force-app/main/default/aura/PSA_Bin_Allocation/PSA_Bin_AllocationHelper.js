({
    OEMpartsmethod:function(component,event){
        var Fromrecord=component.get("v.selectedLookUpRecordfrom");
        var Fromid=Fromrecord.Id;
        var action = component.get('c.getproductlist');
        action.setParams({
            "frompartnumber": Fromid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                if(records.length>0){
                    component.set("v.productlist", records);
                }else{
                    component.set('v.submitdisable',true);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!", 
                        "message": 'there is no inventory for selected part number   ',
                        "type": "Error"
                    });
                    toastEvent.fire();  
                    
                }
            }
        });
        $A.enqueueAction(action); 
    },
    localpartsmethod:function(component,event){
        var Fromrecord=component.get("v.selectedLookUpRecordfrom");
        var Fromid=Fromrecord.Id;
        var action = component.get('c.getLocalpartsrecords');
        action.setParams({
            "frompartnumber": Fromid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                if(records.length>0){
                    component.set("v.productlist", records);
                }else{
                     component.set('v.submitdisable',true);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!", 
                        "message": 'there is no inventory for selected part number   ',
                        "type": "Error"
                    });
                    toastEvent.fire();  
                    
                }
            }
        });
        $A.enqueueAction(action); 
    },
    savebins:function(component,event){
        var Fromrecord=component.get("v.selectedLookUpRecordfrom");
        var Fromid=Fromrecord.Id;
        var binselected=component.get('v.binselected');
        var category = component.get("v.Partcategory");
        var action = component.get('c.updatebinrecords');
        action.setParams({
            "partnumberid" : Fromid,
            "partcategory" : category,
            "binsids" : binselected
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                this.showSuccessToast(component,event);
                component.set('v.submitdisable',true);
            }
        });
        $A.enqueueAction(action);
        
    },
    showSuccessToast : function(component,event){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": 'Bins allocated succesfully ',
            "type": "success"
        });
        toastEvent.fire();  
    },
    showErrorToast : function(component,event){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": 'Bins allocated failed ',
            "type": "Error"
        });
        toastEvent.fire();  
    },
    Binlistmethod:function(component,event){
        var action = component.get('c.getbinlist');
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.Binlist", records); 
            }
        });
        $A.enqueueAction(action); 
    },
    selectedpartnumberbins:function(component,event,partid){
        var action = component.get('c.getselctedpartbins');
        action.setParams({
            "partnumberid": partid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.binsrecord", records); 
            }
        });
        $A.enqueueAction(action); 
        
    }
    
})