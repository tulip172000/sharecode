({
    partchange:function(component,event,helper){ 
        var partcat = component.find("Partc").get("v.value");
        component.set("v.Partcategory",partcat);
    },
    Binchange:function(component,event,helper){
        var binselect = component.find("binc").get("v.value");
        component.set("v.binselected",binselect);
    },
    doInit:function(component,event,helper){  
        helper.Binlistmethod(component,event);
    },
    fromrecordchange:function(component,event,helper){
        var Fromrecord=component.get("v.selectedLookUpRecordfrom");
        var Fromid=Fromrecord.Id;        
        component.set('v.productlist',null);
        component.set('v.binselected','');
        component.set('v.submitdisable',true);
        if(Fromid=='' || Fromid == 'undefined' || Fromid==null){
            component.set('v.fromnumber',true);
        }else{
            component.set('v.fromnumber',false);
            helper.selectedpartnumberbins(component,event,Fromid);
            
        }
    },
    Apply:function(component,event,helper){ 
        component.set('v.submitdisable',false);
        var partcategory=component.get("v.Partcategory");
        if(partcategory=='OEM Parts')
            helper.OEMpartsmethod(component,event);
        if(partcategory=='Local Parts')
            helper.localpartsmethod(component,event);
    },
    Saverecords:function(component,event,helper){
        var isvalid=true;
        var binselected=component.get('v.binselected');
        var nameArr = binselected.split(';');
        for(var i=0;i<nameArr.length;i++){
            if(nameArr[i]=='--None--' || nameArr[i]==''){
                isvalid=false;
            } 
        }
        if(isvalid){
            helper.savebins(component,event);
        }else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "message": 'please atleast one bin record without None values ',
                "type": "Error"
            });
            toastEvent.fire(); 
        }
    },
    resetpage:function(component,event,helper){
        var partc=component.get('v.Partcategory');
        component.set('v.fromnumber',true);
        component.set('v.submitdisable',true);
        component.set('v.productlist',null);
        component.set('v.binselected',null);
        component.set('v.selectedLookUpRecordfrom','');
        if(partc=='OEM Parts'){
            var oemchild=component.find('oemparts');
            oemchild.clearpill();
            
        }else{
            var localpats=component.find('localpats');
            localpats.clearpill();
            
        }
        helper.Binlistmethod(component,event);       
    }
})