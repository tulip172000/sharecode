({
	createObjectData : function(component, event, helper) {
		var RowItemList = component.get("v.partdetails");
        RowItemList.push({
            'sobjectType ': 'PSA_Dealer_Inventory__c',
            'PSA_Product__r.PSA_Part_Number__c':'',
            'PSA_Quantity__c':'',
            'PSA_Product__r.PSA_Part_Description__c':'',
            'PSA_Product__r.PSA_Min_Inv_Level__c':'',
            'PSA_Product__r.PSA_Max_Inv_Level__c' :'',
            'id':'',
            'totalindentvalue':'',
            'PSA_Product_Part_Number__c':'',
            'PSA_BinTransfer_Reason__c':''
        });
        component.set("v.partdetails", RowItemList);
	},
    
    getfulfillmentbranchcodeshelper : function(component, event, helper) {
        var action = component.get('c.getfulfillemntbranchcodes');            
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    component.set("v.branchids", response.getReturnValue());
                    var query = 'SELECT Id, Dealer_Code__c, ShippingCity FROM Account where id IN (';
                    var newString = '\''+ component.get("v.branchids") + '\'';  
                    newString = newString.replace(",", "','");
                    newString += ')';
                    query += newString;
                    component.set("v.localquery",query);
                }
            });
        $A.enqueueAction(action);
    },
    
    calctotalindentvaluehelper : function(component, event, helper) {        
        var orderitems = component.get("v.orderlineitems");
        var totalindent = 0;
        for(var i=0; i<orderitems.length; i++){
            totalindent += orderitems[i].PSA_Indent_Value__c;
        }
        component.find("totalreqvalue").set("v.value", totalindent);
    },
    
    getorderlineitems : function(component, event, helper, oid) {
    	var action = component.get('c.getordlineitems');
            action.setParams({
                "orderid": oid
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    component.set("v.orderlineitems", response.getReturnValue());
                }
            });
        $A.enqueueAction(action);
    },
    
    saverequestordershelper : function(component, event, helper) {
        var lstofstockrequests = component.get("v.FinalStockrequestrecords");
        
        if(lstofstockrequests.length != 0){
            component.set("v.spinner", true);
            var mapofstockrequestdetails;
            mapofstockrequestdetails = {                
                "reqdate" : component.get("v.reqdate"),
                "reqbranchcode" : component.get("v.reqbranchcode"),
                "reqbranchlocation" : component.get("v.reqbranchlocation"),
                "totalreqvalue" : component.get("v.totalreqvalue"),
                "fulfilmentbranchcode" : component.get("v.selectedBranchLookUpRecord.Dealer_Code__c"),
                "fulfilmentbranchlocation" : component.get("v.selectedBranchLookUpRecord.ShippingCity"),
                "dealerremarks" : component.get("v.dealerremarks"),
                "requestedby" : component.get("v.requestedby"),
                "approvedby" : component.get("v.approvedby"),
                "approvedddate" : component.get("v.approvedddate"),
                "approvalstatus" : component.get("v.approvalstatus"),
                "approvercomments" : component.get("v.approvercomments")
            };
            var action = component.get('c.CreateStockRequest');
            action.setParams({
                "orderlineitems": lstofstockrequests,
                "stockreqdetailsmap" : mapofstockrequestdetails
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    var cmpTarget = component.find('submitbtn');
                    $A.util.addClass(cmpTarget, 'disablebtn');
                    component.set("v.spinner", false);                
                    var records =response.getReturnValue();    
                    component.set("v.transreqnumber",records);
                    component.set("v.spinner", false);
                    var message = 'StockRequest created successfully!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "success",
                        "message": message
                    });
                    toastEvent.fire();
                }
                else
                {
                    component.set("v.spinner", false);
                    var message = 'StockRequest Failed!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": message
                    });
                    toastEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
        else{
            var message = 'Please enter indent value for stockrequest!';
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": message
            });
            toastEvent.fire(); 
        }
    },
    
    TransferRequestedordershelper : function(component, event, helper) {
        var lstofstocktransfers = component.get("v.FinalStockrequestrecords");
        
        if(lstofstocktransfers.length != 0){
            component.set("v.spinner", true);            
            var action = component.get('c.TransferRequestedStock');
            action.setParams({
                "oid": component.get("v.selectedLookUpRecord.Id"),
                "orderlineitems" : lstofstocktransfers
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    var cmpTarget = component.find('transfersubmitbtn');
                    $A.util.addClass(cmpTarget, 'disablebtn');
                    component.set("v.spinner", false);                
                    var records =response.getReturnValue();    
                    component.set("v.transreqnumber",records);
                    component.set("v.spinner", false);
                    component.set("v.pdfbuttondisable", false);
                    var message = 'Stock Transferred successfully!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "success",
                        "message": message
                    });
                    toastEvent.fire();
                }
                else
                {
                    component.set("v.spinner", false);
                    var message = 'Stock Transfer Failed!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": message
                    });
                    toastEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
        else{
            var message = 'Please enter transferqty for stocktransfer!';
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "error",
                "message": message
            });
            toastEvent.fire(); 
        }
    },
    
    validatecreatestockrequestForm : function(component, event, helper){
        
        var isValid = true;        
        var reqdate = component.find("reqdate").get("v.value");
        var reqbranchcode = component.find("reqbranchcode").get("v.value");
        var reqbranchloc = component.find("reqbranchlocation").get("v.value");
        var fulbranchcode = component.find("fulfilmentbranchcode").get("v.value");        
        var fulbranchloc = component.find("fulfilmentbranchlocation").get("v.value");
        if(component.get("v.rendersearchcmp") == true){
            var transreqno = component.get("v.selectedLookUpRecord.PSA_Transfer_Request_Number__c");
            component.set("v.transreqErrmsg",'');
            $A.util.removeClass(transreqno,"disp-block");
            $A.util.addClass(transreqno,"disp-none");
            if(transreqno == 'undefined' || transreqno == '' || transreqno == null){
                isValid = false;
                component.set("v.transreqErrmsg",'Required field');
                $A.util.removeClass(transreqno,"disp-none");
                $A.util.addClass(transreqno,"disp-block");
            }
            else{
                isValid = true;
                component.set("v.transreqErrmsg",'');
                $A.util.addClass(transreqno,"disp-none");
                $A.util.removeClass(transreqno,"disp-block");
            }
        }
        component.set("v.reqdateErrmsg",'');
        $A.util.removeClass(reqdate,"disp-block");
        $A.util.addClass(reqdate,"disp-none");
        component.set("v.reqbranchcodeErrmsg",'');
        $A.util.removeClass(reqbranchcode,"disp-block");
        $A.util.addClass(reqbranchcode,"disp-none");
        component.set("v.reqbranchlocErrmsg",'');  
        $A.util.removeClass(reqbranchloc,"disp-block");
        $A.util.addClass(reqbranchloc,"disp-none");
        component.set("v.fulbranchcodeErrmsg",'');
        $A.util.removeClass(fulbranchcode,"disp-block");
        $A.util.addClass(fulbranchcode,"disp-none");
        component.set("v.fulbranchlocErrmsg",'');
        $A.util.removeClass(fulbranchloc,"disp-block");
        $A.util.addClass(fulbranchloc,"disp-none");        
        
        if(reqdate == 'undefined' || reqdate == '' || reqdate == null){
            isValid = false;
            component.set("v.reqdateErrmsg",'Required field');
            $A.util.removeClass(reqdate,"disp-none");
            $A.util.addClass(reqdate,"disp-block");
        }
        else{
            isValid = true;
            component.set("v.reqdateErrmsg",'');
            $A.util.addClass(reqdate,"disp-none");
            $A.util.removeClass(reqdate,"disp-block");
        }
        if(reqbranchcode =='undefined'|| reqbranchcode == '' || reqbranchcode == null){
            component.set("v.reqbranchcodeErrmsg",'Required field');
            $A.util.removeClass(reqbranchcode,"disp-none");
            $A.util.addClass(reqbranchcode,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.reqbranchcodeErrmsg",'');
            $A.util.addClass(reqbranchcode,"disp-none");
            $A.util.removeClass(reqbranchcode,"disp-block");
            isValid = true;
        }
        if(reqbranchloc =='undefined'|| reqbranchloc == '' || reqbranchloc == null){
            component.set("v.reqbranchlocErrmsg",'Required field');
            $A.util.removeClass(reqbranchloc,"disp-none");
            $A.util.addClass(reqbranchloc,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.reqbranchlocErrmsg",'');
            $A.util.addClass(reqbranchloc,"disp-none");
            $A.util.removeClass(reqbranchloc,"disp-block");
            isValid = true;
        }
        if((fulbranchcode == 'undefined'|| fulbranchcode == '' || fulbranchcode == null) && (component.get("v.selectedBranchLookUpRecord.Dealer_Code__c") == null || component.get("v.selectedBranchLookUpRecord.Dealer_Code__c") == undefined)){
            component.set("v.fulbranchcodeErrmsg",'Required field');
            $A.util.removeClass(fulbranchcode,"disp-none");
            $A.util.addClass(fulbranchcode,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.fulbranchcodeErrmsg",'');
            $A.util.addClass(fulbranchcode,"disp-none");
            $A.util.removeClass(fulbranchcode,"disp-block");
            isValid = true;
        }
        if(fulbranchloc == 'undefined'|| fulbranchloc == '' || fulbranchloc == null){
            component.set("v.fulbranchlocErrmsg",'Required field');
            $A.util.removeClass(fulbranchloc,"disp-none");
            $A.util.addClass(fulbranchloc,"disp-block");
            isValid = false;
        }
        else{
            component.set("v.fulbranchlocErrmsg",'');
            $A.util.addClass(fulbranchloc,"disp-none");
            $A.util.removeClass(fulbranchloc,"disp-block");
            isValid = true;
        }
        
        return isValid;
         
     },
    
     hiderequiredfield : function(component,event,helper){        
        var reqdate = component.find("reqdate").get("v.value");
        var reqbranchcode = component.find("reqbranchcode").get("v.value");
        var reqbranchloc = component.find("reqbranchlocation").get("v.value");
        var fulbranchcode = component.find("fulfilmentbranchcode").get("v.value");        
        var fulbranchloc = component.find("fulfilmentbranchlocation").get("v.value"); 
        
        if(reqdate != null || reqdate != undefined){
            component.set("v.reqdateErrmsg",'');  
            $A.util.removeClass(reqdate,"disp-block");
            $A.util.addClass(reqdate,"disp-none");
        }
        if(reqbranchcode != null || reqbranchcode != undefined){
            component.set("v.reqbranchcodeErrmsg",'');
            $A.util.removeClass(reqbranchcode,"disp-block");
            $A.util.addClass(reqbranchcode,"disp-none");
        }
        if(reqbranchloc != null || reqbranchloc != undefined){
            component.set("v.reqbranchlocErrmsg",'');
            $A.util.removeClass(reqbranchloc,"disp-block");
            $A.util.addClass(reqbranchloc,"disp-none");
        
        }
        if(fulbranchcode != null || fulbranchcode != undefined){
            component.set("v.fulbranchcodeErrmsg",'');
            $A.util.removeClass(fulbranchcode,"disp-block");
            $A.util.addClass(fulbranchcode,"disp-none");           
        }
        if(fulbranchloc != null || fulbranchloc != undefined){
            component.set("v.fulbranchlocErrmsg",'');
            $A.util.removeClass(fulbranchloc,"disp-block");
            $A.util.addClass(fulbranchloc,"disp-none");           
        }
       
    }
})