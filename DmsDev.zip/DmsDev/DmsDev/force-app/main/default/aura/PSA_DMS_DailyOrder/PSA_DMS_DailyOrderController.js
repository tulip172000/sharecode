({
	doInit : function(component, event, helper) {
        component.set("v.spinner", true);
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        var today = new Date();
        var month = today.getMonth();
        var monthName = months[month];
        var year = today.getFullYear();
        component.set("v.month", month);
        var findMonth = component.find(month);
        $A.util.removeClass(findMonth, 'disable');
        $A.util.addClass(findMonth, 'activetab');
        component.set("v.year", year);
        var halfyear = year.toString();
        component.set("v.halfyear", halfyear.slice(2));
        component.set("v.monthName", monthName);
        helper.getFirmOrder(component, event, monthName);
        helper.getPlantItems(component, event, helper);
	},
    
    handleAddDeleteRows : function(component, event, helper) {
        var brand = event.getParam("brand");
        var addDelete = event.getParam("addDelete");
        var rowNumber = event.getParam("rowNumber");
        var productId = event.getParam("productId");
        var productList = component.get("v.productList");
        var quantityList = component.get("v.quantityList");
        
        if(addDelete == "del")
            if(typeof productId !== 'undefined' && productId != "")
            {
                var index = productList.indexOf(productId);
                productList.splice(index,1);
                quantityList.splice(index,1);
            }
        
        if(brand == component.get("v.model1"))
        {
            var CitreonSE21ItemList = component.get("v.CitreonSE21ItemList");
            if(addDelete == "add")
            {
            CitreonSE21ItemList.push({
                'sobjectType': 'OrderItem',
                'Product2.PSA_Brand__c': component.get("v.model1"),
                'Product2.PSA_Variant__c': '',
                'Product2.PSA_Ext_Colour__c': '',
                'Product2.Exterior_Color__c': '',
                'Product2.Interior_Color__c': '',
                'Product2.Metallic_Non_Metallic__c':''
                
            });
            }else if(addDelete == "del")
            {
                CitreonSE21ItemList.splice(rowNumber, 1);
            }
            component.set("v.CitreonSE21ItemList", CitreonSE21ItemList);
        }else if(brand == component.get("v.model2")){
            var CitreonC84ItemList = component.get("v.CitreonC84ItemList");
            if(addDelete == "add")
            {
            CitreonC84ItemList.push({
                'sobjectType': 'OrderItem',
                'Product2.PSA_Brand__c': component.get("v.model2"),
                'Product2.PSA_Variant__c': '',
                'Product2.PSA_Ext_Colour__c': '',
                'Product2.Exterior_Color__c': '',
                'Product2.Interior_Color__c': '',
                'Product2.Metallic_Non_Metallic__c':''
                
            });
            }else if(addDelete == "del")
            {
                CitreonC84ItemList.splice(rowNumber, 1);
            }
            component.set("v.CitreonC84ItemList", CitreonC84ItemList);
            
        
        }
        
    },
    
    
    submit : function(component, event, helper) {
        component.set("v.spinner", true);
        var error = false;
        var productList = component.get("v.productList");
        var quantityList = component.get("v.quantityList");
        var SE21demoItems = component.get("v.SE21demoItems");
        var C84demoItems = component.get("v.C84demoItems");
        if(productList.length == 0 && C84demoItems.length == 0 && SE21demoItems.length == 0)
        {
            var error = true;
            var errormsg = $A.get("$Label.c.DailyOrder_Select_Model_Error");
            helper.showError(component, event, helper, errormsg);
        }
        
        if(typeof quantityList !== 'undefined' && quantityList.length > 0)
        {
            for(var i=0; i<quantityList.length; i++)
            {
                if(quantityList[i] == "" || quantityList[i] == null || quantityList[i] == 0)
                {
                    var error = true;
                    var errormsg = $A.get("$Label.c.DailyOrder_Valuable_Qty_Error");
                    helper.showError(component, event, helper, errormsg);
                }
            }
        }
        if(!error)
        {
        var action = component.get("c.saveDailyOrder");
        action.setParams({
            "productList": productList,
            "quantityList": quantityList,
            "OrderId": component.get("v.OrderId")
            });
       	action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.OrderId", value.Id);
                component.set("v.OrderStatus", value.Status);
                component.set("v.PONumber", value.OrderNumber);
                component.set("v.C84Qty", value.C84_Total_Qty__c);
                component.set("v.SE21Qty", value.SE21_Total_Qty__c);
                component.set("v.disableAll", true);
                var msg = $A.get("$Label.c.DailyOrder_Submit_Success");
               helper.showSuccess(component, event, helper, msg);
            }else{
                var msg = $A.get("$Label.c.DailyOrder_Submit_Error");
                helper.showError(component, event, helper, msg);
            }
        });
        $A.enqueueAction(action);
        }
    },
    
    handleAddProducts : function(component, event, helper) {
        var productId = event.getParam("productId");
        var orderItemQuantity = event.getParam("orderItemQuantity");
        var productList = component.get("v.productList");
        var quantityList = component.get("v.quantityList");
        var index = productList.indexOf(productId);
        if(index == -1)
        {
        productList.push(productId);
        quantityList.push(orderItemQuantity);
        }else{
            quantityList.splice(index,1,orderItemQuantity);
        }
        component.set("v.productList", productList);
        component.set("v.quantityList", quantityList);
        
    },
    
    handleremoveProducts : function(component, event, helper) {
        var productId = event.getParam("productId");
        var productList = component.get("v.productList");
        var quantityList = component.get("v.quantityList");
        
        var index = productList.indexOf(productId);
        if(index != -1)
        {
            productList.splice(index,1);
            quantityList.splice(index,1);
            component.set("v.productList", productList);
            component.set("v.quantityList", quantityList);
        }
        
    },
    
    changeSE21Div : function(component, event, helper) {
        if(!component.get("v.CitreonSE21Div"))
        {
            component.set("v.CitreonC84Div", false);
            component.set("v.CitreonSE21Div", true);
        }else
        {
            component.set("v.CitreonSE21Div", false);
        }
    },
    
    changeC84Div : function(component, event, helper) {
        if(!component.get("v.CitreonC84Div"))
        {
            component.set("v.CitreonSE21Div", false);
            component.set("v.CitreonC84Div", true);
        }else
        {
            component.set("v.CitreonC84Div", false);
        }
    },
    next : function(component, event, helper) {
        component.set("v.currTab", "Orders List");
    },
    
    openDemoVehicle : function(component, event, helper) {
        component.set("v.demoPopup", true);
        var modal = document.getElementById('myModal'); 
        modal.style.display = "block"; 
    },
    closeDemoVehicle : function(component, event, helper) {
        var modal = document.getElementById('myModal'); 
        modal.style.display = "none"; 
        component.set("v.demoPopup", false);
    },
    handleAddDeleteRowsDemo : function(component, event, helper) {
        
        var addDelete = event.getParam("addDelete");
        var rowNumber = event.getParam("rowNumber");
        var demoItems = component.get("v.demoItems");
            if(addDelete == "add")
            {
                demoItems.push({
                    'sobjectType': 'OrderItem',
                    'Product2.PSA_Brand__c': '',
                    'Product2.PSA_Variant__c': '',
                    'Product2.PSA_Ext_Colour__c': '',
                    'Product2.Exterior_Color__c': '',
                    'Product2.Interior_Color__c': '',
                    'Product2.Metallic_Non_Metallic__c':''
                    
                });
            }else if(addDelete == "del")
            {
                demoItems.splice(rowNumber, 1);
            }
        component.set("v.demoItems", demoItems);
    },
    
    AddDemoItems : function(component, event, helper) {
        component.set("v.spinner", true);
        var SE21demoItems = [];
        var C84demoItems = [];
        var OrderId = component.get("v.OrderId");
        var action = component.get("c.saveDailyOrderDemo");
        action.setParams({
            "demoMap": component.get("v.demoMap"),
            "OrderId": component.get("v.OrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var items = value.OrderItems;
                component.set("v.OrderId", value.Id);
                component.set("v.C84Qty", value.C84_Total_Qty__c);
                component.set("v.SE21Qty", value.SE21_Total_Qty__c);
                if(typeof items !== 'undefined' && items.length > 0)
                {
                    for(var i=0; i<items.length; i++)
                    {
                        if(items[i].Product2.PSA_Brand__c == component.get("v.model1"))
                            SE21demoItems.push(items[i]);
                        if(items[i].Product2.PSA_Brand__c == component.get("v.model2"))
                            C84demoItems.push(items[i]);
                    }
                }
                component.set("v.spinner", false);
                var modal = document.getElementById('myModal'); 
                modal.style.display = "none"; 
                component.set("v.demoPopup", false);
            }
            component.set("v.SE21demoItems", SE21demoItems);
            component.set("v.C84demoItems", C84demoItems);
        });
        $A.enqueueAction(action);
    },
    
})