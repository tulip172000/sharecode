({
	doInit : function(component, event, helper) {
       
        debugger;
        helper.dealerinfo(component,event,helper);
        helper.getbookinginfo(component,event,helper);
        component.set("v.symbol", "&");
       // helper.getCustomeLookUpQuery(component,event);
       
    
	},
    onTabSelect : function(component, event, helper) {
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        if(id=='Summaryinfo'){
              helper.getbookinginfo(component,event,helper);
        }
    },
 handlevalidateMenu : function(component, event, helper) {
       
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
        	component.set("v.currTab", validationItem);            
        }
    },
    
    
    
    
   /* recordChanges : function(component, event, helper) 
    {
        var selectedrec=component.get("v.selectedLookUpRecord");    
        var invoicenumber =selectedrec.Id;
      if(invoicenumber == 'undefined' || invoicenumber =='' || invoicenumber == null)
      { 
                component.set('v.RecordId',null);
                component.set("v.Orderinfo", null);
                component.set('v.accessoryquantity',null);
                component.set('v.accessoryvalue',null);
                component.set('v.fitmentstatus',null);
                component.set('v.invoicenumber',null);
                component.set('v.invoicedate',null);
                component.set('v.Allomentsatus',null);
                component.set('v.process',null);
                component.set('v.tradeStatus',null);
                component.set("v.bookingdate",null);
                component.set("v.Finaceinfo", null);
                component.set("v.finanLeaseName", null);
                component.set("v.registration", null);
                component.set("v.Insurenceinfo", null);
          
           
      }
        else
        {
          component.set('v.RecordId',invoicenumber);
          helper.getbookinginfo(component,event,helper);
        }
    },
    */
    
    handleInvoiceDetails : function(component, event, helper) {
           
            var invoicenumber = event.getParam("subStatus");
            var invoicedate = event.getParam("invoicedate");
            component.set("v.invoicenumber", invoicenumber);
            component.set("v.invoicedate", invoicedate);
        
            // component.set("v.repairOrder.PSA_Sub_status__c", listPage);
        },
    
    
})