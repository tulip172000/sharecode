({
    recordChanges : function(component, event, helper){
        var Jobcode = component.get("v.selectedjobcode");
        var Jobcodeid=Jobcode.Id;
        if(Jobcodeid == "undefined" || Jobcodeid == '' || Jobcodeid == null ){
            component.set('v.itemInstance.PSA_Labor_Description__c','');
           component.set('v.itemInstance.PSA_Repair_time__c','');
            component.set('v.itemInstance.PSA_CGST__c','');
            component.set('v.itemInstance.PSA_SGST__c','');
            component.set('v.itemInstance.PSA_IGST__c','');
            component.set('v.itemInstance.PSA_CESS__c','');
            component.set('v.itemInstance.PSA_Price_Exl_Tax__c','');
            component.set('v.itemInstance.PSA_IGST__c','');
            component.set('v.itemInstance.PSA_Total_Price__c',null);
            
             component.find('PartNumber').set('v.value','');
            component.find('partsAmount').set('v.value',null);
            component.set('v.labourdesc',true);
            
            var compEvent1 = component.getEvent("calcOTC");
            compEvent1.fire();
             
           // component.set('v.itemInstance','');
            
        }else{
            var isvalid=true;
            var labourschecklist=component.get('v.LaboursSelListEdit');
            var size = labourschecklist.length;
            var x;
            
                    for(x in labourschecklist){
                        if(labourschecklist[x].Id==Jobcodeid){
                            
                       var Message='labourNumber Already Exist' ;
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "type": "error",
                                "message": Message
                            });
                            toastEvent.fire();
                             component.getEvent("DeletelabourRowEvt").setParams({
                            "indexVar" : size-1}).fire();
                            // component.set("v.spinner", false);
                             isvalid=false;
                        }}
             if(isvalid){
            component.set('v.labourdesc',false);
            component.set('v.itemInstance.Id',Jobcodeid);
            component.set('v.itemInstance.Name',Jobcode.Name);
            component.set('v.itemInstance.PSA_Hourly_Rate__c',component.get("v.dealeCateg"));
            var hrrate = component.get("v.dealeCateg");
            component.set('v.itemInstance.PSA_Labor_Description__c',Jobcode.PSA_Labor_Description__c);
            component.set('v.itemInstance.PSA_Repair_time__c',Jobcode.PSA_Repair_time__c);
            component.set('v.itemInstance.PSA_CGST__c',Jobcode.PSA_CGST__c);
            component.set('v.itemInstance.PSA_SGST__c',Jobcode.PSA_SGST__c);
            component.set('v.itemInstance.PSA_IGST__c',Jobcode.PSA_IGST__c);
            component.set('v.itemInstance.PSA_CESS__c',Jobcode.PSA_CESS__c);
            var excltax = hrrate*Jobcode.PSA_Repair_time__c;
            component.set('v.itemInstance.PSA_Price_Exl_Tax__c',excltax);
            var taxamount = (excltax/100)*18;
            component.set('v.taxamount',taxamount);
            component.set('v.itemInstance.PSA_Total_Price__c',taxamount+excltax);
            component.find('PartNumber').set('v.value',Jobcodeid);
            var compEvent1 = component.getEvent("calcOTC");
            compEvent1.fire();
           
        }    
        }
    },
    descChanges : function(component, event, helper){
        var Jobcode = component.get("v.selectedjobDesc");
        var Jobcodeid=Jobcode.Id;
        
        
        if(Jobcodeid == "undefined" || Jobcodeid == '' || Jobcodeid == null ){
           
            component.set('v.labourname',true);
            component.set('v.itemInstance.PSA_Repair_time__c','');
            component.set('v.itemInstance.PSA_CGST__c','');
            component.set('v.itemInstance.PSA_SGST__c','');
            component.set('v.itemInstance.PSA_IGST__c','');
            component.set('v.itemInstance.PSA_CESS__c','');
            component.set('v.itemInstance.PSA_Price_Exl_Tax__c','');
            component.set('v.itemInstance.PSA_IGST__c','');
            component.set('v.itemInstance.PSA_Total_Price__c','');
            
             component.find('PartNumber').set('v.value','');
            component.find('partsAmount').set('v.value','');
            var compEvent1 = component.getEvent("calcOTC");
            compEvent1.fire();
        }else{
            var isvalid=true;
            var labourschecklist=component.get('v.LaboursSelListEdit');
            var size = labourschecklist.length;
            var x;
            
                    for(x in labourschecklist){
                        if(labourschecklist[x].Id==Jobcodeid){
                            
                       var Message='labourDescription Already Exist' ;
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "type": "error",
                                "message": Message
                            });
                            toastEvent.fire();
                             component.getEvent("DeletelabourRowEvt").setParams({
                            "indexVar" : size-1}).fire();
                            // component.set("v.spinner", false);
                             isvalid=false;
                        }}
            if(isvalid){
            component.set('v.itemInstance.Id',Jobcodeid);
            component.find('partsAmount').set('v.value',Jobcode.PSA_Total_Price__c);
            
            component.set('v.itemInstance.Name',Jobcode.Name);
            component.set('v.itemInstance.PSA_Repair_time__c',Jobcode.PSA_Repair_time__c);
            component.set('v.itemInstance.PSA_CGST__c',Jobcode.PSA_CGST__c);
            component.set('v.itemInstance.PSA_SGST__c',Jobcode.PSA_SGST__c);
            component.set('v.itemInstance.PSA_IGST__c',Jobcode.PSA_IGST__c);
            component.set('v.itemInstance.PSA_CESS__c',Jobcode.PSA_CESS__c);
            component.set('v.itemInstance.PSA_Price_Exl_Tax__c',Jobcode.PSA_Price_Exl_Tax__c);
            component.set('v.itemInstance.PSA_IGST__c',Jobcode.PSA_IGST__c);
            component.set('v.itemInstance.PSA_Total_Price__c',Jobcode.PSA_Total_Price__c);
            component.set('v.labourname',false);
            var compEvent1 = component.getEvent("calcOTC");
            compEvent1.fire();
            }
        }
    },
    addRow : function(component, event, helper){
        var compEvent = component.getEvent('AddlabourRowEvt');
        compEvent.fire();  
    },
    DeleteRow : function(component, event, helper){
        component.find('PartNumber').set('v.value',null);
        component.find('partsAmount').set('v.value','');
        var compEvent1 = component.getEvent("calcOTC");
        compEvent1.fire();
        var compEvent = component.getEvent("DeletelabourRowEvt");
        
        compEvent.setParams({
            "indexVar": component.get("v.rowIndex")
        });
        compEvent.fire();  
    }, 
})