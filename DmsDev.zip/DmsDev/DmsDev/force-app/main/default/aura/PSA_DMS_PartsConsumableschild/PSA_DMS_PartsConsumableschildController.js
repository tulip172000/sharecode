({
	preventalphabets : function(component, event, helper){
        var availablestock = component.get("v.wolineitem.availablestock");
        var issueqty = component.find("issueqty").get("v.value");
        if(issueqty > availablestock){
            helper.showtoast(component, event, helper, "Issue qty shoul dnot be greater than available stock!");
        }
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
        
    },
    
    calctotalvalue : function(component, event, helper){ 
        //component.set("v.issueerrmsg", "");
        if(component.find("astock").get('v.value') != undefined && component.find("astock").get('v.value') != "" && component.find("astock").get('v.value')!=null){
            if(component.find("issueqty").get('v.value') > component.find("astock").get('v.value')){
                helper.showtoast(component, event, 'Issue qty should not be greater than available stock qty!');
                component.find("issueqty").set("v.value", "");
                component.find("totalval").set("v.value", "");
                component.set("v.issueerrmsg", "");
            }
            else if(component.find("issueqty").get('v.value') > component.find("rqty").get('v.value')){
                helper.showtoast(component, event, 'Issue qty should not be greater than requisition qty!');
                component.find("issueqty").set("v.value", "");
                component.find("totalval").set("v.value", "");
            }
                else{
                    var iqty = component.find("issueqty").get('v.value');
                    /*var availqty = component.find("astock").get('v.value');
                    if(component.get("v.prevstockvalue") == null || component.get("v.prevstockvalue") == undefined){
                        var stockqty = component.find("astock").get('v.value');
                        component.set("v.prevstockvalue", stockqty);
                    }
                    if((iqty != null && iqty != "") || iqty == 0){
                        component.find("astock").set("v.value", parseInt(component.get("v.prevstockvalue"))-parseInt(iqty));        		
                        component.set("v.issueerrmsg", "");
                    }else{
                        component.find("astock").set("v.value", component.get("v.prevstockvalue"));
                       // component.set("v.issueerrmsg", "Required field");
                    }*/
                    var mrp = component.find("mrp").get('v.value');
                    var tval = parseInt(iqty)*parseInt(mrp);
                    component.find("totalval").set("v.value", tval);
                }
        }
        else
        {
            /*component.find("issueqty").set("v.value", "");
            if(component.get("v.prevstockvalue") > 0)
				component.find("astock").set("v.value", component.get("v.prevstockvalue"));*/
            if(component.find("astock").get("v.value") == undefined || component.find("astock").get("v.value") == null || component.find("astock").get("v.value") == "" || component.find("astock").get("v.value") == 0)
            	helper.showtoast(component, event, 'There is no available stock!');
        }
    },
    
    combinationtotalshare : function(component, event, helper){ 
        var whichOne = event.getSource().getLocalId();
        var oemshareperc = component.get('v.wolineitem.oemshare');
        var dealershareperc = component.get('v.wolineitem.dealershare');
        var customershareperc = component.get('v.wolineitem.customershare');
        var insuranceshareperc = component.get('v.wolineitem.insuranceshare');
        if(insuranceshareperc=='undefined' || insuranceshareperc==null){
             insuranceshareperc=0;
            component.find('insuranceshare').set('v.value',0);
         }

         if(customershareperc=='undefined' || customershareperc==null){
             customershareperc=0;
            component.find('dealershare').set('v.value',0);
         }
         if( dealershareperc=='undefined' || dealershareperc==null){
             dealershareperc=0;
             
             
         }
         if(oemshareperc=='undefined' || oemshareperc==null){
             oemshareperc=0;
             
         } 
        // component.set('v.sharevalue',parseInt(oemshareperc+dealershareperc+customershareperc+insuranceshareperc));
        
        if(parseInt(oemshareperc+dealershareperc+customershareperc+insuranceshareperc) > 100 ){
        	component.find(whichOne).set('v.value','');
            helper.showtoast(component, event, 'The combination of OEM, Dealer,Customer & Insurance shares must be equal to 100 percent');
        }
        if(parseInt(oemshareperc+dealershareperc+customershareperc+insuranceshareperc) < 100){
        	
            helper.showtoast(component, event, 'The combination of OEM, Dealer,Customer & Insurance shares must be equal to 100 percent');
        }
    },
        
    Savepartsconsumables : function(component, event, helper){  
        var isvalid = true;
        var wolineitemrecid = component.get('v.woid');
        var partnum = component.get('v.wolineitem.partno');
        var issuedqty = component.get('v.wolineitem.issueqty');
        var oemshareperc = component.get('v.wolineitem.oemshare');
        var dealershareperc = component.get('v.wolineitem.dealershare');
        var customershareperc = component.get('v.wolineitem.customershare');
        var insuranceshareperc = component.get('v.wolineitem.insuranceshare');
        var totalvalueprice = component.get('v.wolineitem.totalvalue');
        var singlequantityissued = [];
        singlequantityissued.push({
            'sobjectType': 'WorkOrderLineItem',
            'Id': wolineitemrecid,
            'PSA_Part_Number__c' : partnum,
            'PSA_Issued_Quantity__c': issuedqty,
            'PSA_OEM_Sharing__c': oemshareperc,
            'PSA_Dealer_Sharing__c': dealershareperc,
            'PSA_Customer_Sharing__c' : customershareperc,
            'PSA_Insurance_Sharing__c' : insuranceshareperc,
            'TotalPrice' : totalvalueprice
        }); 
        /*if(issuedqty == undefined || issuedqty == null || issuedqty == ""){
          if(issuedqty == 0){
              alert('zero');
            //component.set("v.issueerrmsg", "Required field");
            helper.showtoast(component,event,'Issue quantity should not be zero');
            isvalid = false;
          }
          else{
              alert('empty');
            //var iqty = component.find("issueqty");            
            component.set("v.issueerrmsg", "Required field");
            isvalid = false;
          }
        }*/
        
        if(issuedqty == null || issuedqty == 'undefined'){
            component.set("v.issueerrmsg", "Required field");
            isvalid = false;
        }
        else if(issuedqty == 0 )
        {
           helper.showtoast(component,event,'Issue quantity should not be zero');
           //component.set("v.issueerrmsg", "Cannot be Zero");
           isvalid = false;
        }
        else{
            component.set("v.issueerrmsg","");
            isvalid = true;
        }
        if((customershareperc == null || customershareperc == 'undefined' || customershareperc == '') && (insuranceshareperc == null  || insuranceshareperc == 'undefined' || insuranceshareperc == '') ){
            helper.showtoast(component, event, 'The combination of Customer & Insurance shares must be equal to 100 percent');
      
            isvalid = false;
        }
        else{
            
             if(insuranceshareperc=='undefined' || insuranceshareperc==null){
             insuranceshareperc=0;
            
         }

         if(customershareperc=='undefined' || customershareperc==null){
             customershareperc=0;
            
         }
         if( dealershareperc=='undefined' || dealershareperc==null){
             dealershareperc=0;
             }
         if(oemshareperc=='undefined' || oemshareperc==null){
             oemshareperc=0;
             
         } 
         if(parseInt(oemshareperc+dealershareperc+customershareperc+insuranceshareperc) > 100 || parseInt(oemshareperc+dealershareperc+customershareperc+insuranceshareperc) < 100){
        	helper.showtoast(component, event, 'The combination of Customer & Insurance shares must be equal to 100 percent');
            isvalid = false;
         }
        }
        var transferbinstoparent = component.getEvent("partsconsumablesevent");
        transferbinstoparent.setParams({
            "ordlist" : singlequantityissued,
            "listPage" : isvalid
        });
        transferbinstoparent.fire();
    }
})