({
	doInit: function(component, event, helper) {
         helper.performancetracker(component,event);
	}
})