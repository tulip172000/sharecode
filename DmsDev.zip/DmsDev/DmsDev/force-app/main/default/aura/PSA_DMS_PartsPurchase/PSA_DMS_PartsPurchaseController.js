({
    handlemonthlyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        component.set("v.currentMonthlyOrderId", currentMonthlyOrderId);
        component.set("v.orderitem", true);
        component.set("v.OEMTable", false);
    },
    handledisplayListPage : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.OEMTable", true);
            component.set("v.orderitem", false);            
        }
    }, 
    tabOEMSelected: function(component,event,helper) {
        debugger;
        var tabclick = component.get("v.selOEMTabId");
        if(tabclick == "OEMtab1"){
            component.set("v.OEMTable","true");
            component.set("v.LPDetail","false");         
        }
        if(tabclick == "OEMtab2"){
            component.set("v.LPDetail","true");
            component.set("v.OEMTable","false");
            component.set("v.orderitem","false");
        }
        
    },
    
    onTabSelect : function(component, event, helper) {           
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        
    },
     handlevalidateMenu : function(component, event, helper) {
        debugger;
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
        	component.set("v.currTab", validationItem);            
        }
    },
        
})