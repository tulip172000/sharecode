({
    doInit : function(component, event, helper)
    {
    },
    
    onTabSelect : function(component, event, helper) {         
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
        var supplierName=component.get("v.supplierName");
        component.find("vendorname").set("v.value",supplierName);
    },
        getPartRec :function(component, event, helper){
        debugger;
        var dealerList = component.get("v.dealerList");
        var vendname = component.find("vendorname").get("v.value");
        for(var i=0;i<dealerList.length;i++){
            var vendorId = component.find("vendorname").get("v.value");  
            if(vendorId === dealerList[i].PSA_Vendor__r.Name)
            {
                var vendorCode = dealerList[i].PSA_Vendor__r.PSA_Vendor_Code__c;
                break; 
            }
        }
      component.set("v.VendCode",vendorCode);
      component.set("v.supplierName",vendname);
      
    },
    validateMRP : function(component, event, helper) {
        var mrpVal = component.find("MRP").get("v.value");
        if(mrpVal<= 0){
            //  var message= 'Please Input only Numbers';
            //  helper.showErrorToast(component,event,message);
            component.find("MRP").set("v.value",'');
        }
    },
    validateprice : function(component, event, helper) {
        
        var charCode = event.getParams().keyCode;
        if ((charCode >= 1 && charCode <= 32)||(charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105)) { 
            return true;
        } 
        else{
            var message= 'Please Input only Numbers';
            helper.showErrorToast(component,event,message);
            //component.find("MRP").set("v.value",'');
        }
        
    },
    validateCGST : function(component, event, helper) {
        var cgstVal = component.find("CGST1").get("v.value");
        if(cgstVal<= 0){
            //  var message= 'Please Input only Numbers';
            //  helper.showErrorToast(component,event,message);
            component.find("CGST1").set("v.value",'');
        }
    },
    validateSGST : function(component, event, helper) {
        var sgstVal = component.find("SGST").get("v.value");
        if(sgstVal<= 0){
            //  var message= 'Please Input only Numbers';
            //   helper.showErrorToast(component,event,message);
            component.find("SGST").set("v.value",'');
        }
    },
    validateIGST : function(component, event, helper) {
        var igstVal = component.find("IGST").get("v.value");
        if(igstVal<= 0){
            //   var message= 'Please Input only Numbers';
            //   helper.showErrorToast(component,event,message);
            component.find("IGST").set("v.value",'');
        }
    },
    validateNDP : function(component, event, helper) {
        var ndpVal = component.find("NDP").get("v.value");
        if(ndpVal<= 0){
            //   var message= 'Please Input only Numbers';
            //   helper.showErrorToast(component,event,message);
            component.find("NDP").set("v.value",'');
        }
    },
    validateListprice : function(component, event, helper) {
        var listVal = component.find("ListPrice").get("v.value");
        if(listVal<= 0){
            //   var message= 'Please Input only Numbers';
            //   helper.showErrorToast(component,event,message);
            component.find("ListPrice").set("v.value",'');
        }
    },
    createrequest : function(component, event, helper) {
        debugger;
        if(helper.validatePartForm(component, event, helper)){
            var caserec=component.get('v.caseInfo');
            var gstcat=caserec.PSA_GST_Part_Tax_Category__c;
            var partcategory=caserec.PSA_Part_Category__c;
            var vendorId = component.find("vendorname").get("v.value");
           // alert('vendorId'+vendorId);
             var vendorcode=component.get('v.VendCode');
            
            var action = component.get("c.insertpartrequest");
            action.setParams({ 
                "caserecord" : caserec,
                "partcatgy" : partcategory,//component.find('partcategory').get('v.value'),
                 "vendId" :vendorId,
                "gstcatgy":gstcat,
                "vendcode":vendorcode
                //"gstcatgy" : component.find('GSTPartTaxcategory').get('v.value')
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
                    var message='Part Request submitted successfully';
                    helper.showSuccessToast(component,event,message);
                    var eventListPage = component.getEvent("gotoparent");
                    eventListPage.setParams({"listPage" : true });
                    eventListPage.fire();
                }
            });
            $A.enqueueAction(action);	
        }
    },
    onSubmit : function(component, event, helper) {
        debugger;
        var caserec=component.get('v.caseInfo');
        var caseid=caserec.Id;
        var inputpartnumber = component.find("partnumber").get("v.value");
        component.set("v.partnumbererrormsg",'');
        $A.util.removeClass(inputpartnumber,"disp-block");
        $A.util.addClass(inputpartnumber,"disp-none");
        /*    var genericvalidation=/^[a-z 0-9 A-Z]*$/;
          if(!inputpartnumber.match(genericvalidation)){
                component.set("v.partnumbererrormsg",'Please Enter Valid PartNumber');
            $A.util.removeClass(inputpartnumber,"disp-none");
            $A.util.addClass(inputpartnumber,"disp-block");  
         }*/
        if(inputpartnumber == 'undefined'|| inputpartnumber == '' || inputpartnumber == null){
            component.set("v.partnumbererrormsg",'This is a required field');
            $A.util.removeClass(inputpartnumber,"disp-none");
            $A.util.addClass(inputpartnumber,"disp-block");
        }
         var remarks = component.find("remarks").get("v.value");
        component.set("v.remarkserrmsg",'');
        $A.util.removeClass(remarks,"disp-block");
        $A.util.addClass(remarks,"disp-none");
        if(remarks == 'undefined'|| remarks == '' || remarks == null){
            component.set("v.remarkserrmsg",'This is a required field');
            $A.util.removeClass(remarks,"disp-none");
            $A.util.addClass(remarks,"disp-block");
        }else{
            var action = component.get("c.updateCaseInfo");
            action.setParams({ 
                "partNumber" : inputpartnumber,
                "remarks":remarks,
                "caseId" : caseid
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
                  //  alert(storeResponse);
                    if(storeResponse){
                        var message='part request closed successfully';
                        helper.showSuccessToast(component,event,message);
                        var eventListPage = component.getEvent("gotoparent");
                        eventListPage.setParams({"listPage" : true });
                        eventListPage.fire();
                    }else{
                        var message='Dealer Already have issued part Number closing the request ';
                        helper.showErrorToast(component,event,message);
                         var eventListPage = component.getEvent("gotoparent");
                        eventListPage.setParams({"listPage" : true });
                        eventListPage.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);	
        }
    },
    seasonal  : function(component, event, helper){
        var flag =component.get("v.flag");alert(flag);
        component.set("v.caseInfo.PSA_Seasonal_Part__c",flag);
    },
    onCancel : function(component, event, helper){
        var eventListPage = component.getEvent("gotoparent");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
    cancel : function(component, event, helper){
        var eventListPage = component.getEvent("gotoparent");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
     onReject : function(component, event, helper) {
        debugger;
        var caserec=component.get('v.caseInfo');
        var caseid=caserec.Id;
         var remarks = component.find("remarks").get("v.value");
        var inputpartnumber = component.find("partnumber").get("v.value");
        component.set("v.partnumbererrormsg",'');
        $A.util.removeClass(inputpartnumber,"disp-block");
        $A.util.addClass(inputpartnumber,"disp-none");
        component.set("v.remarkserrmsg",'');
        $A.util.removeClass(remarks,"disp-block");
        $A.util.addClass(remarks,"disp-none");
        if(remarks == 'undefined'|| remarks == '' || remarks == null){
            component.set("v.remarkserrmsg",'This is a required field');
            $A.util.removeClass(remarks,"disp-none");
            $A.util.addClass(remarks,"disp-block");
        }else{
            var action = component.get("c.updateRejectCaseInfo");
            
            action.setParams({   
                "remarks":remarks,
                "caseId" : caseid
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
                 var message='Part Request is Rejected';
                helper.showErrorToast(component,event,message);    
          var eventListPage = component.getEvent("gotoparent");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire(); 
                }
            });
            $A.enqueueAction(action);	
        }
    },
})