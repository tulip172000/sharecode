({
	dealerinfo : function(component,event,helper) {
        var action = component.get("c.getloginuserinfo");
        action.setCallback(this, function(response){
            var state = response.getState();
           
            if (state == "SUCCESS") {
                 var value = response.getReturnValue(); 
              
                if(value=='Dealer Community User')
                {
                    component.set('v.dealerprofile',false);
                }
                else
                {
                    component.set('v.dealerprofile',true);
                }
                
            }
        });
        $A.enqueueAction(action);
        
    },
})