({
	getpaymentmodevalues : function(component, event, helper){
        var action = component.get("c.getPickListValuespaymentmode");        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();                
                component.set("v.PaymentmodeList", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    
    getpaymentparticularvalues : function(component, event, helper){
        var action = component.get("c.getPickListValuespaymentparticulars");        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();                
                component.set("v.PaymentparticularsList", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
      showError : function(component, event, Message) {
          debugger;
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": Message
        });
        toastEvent.fire(); 
    }
})