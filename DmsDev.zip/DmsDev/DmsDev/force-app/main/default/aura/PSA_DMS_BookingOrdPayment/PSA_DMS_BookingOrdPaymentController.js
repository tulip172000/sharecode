({
	doInit : function(component, event, helper) {
        debugger;
        var checkUser=component.get('v.checkUser');
        if(checkUser)
        {
           component.set("v.editbtndis",true);
           component.set("v.submitbtndis",true);
        }
         helper.paymentinfo(component, event);   
         helper.Createpayment(component, event, helper);
         helper.checkBookingStatus(component, event, helper); 
        
	},
    
    addNewRow : function(component, event, helper) {  
        helper.createEmptyRow(component, event);
    },
    
    newpayment : function(component, event, helper) {  
        component.set("v.visiblechild", true); 
        helper.createEmptyRow(component, event);
        component.set("v.showbackbtn", true);
        component.set("v.submitbtndis", false);
        component.set("v.disablechkbox", false);
    },
    
    backbtn : function(component, event, helper) { 
        component.set("v.visiblechild", false); 
        component.set("v.showbackbtn", false);        
        //component.set("v.submitbtndis", true);
        component.set("v.disablechkbox", true);
        component.set("v.paymentrowslist", []);
    },
    
    removeDeletedRow : function(component, event, helper) {
        var index = event.getParam("indexVar");        
        var paymentlist = component.get("v.paymentrowslist");
        paymentlist.splice(index, 1);
        component.set("v.paymentrowslist", paymentlist);
    },
    
    decreasebalance : function(component, event, helper) {
		var sellingprice = component.find("sellingprice").get("v.value");
		var amtrec = component.find("PayAmtid").get("v.value")
		var balamt = component.get("v.balanceamount");
		var balance;
        if(amtrec > balamt){
            helper.errortoast(component, event, helper, "Please enter only due amount!");
        }
        else{
            if(balamt == null || balamt == 0){
                balance = sellingprice - amtrec;
            }
            else{
                balance = balamt - amtrec;
            }
            var balamt = component.get("v.balanceamount");
            if(amtrec == "" && amtrec == undefined )
                component.find("balAmtid").set("v.value", balamt);
            else
                component.find("balAmtid").set("v.value", balance); 
        }
        component.set("v.balanceamount", component.get("v.balanceamount")+amtrec);
		   
	},    
    
    Savepayment:function(component,event,helper){
       debugger;
         var isvalid = true;
         var childCmp = component.find("createpaymentrows"); 
        if(childCmp != undefined){
        if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                isvalid = childCmp[i].checkValidationpaymts();
                if(!isvalid){
                return isvalid;
                }
            }
        }
        else
            isvalid = childCmp.checkValidationpaymts();
        }
            if(isvalid){
            helper.saverequest(component, event, helper);
        }
    },
    checkedBalance:function(component,event,helper){
      
        
         var checkbalance = 0;
         var balancePaid = 0;
         var acessbalancePaid = 0;
         var childRecords=[];
         var i;
         var sellingprice = component.get("v.Perbalanceamount"); 
         var childCmp = component.get("v.paymentrowslist"); 
         var accessamount = component.get("v.Peraccessamount"); 
      
        var accesAmt =accessamount;
        var balamt =sellingprice;
        
        for(i in childCmp)
        {
            
        var rec = childCmp[i];
        if(rec.PSA_Particulars__c !='' && rec.PSA_Particulars__c !=undefined && rec.PSA_Particulars__c !=null && rec.Payment_Amount__c != "" && rec.Payment_Amount__c != undefined && rec.Payment_Amount__c != null)
        {
             debugger;
            balancePaid=balancePaid+rec.Payment_Amount__c;
            if(rec.PSA_Particulars__c=='Accessories')
            {
                 rec.PSA_Balance_Amount__c= accesAmt-rec.Payment_Amount__c; 
                 acessbalancePaid=acessbalancePaid+rec.Payment_Amount__c;
            }
            else{
                rec.PSA_Balance_Amount__c= balamt-rec.Payment_Amount__c; 
            }
           
        }
        balamt=sellingprice- balancePaid;
       accesAmt=accessamount- acessbalancePaid;
     
            childRecords.push(rec); 
        }component.set("v.paymentrowslist",childRecords);
       component.set("v.balanceamount",balamt);
       component.set("v.accessamount",accesAmt);
     
    }
})