({
    doInit : function(component, event, helper) {
    	var action = component.get('c.getbinlist');
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.emptybinlist", records); 
            }
        });
        $A.enqueueAction(action); 
    },
    
	onCheck : function(component, event, helper) {
        var ischecked = component.find("checkbox").get("v.value");
		component.set("v.chkbox", ischecked);   
        var sbins = component.get('v.SelectedDestinationBins');
        var tdate = component.get('v.transferdate');
        var reason = component.get('v.reasonfortransfer');
        component.set("v.selectedbinsErrmsg",'');
        $A.util.removeClass(sbins,"disp-block");
        $A.util.addClass(sbins,"disp-none");
        component.set("v.transferdateErrmsg",'');
        $A.util.removeClass(tdate,"disp-block");
        $A.util.addClass(tdate,"disp-none");
        component.set("v.reasonErrmsg",'');
        $A.util.removeClass(tdate,"disp-block");
        $A.util.addClass(tdate,"disp-none");
        component.set('v.SelectedDestinationBins', "");
        component.set('v.transferdate', "");
        component.set('v.reasonfortransfer', "");
	},
    
    validationmethod : function(component,event,helper){
        if(component.get("v.chkbox") == true){
            var sbins = component.get('v.SelectedDestinationBins');
            var tdate = component.get('v.transferdate');
            var reason = component.get('v.reasonfortransfer');
            
            component.set("v.selectedbinsErrmsg",'');
            $A.util.removeClass(sbins,"disp-block");
            $A.util.addClass(sbins,"disp-none");
            component.set("v.transferdateErrmsg",'');
            $A.util.removeClass(tdate,"disp-block");
            $A.util.addClass(tdate,"disp-none");
            component.set("v.reasonErrmsg",'');
            $A.util.removeClass(reason,"disp-block");
            $A.util.addClass(reason,"disp-none");
             
            if(sbins == 'undefined'|| sbins == '' || sbins == null){
                component.set("v.selectedbinsErrmsg",'Required');
                $A.util.removeClass(sbins,"disp-none");
                $A.util.addClass(sbins,"disp-block");
            }
            if(tdate =='undefined'|| tdate == '' || tdate == null){
                component.set("v.transferdateErrmsg",'Required');
                $A.util.removeClass(tdate,"disp-none");
                $A.util.addClass(tdate,"disp-block");
            } 
            if(reason =='undefined'|| reason == '' || reason == null){
                component.set("v.reasonErrmsg",'Required');
                $A.util.removeClass(tdate,"disp-none");
                $A.util.addClass(tdate,"disp-block");
            } 
            if(component.get("v.selectedbinsErrmsg") == 'Required'){
                var eventListPage = component.getEvent("nonvaluescheck");  
                    eventListPage.setParams({"listPage" : false});
                    eventListPage.fire();
            }
            else if(component.get("v.transferdateErrmsg") == 'Required'){
                var eventListPage = component.getEvent("nonvaluescheck");  
                    eventListPage.setParams({"listPage" : false});
                    eventListPage.fire();
            }
            else if(component.get("v.reasonErrmsg") == 'Required'){
                var eventListPage = component.getEvent("nonvaluescheck");  
                    eventListPage.setParams({"listPage" : false});
                    eventListPage.fire();
            }
            else{
            	var eventListPage = component.getEvent("nonvaluescheck");  
                    eventListPage.setParams({"listPage" : true});
                    eventListPage.fire();	        
            }
        }
    },
    
    hiderequiredfields : function(component, event, helper){
        var sbins = component.get('v.SelectedDestinationBins');
        var tdate = component.get('v.transferdate');
        var reason = component.get('v.reasonfortransfer');
        
        if(sbins != 'undefined' && sbins != '' && sbins != null){
            component.set("v.selectedbinsErrmsg",'');
            $A.util.addClass(sbins,"disp-none");
            $A.util.removeClass(sbins,"disp-block");
        }
        if(tdate !='undefined' && tdate != '' && tdate != null){
            component.set("v.transferdateErrmsg",'');
            $A.util.addClass(tdate,"disp-none");
            $A.util.removeClass(tdate,"disp-block");
        } 
        if(reason !='undefined' && reason != '' && reason != null){
            component.set("v.reasonErrmsg",'');
            $A.util.addClass(tdate,"disp-none");
            $A.util.removeClass(tdate,"disp-block");
        } 
    },
    
    SaveBinTransfer : function(component, event, helper){
            var ischecked = component.find("checkbox").get("v.value");
            component.set("v.chkbox", ischecked);
            if(ischecked){
                var binrecid = component.get('v.binId');
                var selectedbins = component.get('v.SelectedDestinationBins');
                var transferdate = component.get('v.transferdate');
                var transferreason = component.get('v.reasonfortransfer');
                var singlebin = [];
                singlebin.push({
                    'sobjectType': 'PSA_BinPosition__c',
                    'Id': binrecid,
                    'PSA_BinName__c': selectedbins,
                    'PSA_BinTransfer_Date__c': transferdate,
                    'PSA_BinTransfer_Reason__c': transferreason                    
                });   
                
                var transferbinstoparent = component.getEvent("transferbinevent");
                transferbinstoparent.setParams({"ordlist" : singlebin});
                transferbinstoparent.fire();
            }
	}
})