({
	handleSuccess : function(component, event, helper) {
		alert("Success");
	}
})