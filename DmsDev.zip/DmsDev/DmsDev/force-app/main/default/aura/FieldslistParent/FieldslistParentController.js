({
	doinit : function(component, event, helper) {
		var action = component.get("c.getlistofobjectsnames");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS'){
                var list = response.getReturnValue();
                console.log(response.getReturnValue());
                component.set('v.lstobjs', list);
            }            
            
        })
        $A.enqueueAction(action);
	},
    getselectedobjfildapiname : function(component, event, helper){
        var selectedobjectname = component.find("objpicklist").get("v.value");
        //component.set('v.objapiname', selectedobjectname);
        var childComponent = component.find("childCmp");
        childComponent.populatefieldslist(selectedobjectname);
    }
        
})