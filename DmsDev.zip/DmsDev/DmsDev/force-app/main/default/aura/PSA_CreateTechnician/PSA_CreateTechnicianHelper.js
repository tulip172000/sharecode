({
    validateTachForm : function(component, event, helper){
        
        debugger;
        var isValid = true;
       // var Level = component.find("Level").get("v.value");
       // var Title = component.find("Title").get("v.value");
        var Firstname = component.find("Firstname").get("v.value");
        var Lastname = component.find("Lastname").get("v.value");
        var MobileNo = component.find("MobileNo").get("v.value");
        var Emailid = component.find("Emailid").get("v.value");
        var addressline1 = component.find("addressline1").get("v.value");
        var Team = component.find("techn").get("v.value");
        var Position = component.find("Position").get("v.value");
        var Empid = component.find("Empid").get("v.value");
        var JobTitle = component.find("JobTitle").get("v.value");
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        
      /*  component.set("v.LevelErrmsg",'');
        $A.util.removeClass(Level,"disp-block");
        $A.util.addClass(Level,"disp-none");*/
        /*component.set("v.TitleErrmsg",'');
        $A.util.removeClass(Title,"disp-block");
        $A.util.addClass(Title,"disp-none");*/
        component.set("v.FirstnameErrmsg",'');  
        $A.util.removeClass(Firstname,"disp-block");
        $A.util.addClass(Firstname,"disp-none");
        component.set("v.LastnameErrmsg",'');
        $A.util.removeClass(Lastname,"disp-block");
        $A.util.addClass(Lastname,"disp-none");
        component.set("v.mobilenoErrorMsg",'');
        $A.util.removeClass(MobileNo,"disp-block");
        $A.util.addClass(MobileNo,"disp-none");
        component.set("v.emailErrorMsg",'');
        $A.util.removeClass(Emailid,"disp-block");
        $A.util.addClass(Emailid,"disp-none");
        component.set("v.add1ErrorMsg",' ');
        $A.util.removeClass(addressline1,"disp-block");
        $A.util.addClass(addressline1,"disp-none");
        component.set("v.TeamErrorMsg",'');
        $A.util.removeClass(Team,"disp-block");
        $A.util.addClass(Team,"disp-none");
        component.set("v.PositionErrmsg",'');
        $A.util.removeClass(Position,"disp-block");
        $A.util.addClass(Position,"disp-none");
        component.set("v.EmpIDErrorMsg",'');
        $A.util.removeClass(Empid,"disp-block");
        $A.util.addClass(Empid,"disp-none");
        component.set("v.JobtitleErrorMsg",'');
        $A.util.removeClass(JobTitle,"disp-block");
        $A.util.addClass(JobTitle,"disp-none");
        
        
       /* if(Level == '--None--'|| Level == '' || Level == null){
            isValid = false;
            component.set("v.LevelErrmsg",'This is a required field');
            $A.util.removeClass(Level,"disp-none");
            $A.util.addClass(Level,"disp-block");
        }*/
        /*if(Title =='--None--'|| Title == '' || Title == null){
            component.set("v.TitleErrmsg",'This is a required field');
            $A.util.removeClass(Title,"disp-none");
            $A.util.addClass(Title,"disp-block");
            isValid = false;
        }*/
        if(Firstname =='undefined'|| Firstname == '' || Firstname == null){
            component.set("v.FirstnameErrmsg",'This is a required field');
            $A.util.removeClass(Firstname,"disp-none");
            $A.util.addClass(Firstname,"disp-block");
            isValid = false;
        }
        if(Lastname == 'undefined'|| Lastname == '' || Lastname == null){
            component.set("v.LastnameErrmsg",'This is a required field');
            $A.util.removeClass(Lastname,"disp-none");
            $A.util.addClass(Lastname,"disp-block");
            isValid = false;
        }
        if(MobileNo == 'undefined'|| MobileNo == '' || MobileNo == null){
            component.set("v.mobilenoErrorMsg",'This is a required field');
            $A.util.removeClass(MobileNo,"disp-none");
            $A.util.addClass(MobileNo,"disp-block");
            isValid = false;
        }
        if(Emailid == 'undefined'|| Emailid == '' || Emailid == null){
            component.set("v.emailErrorMsg",'This is a required field');
            $A.util.removeClass(Emailid,"disp-none");
            $A.util.addClass(Emailid,"disp-block");
            isValid = false;
        }
        else{
            if(!Emailid.match(regExpEmailformat)){
             component.set("v.emailErrorMsg",'Please Enter a Valid Email Address');
               $A.util.removeClass(mailaddr,"disp-none");
             $A.util.addClass(mailaddr,"disp-block");
             isValid = false;
         } 
            
        }
        if(addressline1 == 'undefined'|| addressline1 == '' || addressline1 == null){
            component.set("v.add1ErrorMsg",'This is a required field');
            $A.util.removeClass(addressline1,"disp-none");
            $A.util.addClass(addressline1,"disp-block");
            isValid = false;
        }
        if(Team == '--None--'|| Team == '' || Team == null){
            component.set("v.TeamErrorMsg",'This is a required field');
            $A.util.removeClass(Team,"disp-none");
            $A.util.addClass(Team,"disp-block");
            isValid = false;
        }
        
        
        if(Position == '--None--'|| Position == '' || Position == null){
            component.set("v.PositionErrmsg",'This is a required field');
            $A.util.removeClass(Position,"disp-none");
            $A.util.addClass(Position,"disp-block");
            isValid = false;
        }
        if(Empid == 'undefined'|| Empid == '' || Empid == null){
            component.set("v.EmpIDErrorMsg",'This is a required field');
            $A.util.removeClass(Empid,"disp-none");
            $A.util.addClass(Empid,"disp-block");
            isValid = false;
        }
        if(JobTitle == '--None--'|| JobTitle == '' || JobTitle == null){
            component.set("v.JobtitleErrorMsg",'This is a required field');
            $A.util.removeClass(JobTitle,"disp-none");
            $A.util.addClass(JobTitle,"disp-block");
            isValid = false;
        }
        
        return isValid;
    },
    Techniciantable:function(component,event){
        
        var action = component.get('c.getchtechnicians');
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
               	component.set("v.techniciancount", records.length);                
                var pageSize = component.get("v.pageSize");
                component.set("v.technlist", records);
                 component.set("v.totalSize", component.get("v.technlist").length);
                    component.set("v.start",0);
                    component.set("v.end",pageSize-1);
                    var paginationList = [];
                    if(response.getReturnValue().length < pageSize){
                        paginationList=response.getReturnValue();
                    }
                    else{
                        for(var i=0; i< pageSize; i++){
                            paginationList.push(response.getReturnValue()[i]); 
                        } 
                    }
                    
                    component.set('v.paginationList', paginationList);
                	this.helperMethodPagination(component, event, '1');
            }
        });
        $A.enqueueAction(action);
        
    },
    Techtablerefresh:function(component,event){
        this.Techniciantable(component, event);
    },
    
    saveTechnician:function(component,event){
       // debugger;
        
       // var Level = component.find("Level").get("v.value");
        var Title = component.find("Title").get("v.value");
        var Firstname = component.find("Firstname").get("v.value");
        var Lastname = component.find("Lastname").get("v.value");
        var MobileNo = component.find("MobileNo").get("v.value");
        var Emailid = component.find("Emailid").get("v.value");
        var addressline1 = component.find("addressline1").get("v.value");
        var Team = component.find("techn").get("v.value");
        var Position = component.find("Position").get("v.value");
       // var active =component.get("v.uncheckvalue");
        var inactive =component.find("inactivecheckbox").get("v.value");
        var active =component.find("checkbox").get("v.value");
        var Empid = component.find("Empid").get("v.value");
        var JobTitle = component.find("JobTitle").get("v.value");
       
        var action = component.get("c.createtechnician");
        debugger;
        action.setParams({
            
            "title": Title,
            "fname" : Firstname,
            "lname": Lastname,
            "mobnumber": MobileNo,
            "Emailid": Emailid,
            "addline": addressline1,
            "team": Team,
            "position": Position,
            "active":active,
            "inactive":inactive,
            "EMpid":Empid,
            "jobtitle" : JobTitle
                       
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
            if (state === "SUCCESS") {
                if(storeResponse=='' || storeResponse==null || storeResponse=='undefined')
                {
                    this.showErrorToast(component,event);
                    this.closeBayForm(component,event);
                }
                else{
                var Message= $A.get("$Label.c.Technician_Created_Successfully");
                this.showSuccessToast(component,event,Message);
                document.getElementById("myform").style.display = "none";
                this.Techniciantable(component, event);
                this.closeBayForm(component,event);
            }
            }
           

        });
        $A.enqueueAction(action);
    },
    
    closeBayForm : function(component, event, helper) {
        debugger;
       // component.set("v.LevelErrmsg",'');
        component.set("v.TitleErrmsg",'');
        component.set("v.FirstnameErrmsg",'');
        component.set("v.LastnameErrmsg",'');
        component.set("v.mobilenoErrorMsg",'');
        component.set("v.emailErrorMsg",'');
        component.set("v.add1ErrorMsg",' ');
        component.set("v.TeamErrorMsg",'');
        component.set("v.PositionErrmsg",'');
        component.set("v.EmpIDErrorMsg",'');
        component.set("v.JobtitleErrorMsg",'');
        //component.find("Level").set("v.value", "--None--");
        component.find("Title").set("v.value", "--None--");
        component.find("Firstname").set("v.value", "");
        component.find("Lastname").set("v.value", "");
        component.find("MobileNo").set("v.value", "");
        component.find("Emailid").set("v.value", "");
        component.find("addressline1").set("v.value", "");
        component.find("Empid").set("v.value", "");
        component.find("techn").set("v.value", "--None--");
        component.find("Position").set("v.value", "--None--");
        component.find("JobTitle").set("v.value", "--None--");
        component.find("checkbox").set("v.value", false);
        document.getElementById("myform").style.display = "none";
    },
    
    
    
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
      showErrorToast : function(component,event){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": "duplicate technician",
            "type": "error"
        });
        toastEvent.fire();  
    },
    
    helperMethodPagination : function(component, event, pageNumber){
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.technlist").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
         if(pageNumber<=7){ 
            
            for(var i=1; i<= totalpage; i++){
              
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                  paginationPageNumb.push(i);
            }
            
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
               paginationPageNumb.push(i);
           
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
    fetchskillvaluePicklist: function(component, event) {
        var action = component.get("c.fetchskillvaluePicklist");
        action.setCallback(this, function(response) {
        component.set("v.skillposition", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
    fetchteamPicklist: function(component, event) {
        var action = component.get("c.fetchsteamPicklist");
        action.setCallback(this, function(response) {
        component.set("v.teampick", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
    fetchjobtitlePicklist: function(component, event) {
        var action = component.get("c.fetchsjobtitlePicklist");
        action.setCallback(this, function(response) {
        component.set("v.joblist", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }
    
})