({ 
    
    doInit : function(component, event, helper) {
        
        helper.Techniciantable(component,event);
        helper.fetchskillvaluePicklist(component, event);
        helper.fetchteamPicklist(component, event);
        helper.fetchjobtitlePicklist(component, event);
    },   
   adharvalidate  : function(component, event, helper) {
        var mobinp = component.find("MobileNo").get("v.value");
      
        if(isNaN(mobinp))
            component.find("MobileNo").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
    
    opentechForm : function(component, event, helper) {
        debugger;
        document.getElementById("myform").style.display = "block";
    },
    TechEditview : function(component, event, helper) {
        debugger;
         var target = event.getSource().get('v.value');
          component.set("v.technicianId",target);
         component.set("v.EditTech",true);
        
    },
     handleEditPage : function(component, event, helper) {
        
        component.set("v.EditTech",false);
          helper.Techtablerefresh(component,event); 
        
    },
    closeBayForm : function(component, event, helper) {
        debugger;
       // component.set("v.LevelErrmsg",'');
       helper.closeBayForm(component,event,helper); 
    },
    
    createTechnician : function(component, event, helper) {
        debugger;
        if(helper.validateTachForm(component)) {
            helper.saveTechnician(component,event);
            
        }
    },
    
         next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var technicianlist = component.get("v.technlist");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = technicianlist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var technicianlist = component.get("v.technlist");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = technicianlist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
         /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var technicianslist = component.get("v.technlist");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = technicianslist.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.Techniciantable(component, event);
    },
    techsearch: function(component, event, helper){
        debugger;
        console.log("" + event.getSource().get("v.value"));
    	var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");  
       if(pot == null || pot == 'undefined' || pot==""){
            helper.Techniciantable(component,event);
       }else{
           var action = component.get('c.technicianssearch');
        action.setParams({
            'empnumber' : pot,
          
            
        });
            action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                console.log("Inside "+state);
                component.set("v.paginationList", records);
            }
                 });
        $A.enqueueAction(action);
           
       }
   }, 
       onCreditLimit: function(component, event, helper){
        var selected = event.getSource().getLocalId();
          alert(selected);
        component.set('v.uncheckvalue',selected);
        
    },
     onactive:function(component, event, helper){
        var active=component.find("checkbox").get("v.value");
        if(active){
            component.set("v.inactivecheckbox",true);
            component.find("inactivecheckbox").set("v.value",false);
        }
        else{
             component.set("v.inactivecheckbox",false);
        }
    },
      oninactive:function(component, event, helper){
        var active=component.find("inactivecheckbox").get("v.value");
        if(active){
            component.set("v.activecheckbox",true);
            component.find("checkbox").set("v.value",false);
        }
        else{
             component.set("v.activecheckbox",false);
        }
    }
    
})