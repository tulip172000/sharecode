({
	 doInit : function(component, event, helper) {
 
         helper.partstable(component, event,'PSA_Booking_ID__r.OrderNumber',null,null,null); 
	},
    handleApplicationEvent : function(cmp, event) {
        var message = event.getParam("orderId");

        // set the handler attributes based on event data
        component.set("v.orderid",message);
    },
      bookingview : function(component, event, helper) {
          debugger;
          component.set("v.pause",true);
          var target = event.getSource().get('v.text');
          var checkedList=component.get('v.paginationList');
        var i;
        var variant;
        var nam;
        var color;
        var dat;
        var mod;
        var checkvalue = component.find("checkfor");
        var target = event.getSource().get("v.text");
        for (i   in  checkedList) {
             if(checkedList[i].bookId==target)
              { 
                component.set('v.variant', checkedList[i].variant);
                component.set('v.custName', checkedList[i].custName);
                component.set('v.color', checkedList[i].color);
                component.set('v.mod', checkedList[i].mod);
                component.set('v.planDate', checkedList[i].planDate);
                checkvalue[i].set("v.value",true);
                component.set("v.pause",true)
                helper.setTimeDisplay(component, event,checkedList,i+1);
              }else
              {
                  checkvalue[i].set("v.value",false);
              }
                 
        }  


           },
})