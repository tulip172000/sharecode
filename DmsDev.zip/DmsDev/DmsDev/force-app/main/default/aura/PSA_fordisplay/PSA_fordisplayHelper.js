({
	partstable : function(component, event,sortoption,fromdate,todate,filter) {
       
        var action = component.get('c.forDisplay');
        var i=0;
        
         action.setParams({
             "sortField" :sortoption,
             "fromdate"  :fromdate,
             "todate"    :todate,
             "filter"    :filter,
             
        })
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set('v.variant', records[i].variant);
                component.set('v.custName', records[i].custName);
                component.set('v.color', records[i].color);
                component.set('v.mod', records[i].mod);
                component.set('v.planDate', records[i].planDate);
                records[i].checkBooking=true;
                component.set('v.paginationList', records);
                debugger;
               this.setTimeDisplay(component, event,records,i);
                   }
                
            
        });
        $A.enqueueAction(action);
        
	},
    setTimeDisplay : function(component, event,records,k) 
    {
        var i=k;
        if(component.get("v.pause")){
            clearInterval(component._interval);
        }
       
       var timeset=4000;
       component._interval= setInterval(
            $A.getCallback(function() {
                if(i<records.length)
                {
                    
                component.set('v.variant', records[i].variant);
                component.set('v.custName', records[i].custName);
                component.set('v.color', records[i].color);
                component.set('v.mod', records[i].mod);
                component.set('v.planDate', records[i].planDate);
                records[i].checkBooking=true;
                debugger;
                for(var j=0;j<records.length;j++)
                {
                    
                if(j!=i)
                {
                  records[j].checkBooking=false;      
                } 
                }
                i=parseInt(i)+1;
                timeset=4000;
                component.set('v.paginationList', records);
                }
                else
                {
                i=0;
                timeset=100;
                }
           }), timeset
            ); 
        
          
    }
    
    
    /*window.setTimeout(
    $A.getCallback(function() {
alert("Ravi")
    }), 5000
);*/
})