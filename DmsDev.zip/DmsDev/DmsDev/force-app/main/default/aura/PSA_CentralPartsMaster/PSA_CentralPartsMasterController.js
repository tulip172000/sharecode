({
    doInit : function(component, event, helper) {
      //  debugger;
         helper.partstable(component, event); 
         
    },
      partsview : function(component, event, helper) {
        var target = event.getSource().get('v.value');
        var compEvent = component.getEvent("PartorderIdPass");
        compEvent.setParams({"currentMonthlyOrderId" : target });
        compEvent.fire();
   },
  next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var receiptslist = component.get("v.CentralPartList");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var receiptslist = component.get("v.CentralPartList");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
        debugger;
         /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var accountList = component.get("v.CentralPartList");//All Account List
        var start =(pagenum-1)*parseInt(pageSize);
        var end = ((pagenum-1)*parseInt(pageSize)+parseInt(pageSize))-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    }, 
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.partstable(component, event);
    },  
    
    partsearch: function(component, event, helper) { 
        debugger;   
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");   
        if(pot == null || pot == 'undefined' || pot==""){
            helper.partstable(component, event, helper);     
        }
        else
        {
            //alert(component.get("v.selectedsearchfieldvalue"));
            var action = component.get('c.searchlabourmaster');
            action.setParams({          
                'ordernumber' : pot,
                 //'selectedfield' : component.get("v.selectedsearchfieldvalue")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(""+state);
                if(state == 'SUCCESS') {               
                    var records =response.getReturnValue();
                    component.set("v.paginationList", records);   
                   
                }
            });
            $A.enqueueAction(action); 
        }
    }
    
})