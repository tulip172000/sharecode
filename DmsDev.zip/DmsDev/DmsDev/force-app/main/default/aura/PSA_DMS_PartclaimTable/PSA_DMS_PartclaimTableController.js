({
    doInit : function(component, event, helper) {
        var pagesize=component.get("v.pageSize");
        component.find("recordperpageselect").set("v.value",pagesize);
        helper.claimsdata(component, event, helper);
    },
    next : function(component, event, helper){
        var orderlist = component.get("v.orders");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = orderlist.slice(end+1,end+parseInt(pageSize)+1);
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var orderlist = component.get("v.orders");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = orderlist.slice(start-parseInt(pageSize),start);
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    currentPage: function(component, event, helper) {
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;
        var pageSize = component.get("v.pageSize");
        var orderlist = component.get("v.orders");
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var c=end+1;
        var paginationList = orderlist.slice(start,end+1);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));
    },
    
    setrecordsizeperpage: function(component, event, helper){
        debugger;
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.oemdata(component, event, helper);
    },
     onclickPO : function(component, event, helper) {
        debugger;
        var target = event.getSource().get('v.value');
          var compEvent = component.getEvent("ClaimDetailPage");
          compEvent.setParams({"currentMonthlyOrderId" : target});
          compEvent.fire();
     }
})