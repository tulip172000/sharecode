({
	doInit : function(cmp, event, helper) {
		window.setTimeout(
    $A.getCallback(function() {
        helper.helperMethod(cmp, event, helper);
        // check component.isValid() if you want to work with component
    }), 3000
);
        
	}
})