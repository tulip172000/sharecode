({
	 getbookinginfo : function(component,event,helper) {
         debugger;
        var action = component.get("c.getorderid");
         var record=component.get("v.RecordId");
         
         
        action.setParams({
            "orderId" : component.get("v.RecordId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var orderno=value;
               
               
              //  alert('orderid'+orderno);
             
                component.set("v.ordernum",orderno);
               // var ordedetails=value.orderinfo;
                 //component.set("v.Orderinfo", ordedetails);
                            }
        });
        $A.enqueueAction(action);
    },
    
    fetchVehicleDetails : function(component, event) {
		
         //var orderId=  component.get("v.");
      var bookingid=component.get("v.RecordId");
       // alert('@@@@@@@@@@@'+bookingid);
         var action = component.get("c.fetchVehDetails");
        action.setParams({
            "orderId": bookingid,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            		
            var values=response.getReturnValue();
            if(state=="SUCCESS"){
            //component.set("v.vehId", values.Id);
            component.set("v.vehDetails", response.getReturnValue());
            }
	});
           $A.enqueueAction(action);
    },
    
    
    getcustomerinfo : function(component, event, helper){
        var bookingid=component.get("v.RecordId");
         var action = component.get("c.getCustdetails");
        
        action.setParams({
                "orderId" :bookingid
            });
        
          action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
       
            component.set("v.custDetails", response.getReturnValue());
            }
	});
           $A.enqueueAction(action);
    },
    
    fordeliverychecklist : function(component, event, helper){
    var bookingid=component.get("v.RecordId");
         var action = component.get("c.fordeliverychecklist");
        action.setParams({
                "orderId" :bookingid
            });
         action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
       
            component.set("v.pdistatus", response.getReturnValue());
            }
	});
           $A.enqueueAction(action);
    }
})