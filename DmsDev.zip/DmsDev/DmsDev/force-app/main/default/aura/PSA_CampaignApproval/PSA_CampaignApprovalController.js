({
	doInit: function(component, event, helper) {
        
    },
    Createvendor:function(component,event,helper){
        component.set("v.newvendor", true);
        component.set("v.listvendor", false);
        
    },
    handledisplayListPage : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.listvendor", true);
             component.set("v.newvendor", false);
            component.set("v.newissue", false);
        }
    },
    handledisplayListPageView : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.listvendor", true);
             component.set("v.newvendorform", false);
            
        }
    },
    handlemonthlyOrderIdPass : function(component, event, helper) {
        var currentMonthlyOrderId = event.getParam("currentMonthlyOrderId");
        component.set("v.RecordId", currentMonthlyOrderId);
    	component.set("v.newvendorform", true);
        component.set("v.listvendor", false);
       
    },
      cancelNewpurchase: function(component, event, helper) {
        component.set("v.selectedStep","Draft");
        component.set("v.NewOEM",false);
        component.set("v.OEMTable",true);
        component.set("v.EditOEM",false);
        
    },
   
})