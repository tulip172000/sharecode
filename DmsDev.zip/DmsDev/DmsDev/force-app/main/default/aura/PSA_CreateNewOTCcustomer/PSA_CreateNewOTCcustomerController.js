({
    
    doInit: function(component, event, helper) {
        
        helper.getaccrec(component, event, helper);
        //  helper.getautocustId(component, event, helper);
        // helper.credlimitdisable(component, event, helper);
        var action = component.get("c.getStateval");
        action.setCallback(this, function(response) {
            component.set("v.StateList", response.getReturnValue());
        });
        $A.enqueueAction(action);
    },  
    
    getdistrict : function(component, event, helper){
        debugger;
        var selectstate = component.find("state").get("v.value");
        var action = component.get("c.getdistrictmethod");
        action.setParams({ 
            "selState" : selectstate,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.districtList", response.getReturnValue());
                console.log('response.getReturnValue()'+response.getReturnValue())
            }
        });
        $A.enqueueAction(action);	
    },
    
    /*onCreditLimit: function(component, event, helper){
        
        var selected = event.getSource().get("v.label");
        component.set("v.credLimit",selected);
    },*/
    
    onCreditLimit: function(component, event, helper){
         
        var selected = event.getSource().getLocalId();
        var selectedName = event.getSource().get("v.name");
         
        if(selectedName=='others'){
            component.find("No").set("v.value",false);
        }
        if(selectedName=='others1'){
         component.find("Yes").set("v.value",false);   
        }
        component.set('v.credLimit',selected);
        
        
        
    },
    
     
    
    
    validatepin  : function(component, event, helper) {
        var inp = component.find("pin").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(inp))
            component.find("pin").set("v.value", inp.substring(0, inp.length - 1));
    },
    
    phonevalidate  : function(component, event, helper) {
        var mobinp = component.find("phno").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(mobinp))
            component.find("phno").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
    
    altphonevalidate  : function(component, event, helper) {
        var mobinp = component.find("altphno").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(mobinp))
            component.find("altphno").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
    
    creditLimitvalidate  : function(component, event, helper) {
        var credlim = component.find("limit").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(credlim))
            component.find("limit").set("v.value", credlim.substring(0, credlim.length - 1));
    },
    gstvalidate  : function(component, event, helper) {
        var gstinp = component.find("gst").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(gstinp))
            component.find("gst").set("v.value", gstinp.substring(0, gstinp.length - 1));
    },
    uinvalidate  : function(component, event, helper) {
        var uininp = component.find("uin").get("v.value");
        //var inp = component.get('v.inputN');
        if(isNaN(uininp))
            component.find("uin").set("v.value", uininp.substring(0, uininp.length - 1));
    },
    
    handleSave: function(component, event, helper) {
        
        if(helper.validateCustomerForm(component)) {
            debugger;
            var custSeg = component.find("CustSeg").get("v.value");
            //   var custId = component.find("custId").get("v.value");
            
            var fname = component.find("Fname").get("v.value");
            var lName = component.find("Lname").get("v.value");
            var gender = component.find("gender").get("v.value");
            var occupation = component.find("occ").get("v.value");
            var institution = component.find("institute").get("v.value");
            var organisation = component.find("org").get("v.value");
            var gst = component.find("gst").get("v.value");
            var uin = component.find("uin").get("v.value");
            var pan = component.find("pan").get("v.value");
             var vin = component.find("vin").get("v.value");
            var addr1 = component.find("addressline1").get("v.value");
            var addr2 = component.find("addressline2").get("v.value");
            var district = component.find("city").get("v.value");
            var state = component.find("state").get("v.value");
            var country = component.find("country").get("v.value");
            var pincode = component.find("pin").get("v.value");
            var phone = component.find("phno").get("v.value");
            var alternateph = component.find("altphno").get("v.value");
          //  var actstatus = component.find("activestatus").get("v.value");
            var crdLimit = component.get("v.credLimit");  
            /* if(crdLimit=="Yes")
               {
                   component.set("v.enablecredlimit",true);
               }
               else{
                   component.set("v.enablecredlimit",false);
               }*/
               var email = component.find("email").get("v.value");
               var creditlimit = component.find("limit").get("v.value");  
               var recId=component.get("v.accrecId");
               var action = component.get("c.CreateCustomer"); 
               action.setParams({
                   "Seg"   	: custSeg, 
                   "Fname" 	:fname,
                   "Lname" 	:lName,
                   "gender"    :gender,
                   "occupation":occupation,
                   "institue"  :institution,
                   "org"      	:organisation,
                   "gst" 		: gst,
                   "uin" 		: uin,
                   "Pan"	    : pan,
                   "Addr1"  	: addr1,
                   "Addr2"     : addr2,
                   "City"  	: district,
                   "State"  	: state,
                   "Country"   : country,
                   "Pin"  		: pincode,
                   "Phone"     : phone,
                   "AltPhone" : alternateph,
                   "Email"     : email,
                   "yesno"  	: crdLimit,
                   "Credit"	:creditlimit,
                   "RectypeId" : recId,
                   "activestatus" :false,
                   "vinnumber" :vin,
                   
               });
               action.setCallback(this, function(response) {
                   var result=response.getState();
                   console.log('save status  >>>>'+result);
                   if(result  === "SUCCESS"){
                       var cusNo = response.getReturnValue();
                      
                       if(cusNo=='' || cusNo==null || cusNo=='undefined'){
                         helper.showError(component, event, helper);  
                       }else{ 
                           helper.showSuccessToast(component, event, helper);
                           component.set("v.autocustId",cusNo);
                           component.set("v.disable",true);
                                      component.set("v.disablebutton",true);
                           // component.find("123button").set("v.disablebutton",true);
                       }
                       //    component.set("v.disable",true);
                          
                   }
                   /*else
            {
            var Message= $A.get("$Label.c.Local_Purchase_Order_Error");
            helper.showError(component,event,Message);
           }*/
                
            });
               $A.enqueueAction(action); 
               
           }
           else
           {
               helper.showvalidationToast(component, event, helper);
           }
        
       },
    
    oncancel:function(component, event, helper) {
        debugger;
        var custId = component.find("custId").set("v.value",'');
        var custseg = component.find("CustSeg").set("v.value",'--Select--');
        
        var fname = component.find("Fname").set("v.value",'');
        var lName = component.find("Lname").set("v.value",'');
        
          var gender = component.find("gender").set("v.value",'Male');
          
        
        var occupation = component.find("occ").set("v.value",'');
        var institution = component.find("institute").set("v.value",'');
        var organisation = component.find("org").set("v.value",'');
        var gst = component.find("gst").set("v.value",'');
        var uin = component.find("uin").set("v.value",'');
        var pan = component.find("pan").set("v.value",'');
        var addr1 = component.find("addressline1").set("v.value",'');
        var addr2 = component.find("addressline2").set("v.value",'');
        var district = component.find("city").set("v.value",'');
        var state = component.find("state").set("v.value",'');
        var country = component.find("country").set("v.value",'');
        var pincode = component.find("pin").set("v.value",'');
        component.find("phno").set("v.value",'');
        component.find("altphno").set("v.value",'');
       // component.find("activestatus").set("v.value",'false');
        component.find("email").set("v.value",'');
        component.find("limit").set("v.value",'');
        component.find("No").set("v.value",true);
        component.find("Yes").set("v.value",false);
        
        component.set("v.Address1ErrorMsg","");
        component.set("v.CreditlimitErrorMsg","");
        component.set("v.EmailErrorMsg","");
        component.set("v.AltmobileErrorMsg","");
        component.set("v.PhoneErrorMsg","");
        component.set("v.PincodeErrorMsg","");
        component.set("v.CountryErrorMsg","");
        component.set("v.StateErrorMsg","");
        component.set("v.DistrictErrorMsg","");
        component.set("v.Address2ErrorMsg","");
        component.set("v.PANErrorMsg","");
        component.set("v.UINErrorMsg","");
        component.set("v.GSTINErrorMsg","");
        component.set("v.vinErrorMsg","");
        component.set("v.OrganizationErrorMsg","");
        component.set("v.InstitutionErrorMsg","");
        component.set("v.OccupationErrorMsg","");
        component.set("v.GenderErrorMsg","");
        component.set("v.LastNameErrorMsg","");
        component.set("v.FirstNameErrorMsg","");
        component.set("v.CustomerIdErrorMsg","");
        component.set("v.CustomerSegmentErrorMsg",""); 
        component.set("v.disable",false);
        component.find("123button").set("v.disabled",false);
        component.find("vin").set("v.disabled",'');

    }
    
})