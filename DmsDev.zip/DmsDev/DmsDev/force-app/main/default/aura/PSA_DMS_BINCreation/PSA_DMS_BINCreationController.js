({
	doInit : function(component, event, helper) {
		helper.createObjectData(component, event);
	},
    
    handleAddDeleteRowsDemo : function(component, event, helper) {
        
        var addDelete = event.getParam("addDelete");
        var rowNumber = event.getParam("rowNumber");
        var BinItems = component.get("v.BinRecordItems");
            if(addDelete == "add")
            {
                BinItems.push({
                    'sobjectType': 'PSA_BinStorage__c',
                    'Name': ''                    
                });
                component.set("v.BinRecordItems", BinItems);
            }else if(addDelete == "del")
            {
                //BinItems.splice(rowNumber, 1);
                var index = event.getParam("rowNumber");        
                var BinItems = component.get("v.BinRecordItems");
                BinItems.splice(index, 1);        
                component.set("v.BinRecordItems", BinItems);
            }
        
    },
    
    showBinillustration: function(component, event, helper) {
      document.getElementById("myModal").style.display = "block";  
    },
    
    closeBinIllustration: function(component, event, helper) {
      document.getElementById("myModal").style.display = "none";  
    }
})