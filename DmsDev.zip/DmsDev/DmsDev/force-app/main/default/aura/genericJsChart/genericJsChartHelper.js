({
    graph1 : function(component, event, helper, variant) {
        var keys = variant.keys();
        var values = variant.values();
        var label = [];
        var quantity = [];
        var totalquantity = 0;
        var color = ['#47acb1', '#f9aa7b', '#ffcc99'];
        var percentage = [];
        for(var i=0; i<variant.size; i++)
        {
            label.push(keys.next().value);
            quantity.push(values.next().value);
        }
        var el = component.find('colorChart').getElement();
        var ctx = el.getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: label,
                datasets: [
                    {
                        label: "Payments History",
                        backgroundColor: color,
                        data: quantity
                    }
                ]
            },
            options: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        boxWidth: 10
                    }
                }
            },
        });
        
    },
    
    graph2 : function(component, event, helper) {
        
        var sc21obj = component.get("v.sc21obj");
        var sc21com = component.get("v.sc21com");
        var scDiffp = 0;
        var scDiffn = 0;
        if(sc21obj>sc21com)
            scDiffp = sc21obj-sc21com;
        else
            scDiffn = sc21com-sc21obj;
        var c84obj = component.get("v.c84obj");
        var c84com = component.get("v.c84com");
        var c84Diffp = 0;
        var c84Diffn = 0;
        if(c84obj>c84com)
            c84Diffp = c84obj-c84com;
        else
            c84Diffn = c84com-c84obj;
        
         var label = ['Objective','Commitment', 'Variance','Excess','Objective','Commitment', 'Variance','Excess'];
        var quantity = [sc21obj,sc21com,scDiffp,scDiffn,c84obj,c84com,c84Diffp,c84Diffn];
       var color = ['#2874A6','#85C1E9', '#BFC9CA','#82E0AA','#F0B27A','#F5CBA7', '#BFC9CA','#82E0AA']; //c9222b  77a158
       
       
    //    var color1 = ['#00bda5','#f9aa7b','#add5d7', '#a5a8aa','#00bda5','#f9aa7b','#add5d7', '#a5a8aa']; //c9222b  77a158
    //    var color2 = ['#00bda5','#f9aa7b','#add5d7', '#a5a8aa','#00bda5','#f9aa7b','#add5d7', '#a5a8aa'];
        
        
    //    var quantity2 = [10,8,2,0,0,0,0,0];
    //    var quantity1 = [50,35,15,0,10,0,50,40];
        
     //   var label = ['Objective','Commitment', 'Variance','Excess','Excess', 'Variance','Commitment','Objective'];
    //    var color1 = ['#f9aa7b','#add5d7', '#a5a8aa','#00bda5','#00bda5', '#a5a8aa','#add5d7','#f9aa7b']; //c9222b  77a158
     //   var color2 = ['#f9aa7b','#add5d7', '#a5a8aa','#00bda5','#f9aa7b','#add5d7', '#a5a8aa','#00bda5'];
        
     //   var quantity2 = [10,8,2,0,0,0,0,0];
     //   var quantity1 = [6,3,3,0,4,5,0,1];
        
    //    var label = ['Objective','Commitment', 'Variance','Excess','Objective','Commitment', 'Variance','Excess'];
         //var color1 = ['#2874A6','#85C1E9', '#BFC9CA','#82E0AA','#F0B27A','#F5CBA7', '#BFC9CA','#82E0AA']; //c9222b  77a158
    //    var color1 = ['#f9aa7b','#add5d7', '#a5a8aa','#00bda5','#f9aa7b','#add5d7', '#a5a8aa','#00bda5'];
    //   var borderColor = ['#35586C','#35586C','#35586C','#35586C','#FF664D','#FF664D','#FF664D','#FF664D'];
        
        var el = component.find('objCommChart').getElement();
        var ctx = el.getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: label,
                datasets: [
                    {
                        label: "Payments History",
                        backgroundColor: color,
                        data: quantity
                    }
                ]
            },
            options: {
                legend: {
                    display: false
                }
            }
        });
    },
    
    variantGraph : function(component, event, helper, label, v) {
        debugger;
        var variantList = component.get("v.variantList");
        var el = component.find('variantChart').getElement();
        var ctx = el.getContext('2d');
        var clrs = ["#47acb1", "#f9aa7b", "yellow"];
        /*  var x = [{
                    label: 'L1',
                    data: firstValue,
                    backgroundColor: "#4bca81"
                }, {
                    label: 'L2',
                    data: secondValue,
                    backgroundColor: "#ff9933"
                }]; */
        var x = [];
        var xy;
        for(xy in v)
        {
            var ind = variantList.indexOf(xy);
            var n = {
                label: xy,
                data: v[xy],
                backgroundColor: clrs[ind]
            };
            x.push(n);
        }
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: label,
                datasets: x
            },
            options: {
                legend: {
                    display: true,
                    position: 'bottom'
                }
            },
        });
        
    },
    
    getColour : function(component, event, helper){
        var action = component.get("c.getCarColour");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                //  component.set("v.colorList", value);
                var labelc = component.get("v.labelc");
                var percentagec = component.get("v.percentagec");
                var x;
                for(x in value)
                    if(!labelc.includes(value[x]))
                    {
                        labelc.push(value[x]);
                        percentagec.push(0);
                    }
                component.set("v.labelc", labelc);
                component.set("v.percentagec", percentagec);
            }
        });
        $A.enqueueAction(action);	
    },
    
    getmetallicList : function(component, event, helper){
        var action = component.get("c.getCarMetallicColour");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var labelm = component.get("v.labelm");
                var percentagem = component.get("v.percentagem");
                var x;
                for(x in value)
                    if(!labelm.includes(value[x]))
                    {
                        labelm.push(value[x]);
                        percentagem.push(0);
                    }
                component.set("v.labelm", labelm);
                component.set("v.percentagem", percentagem);
            }
        });
        $A.enqueueAction(action);	
        
    },
    
    buildVariantChart : function(component, event, helper){
       //  var itemNode = document.getElementById('variantChart');
       //     itemNode.parentNode.removeChild(itemNode);
       //     document.getElementById('varchartDiv').innerHTML = '<canvas aura:id="variantChart" id="variantChart" width="295" height="162"/>';
        var action = component.get("c.getCarColour");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var wholeMap = new Map();
                var x;
                for(x in value)
                {
                    var variantList = component.get("v.variantList");
                    var varMap = new Map();
                    var y;
                    for(y in variantList)
                    {
                        varMap.set(variantList[y], 0);
                    }
                    wholeMap.set(value[x], varMap);
                }
                var itemList = component.get("v.itemList"); 
                var productList = component.get("v.productList"); 
                var quantityList = component.get("v.quantityList");
                if(itemList != null && typeof itemList[0].Product2 !== 'undefined')
                    for(x in itemList)
                    {debugger;
                        var index = productList.indexOf(itemList[x].Product2.Id);
                        var map1 = wholeMap.get(itemList[x].Product2.PSA_Ext_Colour__c);
                        var val1 = 0;
                        if(map1.has(itemList[x].Product2.PSA_Variant__c))
                            val1 = map1.get(itemList[x].Product2.PSA_Variant__c);
                        map1.set(itemList[x].Product2.PSA_Variant__c, val1+quantityList[index]);
                        wholeMap.set(itemList[x].Product2.PSA_Ext_Colour__c, map1);
                    }
                
                var demoItems = component.get("v.demoItems"); 
                var demomapFirm = component.get("v.demomapFirm"); 
                if(demoItems != null && typeof demoItems !== 'undefined')
                    for(x in demoItems)
                    {
                        var DemoType = demoItems[x].Demo_OrderType__c;
                        var xintMap = demomapFirm[DemoType];
                        var map1 = wholeMap.get(demoItems[x].Product2.PSA_Ext_Colour__c);
                        var val1 = 0;
                        if(map1.has(demoItems[x].Product2.PSA_Variant__c))
                            val1 = map1.get(demoItems[x].Product2.PSA_Variant__c);
                        map1.set(demoItems[x].Product2.PSA_Variant__c, val1+xintMap[demoItems[x].Product2.Id]);
                    }
                var label = [];
                var firstValue = [];
                var secondValue = [];
                
                var variantList = component.get("v.variantList");
                var varMap = new Map();
                var y;
                var v;
                v = [];
                for(y in variantList)
                {
                    v[variantList[y]] = [];
                }
                for (let [key, value] of wholeMap)
                {
                    var x = 0;
                    label.push(key);
                    for(y in variantList)
                    {
                        v[variantList[y]].push(value.get(variantList[y]));
                    }
                }
                this.variantGraph(component, event, helper, label, v);
                
            }
        });
        $A.enqueueAction(action);
        
        
    },
    
    
    
    
})