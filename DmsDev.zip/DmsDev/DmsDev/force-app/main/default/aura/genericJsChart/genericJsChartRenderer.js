({
    afterRender: function (component, helper) {
        this.superAfterRender();
        if(component.get("v.name") == "modelChart")
        {
            helper.buildVariantChart(component, event, helper);
            var variant = new Map();
            var color = new Map();
            var metallic = new Map();
            var demoMaps = new Map();
            var x;
            var itemList = component.get("v.itemList");     
            var demoItems = component.get("v.demoItems"); 
            var demomapFirm = component.get("v.demomapFirm"); 
            if(demoItems != null && typeof demoItems !== 'undefined')
                for(x in demoItems)
                {
                    var DemoType = demoItems[x].Demo_OrderType__c;
                    var xintMap = demomapFirm[DemoType];
                    if(!variant.has(demoItems[x].Product2.PSA_Variant__c))
                        variant.set(demoItems[x].Product2.PSA_Variant__c, xintMap[demoItems[x].Product2.Id]);
                    else
                    {
                        var val = variant.get(demoItems[x].Product2.PSA_Variant__c);
                        variant.set(demoItems[x].Product2.PSA_Variant__c, xintMap[demoItems[x].Product2.Id]+val);
                    }
                    if(!color.has(demoItems[x].Product2.PSA_Ext_Colour__c))
                        color.set(demoItems[x].Product2.PSA_Ext_Colour__c, xintMap[demoItems[x].Product2.Id]);
                    else
                    {
                        var val = color.get(demoItems[x].Product2.PSA_Ext_Colour__c);
                        color.set(demoItems[x].Product2.PSA_Ext_Colour__c, xintMap[demoItems[x].Product2.Id]+val);
                    }
                    if(!metallic.has(demoItems[x].Product2.Metallic_Non_Metallic__c))
                        metallic.set(demoItems[x].Product2.Metallic_Non_Metallic__c, xintMap[demoItems[x].Product2.Id]);
                    else
                    {
                        var val = metallic.get(demoItems[x].Product2.Metallic_Non_Metallic__c);
                        metallic.set(demoItems[x].Product2.Metallic_Non_Metallic__c, xintMap[demoItems[x].Product2.Id]+val);
                    }
                }
            var productList = component.get("v.productList"); 
            var quantityList = component.get("v.quantityList");
            if(itemList != null && typeof itemList[0].Product2 !== 'undefined')
                for(x in itemList)
                {
                    var index = productList.indexOf(itemList[x].Product2.Id);
                    if(!variant.has(itemList[x].Product2.PSA_Variant__c))
                        variant.set(itemList[x].Product2.PSA_Variant__c, quantityList[index]);
                    else
                    {
                        var val = variant.get(itemList[x].Product2.PSA_Variant__c);
                        variant.set(itemList[x].Product2.PSA_Variant__c, quantityList[index]+val);
                    }
                    if(!color.has(itemList[x].Product2.PSA_Ext_Colour__c))
                        color.set(itemList[x].Product2.PSA_Ext_Colour__c, quantityList[index]);
                    else
                    {
                        var val = color.get(itemList[x].Product2.PSA_Ext_Colour__c);
                        color.set(itemList[x].Product2.PSA_Ext_Colour__c, quantityList[index]+val);
                    }
                    if(!metallic.has(itemList[x].Product2.Metallic_Non_Metallic__c))
                        metallic.set(itemList[x].Product2.Metallic_Non_Metallic__c, quantityList[index]);
                    else
                    {
                        var val = metallic.get(itemList[x].Product2.Metallic_Non_Metallic__c);
                        metallic.set(itemList[x].Product2.Metallic_Non_Metallic__c, quantityList[index]+val);
                    }
                }
            
            console.log(variant);
            console.log(color);
            console.log(metallic);
            
            var labelc = [];
            var quantityc = [];
            var percentagec = [];
            var totalquantityc = 0;
            for (let [key, value] of color) 
            {
                labelc.push(key);
                quantityc.push(value);
                totalquantityc += value;
            }
            for(var i=0; i<quantityc.length; i++)
            {
                var x = (quantityc[i]*100)/totalquantityc;
                x = x.toFixed(1);
                percentagec.push(x);
            }
            component.set("v.labelc", labelc);
            component.set("v.percentagec", percentagec);
            
            var labelm = [];
            var quantitym = [];
            var percentagem = [];
            var totalquantitym = 0;
            for (let [key, value] of metallic) 
            {
                labelm.push(key);
                quantitym.push(value);
                totalquantitym += value;
            }
            for(var i=0; i<quantitym.length; i++)
            {
                var x = (quantitym[i]*100)/totalquantitym;
                x = x.toFixed(1);
                percentagem.push(x);
            }
            component.set("v.labelm", labelm);
            component.set("v.percentagem", percentagem);        
            helper.getColour(component, event, helper);
            helper.getmetallicList(component, event, helper);
            
            
            window.setTimeout(
                $A.getCallback(function() {
                    helper.graph1(component, event, helper, variant);
                }), 500
            ); 
        }else if(component.get("v.name") == "objCommitment")
        {
            window.setTimeout(
                $A.getCallback(function() {
                    helper.graph2(component, event, helper);
                }), 3000
            );
            
        }
        
        
        
    },
})