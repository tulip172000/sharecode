({
    doInit : function(component, event, helper) {
        helper.vehicledata(component, event, helper);
    },
    
    onclickPO : function(component, event, helper) {
        debugger;
        component.set('v.creategrn',true);
        var target = event.getSource().get('v.value');
        var action = component.get('c.createvehiclerecord');
        action.setParams({
            'salesid' : target
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();    
                //  component.set('v.vehicleid',records);
                var compEvent = component.getEvent("vehicleReceiptIdPass");
               // var vehiclerec = component.get('v.vehicleid') ;
               // var vehid=vehiclerec.Id;
                compEvent.setParams({"Id" : target, "currentOrderId" : records.Id});
                compEvent.fire();
            }
        });
        $A.enqueueAction(action); 
    },
    potrucksearch : function(component, event, helper) {
        
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        console.log("" + event.getSource().get("v.value")); 
        //component.set("v.invoice",pot) ; 
        if(pot == null || pot == 'undefined' || pot==""){
          helper.vehicledata(component, event, helper);     
        }
        else{
        var action = component.get('c.getVehicletrucksearch');
        action.setParams({
            'trucknumber' : pot,
            'searchtype'  :'Truck'
            
        });
        
       action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                console.log("Inside "+state);
             
                component.set("v.paginationList", records);
                component.set("v.spinner", false);
            }
            else{
                component.set("v.spinner", false);
            }
        });
        $A.enqueueAction(action);
        }
    },
    
    poVinsearch : function(component, event, helper) {
        
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        console.log("" + event.getSource().get("v.value"));
      
        component.set("v.invoice",pot) ; 
        if(pot == null || pot == 'undefined' || pot==""){
          helper.vehicledata(component, event, helper);  
           
        }
        else{
 
        var action = component.get('c.getVehicletrucksearch');
        action.setParams({
            'trucknumber' : pot,
            'searchtype'  :'Vin'
        });
        
       action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                console.log("Inside "+state);
             
                component.set("v.paginationList", records);
                component.set("v.spinner", false);
            }
            else{
                component.set("v.spinner", false);
            }
        });
        $A.enqueueAction(action);
        }
    },
    
    poInvoicesearch : function(component, event, helper) {
        
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");
        console.log("" + event.getSource().get("v.value"));
      
        component.set("v.invoice",pot) ; 
        if(pot == null || pot == 'undefined' || pot==""){
          helper.vehicledata(component, event, helper);  
           
        }
        else{
 
        var action = component.get('c.getVehicletrucksearch');
        action.setParams({
            'trucknumber' : pot,
            'searchtype'  :'Invoice'
        });
        
       action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                console.log("Inside "+state);
             
                component.set("v.paginationList", records);
                component.set("v.spinner", false);
            }
            else{
                component.set("v.spinner", false);
            }
        });
        $A.enqueueAction(action);
        }
    },
    
    next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var orderlist = component.get("v.receipts");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = orderlist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
       var orderlist = component.get("v.receipts");//All Vehicle List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = orderlist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
         /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
       var orderlist = component.get("v.receipts");//All Vehicle List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = orderlist.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.vehicledata(component, event, helper);
    }
   
})