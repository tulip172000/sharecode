({
	doInit: function(component, event, helper) {
         helper.targetsrecords(component,event);
         helper.stockrecords(component,event);
         helper.Vorrecords(component,event);
	},
    pricechange: function(component, event, helper) {
        var price=component.find('pricetype').get('v.value');
        component.set('v.pricetype',price);
         helper.targetsrecords(component,event);
         helper.stockrecords(component,event);
	}
})