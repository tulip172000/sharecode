({
	onTabSelect : function(component, event, helper) {
        component.set("v.BookingOrderDetailView", false);
         component.set("v.showtabs", true);
        var deactivate = component.find("serviceDashboard");
        $A.util.removeClass(deactivate, "active");
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
    },
    onCancelSelect : function(component, event, helper) {
        debugger;
        component.set("v.BookingOrderDetailViewApprove", false);
        component.set("v.showtabs", true);
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var checkCurrTab = component.get("v.currTab");
        if(checkCurrTab =='updatePhone'){
           component.set("v.BookingOrderDetailViewApprove", false);   
        }
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");
    },
    
    handleBookingOrderIdPass : function(component, event, helper) {        
        var Id = event.getParam("currentMonthlyOrderIdoem");
        component.set("v.BookingorderId", Id);  
        component.set("v.BookingOrderDetailView", true);
    },
    handleBookingOrderIdPassPending : function(component, event, helper) { 
        debugger;
        var Id = event.getParam("currentMonthlyOrderIdoem");
        component.set("v.BookingorderId", Id);  
        component.set("v.BookingOrderDetailViewApprove", true);
            
    },
     handlevalidateMenu : function(component, event, helper) {
       
        var validation = event.getParam("validation");
        var validationItem = event.getParam("validationItem");
        var defaultItem = event.getParam("defaultItem");
        console.log("validationItem -- "+validationItem+"::"+defaultItem);
        if (defaultItem) {
        	component.set("v.currTab", validationItem);            
        }
    },
    
})