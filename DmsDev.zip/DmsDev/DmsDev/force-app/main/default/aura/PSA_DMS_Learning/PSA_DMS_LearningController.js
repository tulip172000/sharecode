({
	onTabSelect : function(component, event, helper) {
        
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var deact = ['MyTrainings','Forms','Reports','MyRanking','Approvenominations','UsefulLinks'];
        var activate = component.find(id);
        if(['CustomReports', 'Dashboards'].includes(id))
            var activate = component.find("Reports");
        else
            deact.push("Reports");
        if(['Snapshot', 'Leaderboard', 'Badges'].includes(id))
            var activate = component.find("MyRanking");
        else
            deact.push("MyRanking");
        
        var x;
        for(x in deact)
            {
                var deactivate = component.find(deact[x]);
                $A.util.removeClass(deactivate, "active");
            }
        $A.util.addClass(activate, "active");
        
        
        
    },
    handleClick1 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_MyTraining");
        window.open(la,'_blank');
    },
    handleClick2 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_Forms");
        window.open(la,'_blank');
    },
    handleClick3 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_Reports_Custom");
        window.open(la,'_blank');
    },
    handleClick4 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_Reports_Dashboards");
        window.open(la,'_blank');
    },
    handleClick5 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_MyRanking_Snapshot");
        window.open(la,'_blank');
    },
    handleClick6 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_MyRanking_Leaderboard");
        window.open(la,'_blank');
    },
    handleClick7 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_MyRanking_Badges");
        window.open(la,'_blank');
    },
    handleClick8 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_Approvenominations");
        window.open(la,'_blank');
    },
    handleClick9 : function(component, event, helper) {
        var la = $A.get("$Label.c.DMS_Learning_UsefulLinks");
        window.open(la,'_blank');
    },
})