({
     doInit : function(component, event, helper) {
    	helper.getdisablebuttons(component,event,helper);
     },
    validate  : function(component, event, helper) {
       var charCode = event.getParams().keyCode;
          if ((charCode >= 1 && charCode <= 32)||(charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105)) { 
            return true;
       }
        else{
           alert('Please Enter Only in Numbers');
        }
    },
    
    qtyValueChanged : function(component, event, helper) {
           debugger;   
         var Quant = event.getSource().get('v.value');
         var dealercde = component.find("Dealercoid").get("v.value");
         var service = component.find("sevicetype").get("v.value");
         var monthsrc = event.getSource();
         var monthname = monthsrc.getLocalId();
		 var orderlimit = component.get("v.objectiveInstance.orderlimit");
         var monthlyquantity = component.find(monthname).get("v.value");
         var selYear = component.get("v.yearSelectedchild");
          var today = new Date();
         var fullYear =today.getFullYear();
            if(selYear == "option"){
                selYear = fullYear;
            }
                 var action = component.get("c.upsertopportunity");
           action.setParams({ 
                "dealercode" : dealercde,
                "servicevalue": service,
                "monthname" : monthname,
                "qty"		: Quant,
                "year"		:selYear
            });
            action.setCallback(this, function(a) {
                var state = a.getState();
                console.log(" state ---"+state);
                if (state === "SUCCESS") {
                    var storeResponse = a.getReturnValue();
                }
            });
            $A.enqueueAction(action);
   
      },
 
  handleValueChange: function(component,event,helper) {
   var yearsel = component.get("v.yearSelected");
      component.set("v.yearSelectedchild",yearsel);
  },

})