({
    getcasenumbers : function(component, event) {
        var action = component.get("c.getcasenumbers");
        action.setParams({
            "wokorderid" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.lstcasenumbers', response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    
    workshopnochange : function(component, event, helper){
        var cid = component.find("requisitionid").get("v.value");
        var rid = component.find("workshopnoid").get("v.value");
        helper.getwolineitemshelper(component, event, cid, rid);
        //var cmpTarget = component.find('submitbtn');
        //$A.util.removeClass(cmpTarget, 'disablebtn');
        //component.set("v.disablereturns",false);      
    },
    
    getwolineitemshelper : function(component, event, caseid, reqid){
        var action = component.get("c.getwolineitems");
        action.setParams({
            "caseid" :  caseid,
            "workshopreturn" : true
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.lstwolineitems", response.getReturnValue()); 
                /*var lineitems = response.getReturnValue();
                component.set("v.disablereturns",lineitems[0].isreturned);
                var x;
                for(x in lineitems){
                    var rec = lineitems[x];
                    var returnqty = rec.returnqty;
                    if(component.get("v.disablereturns") == false){
                        if(returnqty == undefined || returnqty == null || returnqty == ""){
                            component.set("v.disablereturns", false);
                        }
                        else{
                            component.set("v.disablereturns", true);
                            component.find("submitbtn").set("v.class", "disablebtn");
                        }
                    }
                }*/
                if(response.getReturnValue().length == 0){
                   
                    component.set('v.disablereturns',true);
                    var message = 'No parts has been issued!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "type": "error",
                        "message": message
                    });
                    toastEvent.fire();
                }
                else
                {
                  
                    var lineitems = response.getReturnValue();
                    if(lineitems[0].isreturned)
                    {
                        var cmpTarget = component.find('submitbtn');
                        $A.util.addClass(cmpTarget, 'disablebtn');
                        component.set('v.disablereturns',true);
                    }
                    else
                    {
                        var cmpTarget = component.find('submitbtn');
                        $A.util.removeClass(cmpTarget, 'disablebtn');
                        component.set('v.disablereturns',false);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    getworkshopno : function(component, event, cid){
        var action = component.get("c.getworkshopnos");
        action.setParams({
            "caseid" : cid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.lstworkshopno", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);     	   
    },
    
    Savereturnedrecords : function(component, event)
    {       
        var lstoflineitems = component.get("v.Finalpartsconsumables");
        if(lstoflineitems.length > 0){
           
            component.set("v.spinner", true);
            var action = component.get('c.updaterequistionqty');
            action.setParams({
                "wolineitems": lstoflineitems,
                "casenum" : component.get("v.selectedrequisition"),
                "caseremarks" : ""
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                        var cmpTarget = component.find('submitbtn');
                        $A.util.addClass(cmpTarget, 'disablebtn');
                    component.set('v.disablereturns',true);
                    component.set("v.spinner", false);                
                    var workshopissueno =response.getReturnValue();
                    component.set("v.workshopissueno", workshopissueno);
                    component.set("v.Finalpartsconsumables",[]);
                    this.showtoast(component, event, "success", "Parts Returned Successfully!");                    
                }
                else{
                    component.set("v.spinner", false);
                    component.set("v.Finalpartsconsumables",[]);
                    this.showtoast(component, event, "error", "Parts Return Failed!");                    
                }
            });
            $A.enqueueAction(action);
        }
        else{
            this.showtoast(component, event, "error", "Please select atleast one part to return!");            
        }
    },
    
    validateworkshopreturn : function(component, event, helper){
        var isValid = true;        
        var requistionval = component.find("requisitionid").get("v.value");
        
        if(requistionval == '-- None --' || requistionval == 'undefined' || requistionval == '' || requistionval == null){
            isValid = false;            
            this.showtoast(component, event, "error", "Please select requisition no to return");
        }
        else{
            isValid = true;
        }
                
        return isValid;
         
     },
    
    showtoast : function(component, event, type, msg){
        var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": type,
                "message": msg
            });
            toastEvent.fire();
    }
})