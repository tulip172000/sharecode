({
    getRepairOrderDetails : function(component, event){
        
        var action = component.get("c.getBayRepairOrderMethod");
        var recid = component.get("v.repairOrderId")
        action.setParams({
            "recordId" : recid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.repairOrderDetails", storeResponse);
                component.set("v.jcaseId", storeResponse.CaseId);
                
            }
        });
        $A.enqueueAction(action);
    },
    
    getBayMasterDetails : function(component, event){
       
        var action = component.get('c.getBaymasterDetailsRO');
        var recid = component.get("v.repairOrderId");
        var bayid=component.get("v.recordId");

        action.setParams({
            "recid" : recid,
            "bayid": bayid
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
              
                component.set("v.technian",records[0].PSA_Technician__r.Id);
                 component.find("technicianUp").set("v.value",records[0].PSA_Technician__r.Id);
                 component.set("v.BaylistUpdates",records[0]); 
                document.getElementById("remarksup").value = records[0].PSA_Remarks__c;
                this.getBayMasterDetails1(component, event);
                
                
            }
        });
        $A.enqueueAction(action);
        
    },
    getUpdateBayMasterDetails : function(component, event){
       
        var action = component.get('c.getBaymasterDetailsRO');
        var recid = component.get("v.repairOrderId");
         var bayid=component.get("v.recordId");
        action.setParams({
            "recid" : recid,
            "bayid": null
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.Baylist", records);
                
                 if(records == ''|| records  == null || records == 'undefined')
                  {
                   component.set("v.checVal", false);
                    var checkRoStatus=component.get("v.checkRoStatus");
                     if(checkRoStatus)
                     {
                     component.set("v.allocated",checkRoStatus);
                     }
                    
                  } 
                else
                {   component.set("v.checVal", true);
                    this.getBayMasterDetails1(component, event);
                }
              
           if(bayid == ''|| bayid  == null || bayid == 'undefined')
            {
               // component.set("v.checVal", true);
            }
          }
        });
        $A.enqueueAction(action);
        
    },
    getBayMasterDetails1 : function(component, event){
       
        var action = component.get('c.getCheckTime');
        var recid = component.get("v.repairOrderId");
        var bayid=component.get("v.recordId");

        action.setParams({
            "recid" : recid,
             });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if(state == 'SUCCESS') {
                var result =response.getReturnValue();
                var checkRoStatus=component.get("v.checkRoStatus");
                if(checkRoStatus)
                {
                     component.set("v.allocated",checkRoStatus);
                }else
                {
                    component.set("v.allocated",result);
                }
               
                 }
        });
        $A.enqueueAction(action);
        
    },
    
    validatePartForm : function(component, event, helper){
        
        var isValid = true;
        var checkUpdate = component.get("v.UpdateBayAllocation");
        if(checkUpdate)
        {
        var bayName = component.get("v.BaylistUpdates.PSA_Bay_Master__r.Id");
        var technicianAssign = component.find("technicianUp").get("v.value");
        var startTime = component.get("v.BaylistUpdates.PSA_Start_Time__c");
        var endTime = component.get("v.BaylistUpdates.PSA_End_Time__c");
        var astartTime = component.get("v.BaylistUpdates.PSA_Actual_Start_Date__c");
        var aendTime = component.get("v.BaylistUpdates.PSA_Actual_End_Date__c");
        var remarksVal = document.getElementById("remarksup").value;
          
        }
        else{
        var startTime = component.find("startime").get("v.value");
        var bayName = component.find("BayNme").get("v.value");
        var technicianAssign = component.find("technician").get("v.value");
        var startTime = component.find("startime").get("v.value");
        var endTime = component.find("endtime").get("v.value");
        var astartTime = component.find("astartime").get("v.value");
        var aendTime = component.find("aendtime").get("v.value");
        var remarksVal = document.getElementById("remarks").value;
            
        }
        var roOpenDate = component.get("v.roOpenDate");
        var now = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD hh:mm:ss");
       
        
        component.set("v.BayNameErrmsg",'');
        $A.util.removeClass(bayName,"disp-block");
        $A.util.addClass(bayName,"disp-none");
        component.set("v.TechnErrmsg",'');  
        $A.util.removeClass(technicianAssign,"disp-block");
        $A.util.addClass(technicianAssign,"disp-none");
        component.set("v.StartTimeErrmsg",'');
        $A.util.removeClass(startTime,"disp-block");
        $A.util.addClass(startTime,"disp-none");
        
       
        component.set("v.EndTimeErrmsg",'');
        $A.util.removeClass(endTime,"disp-block");
        $A.util.addClass(endTime,"disp-none");
        
        component.set("v.aStartTimeErrmsg",'');
        $A.util.removeClass(startTime,"disp-block");
        $A.util.addClass(startTime,"disp-none");
        component.set("v.aEndTimeErrmsg",'');
        $A.util.removeClass(aendTime,"disp-block");
        $A.util.addClass(aendTime,"disp-none");
        component.set("v.remarkserrmsg",'');
        $A.util.removeClass(remarksVal,"disp-block");
        $A.util.addClass(remarksVal,"disp-none");
        
        if(bayName =='--None--'|| bayName == '' || bayName == null){
            component.set("v.BayNameErrmsg",'This is a required field');
            $A.util.removeClass(bayName,"disp-none");
            $A.util.addClass(bayName,"disp-block");
            isValid = false;
        }
        
        if(technicianAssign =='--None--'|| technicianAssign == '' || technicianAssign == null){
            component.set("v.TechnErrmsg",'This is a required field');
            $A.util.removeClass(technicianAssign,"disp-none");
            $A.util.addClass(technicianAssign,"disp-block");
            isValid = false;
        }
        if(startTime =='--None--' || startTime == '' || startTime == null){
            component.set("v.StartTimeErrmsg",'This is a required field');
            $A.util.removeClass(startTime,"disp-none");
            $A.util.addClass(startTime,"disp-block");
            isValid = false;
        }
        else{
        if(startTime<roOpenDate)
        {
           component.set("v.StartTimeErrmsg",'Start Day & Time should not be less than RO Open Date & Time');
            $A.util.removeClass(startTime,"disp-none");
            $A.util.addClass(startTime,"disp-block");
           isValid = false;
        }
        }
        if(endTime =='--None--'|| endTime == '' || endTime == null){
            component.set("v.EndTimeErrmsg",'This is a required field');
            $A.util.removeClass(endTime,"disp-none");
            $A.util.addClass(endTime,"disp-block");
            isValid = false;
        }else{
         if(startTime>endTime)
        {
            component.set("v.EndTimeErrmsg",'End Day & Time should not be less than Start Date & Time');
            $A.util.removeClass(endTime,"disp-none");
            $A.util.addClass(endTime,"disp-block");
           
            isValid = false;
        }}
        
         if(astartTime =='--None--' || astartTime == '' || astartTime == null){
            component.set("v.aStartTimeErrmsg",'This is a required field');
            $A.util.removeClass(startTime,"disp-none");
            $A.util.addClass(startTime,"disp-block");
            isValid = false;
        } 
        else{
        if(astartTime<roOpenDate)
        {
            component.set("v.aStartTimeErrmsg",'Start Day & Time should not be less than RO Open Date & Time');
            $A.util.removeClass(astartTime,"disp-none");
            $A.util.addClass(astartTime,"disp-block");
            isValid = false;
        }}
        if(aendTime =='--None--'|| aendTime == '' || aendTime == null){
            /*component.set("v.aEndTimeErrmsg",'This is a required field');
            $A.util.removeClass(aendTime,"disp-none");
            $A.util.addClass(aendTime,"disp-block");
            isValid = false;*/
        } 
        else{
        if(astartTime>aendTime)
        {
            component.set("v.aEndTimeErrmsg",'End Day & Time should not be less than Start Date & Time');
            $A.util.removeClass(aendTime,"disp-none");
            $A.util.addClass(aendTime,"disp-block");
           
            isValid = false;
        }
          
        }
          if(remarksVal =='--None--'|| remarksVal == '' || remarksVal == null || remarksVal=='undefined'){
            component.set("v.remarkserrmsg",'This is a required field');
            $A.util.removeClass(remarksVal,"disp-none");
            $A.util.addClass(remarksVal,"disp-block");
            isValid = false;
        }
      
        return isValid;
    },
    saverequest:function(component,event){
        debugger;

        var recId = component.get("v.recordId");
        var jobCarddet = component.get("v.jcaseId");
        var checkUpdate = component.get("v.UpdateBayAllocation");
        if(checkUpdate)
        {
        
        var bayName = component.get("v.BaylistUpdates.PSA_Bay_Master__r.Id");
        var technicianAssign = component.find("technicianUp").get("v.value");
        var startTime = component.get("v.BaylistUpdates.PSA_Start_Time__c");
        var endTime = component.get("v.BaylistUpdates.PSA_End_Time__c");
        var astartTime = component.get("v.BaylistUpdates.PSA_Actual_Start_Date__c");
        var aendTime = component.get("v.BaylistUpdates.PSA_Actual_End_Date__c");
        var textAreaComments = document.getElementById("remarksup").value;
           
        }
        else{
        var startTime = component.find("startime").get("v.value");
        var bayName = component.find("BayNme").get("v.value");
        var technicianAssign = component.find("technician").get("v.value");
        var startTime = component.find("startime").get("v.value");
        var endTime = component.find("endtime").get("v.value");
        var astartTime = component.find("astartime").get("v.value");
        var aendTime = component.find("aendtime").get("v.value");
        var textAreaComments = document.getElementById("remarks").value;
        }
       
         if(aendTime =='undefined'|| aendTime == '' || aendTime == null){
            aendTime=null;
        } 
        var workorderid = component.get("v.repairOrderId");
        console.log('remark value  >>>>>>'+textAreaComments);
        var action = component.get("c.createBayAllocationMethod");
        action.setParams({
            
            "jobcardNo": jobCarddet,
            "bayname": bayName,
            "techassign" : technicianAssign,
            "starttime": startTime,
            "endtime": endTime,
            "workordId"    :workorderid,
            "remarks": textAreaComments,
            "recordid" :recId,
            "actualStart":astartTime,
            "actualEnd":aendTime
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            var storeResponse = response.getReturnValue();
          
            if (state === "SUCCESS") {          
                
              
                this.getUpdateBayMasterDetails(component, event);
             var Message= $A.get("$Label.c.Bay_Allocated_Successfully");
                component.set("v.checVal", true);
                this.showSuccessToast(component, event,Message);
                document.getElementById("myModal").style.display = "none";
                
            }
            else{
                 
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Failed!",
                    "message": "Failed to Bay Allocation",
                    "type": "failed"
                });
                toastEvent.fire(); 
                document.getElementById("myModal").style.display = "none";
                document.getElementById("remarks").value = '';
                
                component.find('caseIdval').set("v.value",'');
                component.find('BayNme').set("v.value",'');
                component.find('technician').set("v.value",'');
                component.find('startime').set("v.value",'');
                component.find('endtime').set("v.value",'');
                component.find('astartime').set("v.value",'');
                component.find('aendtime').set("v.value",'');
            }
            
        });
        $A.enqueueAction(action);
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    getBayListDetails :function(component, event, helper){
        var action = component.get("c.bayListMethod");
        action.setCallback(this, function(response){
            var state = response.getState();
           
            if (state == "SUCCESS") {
                
                component.set("v.myBayList", response.getReturnValue());
            }
            
        });
        $A.enqueueAction(action);
    },
    getTechnicianDetails :function(component, event, helper){
        var action = component.get("c.technicainListMethod");
        action.setCallback(this, function(response){
            var state = response.getState();
    
            if (state == "SUCCESS") {
                component.set("v.myTechnList", response.getReturnValue());
             
            }
        });
        $A.enqueueAction(action);
        
    }//100183052
    
})