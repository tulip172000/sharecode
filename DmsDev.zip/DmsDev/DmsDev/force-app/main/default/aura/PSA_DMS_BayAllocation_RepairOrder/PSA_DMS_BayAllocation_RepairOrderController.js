({
    doInit: function(component, event, helper) {
        helper.getBayListDetails(component, event);
        helper.getTechnicianDetails(component, event);
        helper.getRepairOrderDetails(component, event);
        helper.getUpdateBayMasterDetails(component, event);
        
       // helper.getTechnicianDetails(component, event);
    },
    
    CreatebayAllocation : function(component, event, helper) {
        component.set("v.newBayAllocation", true);
         component.set("v.newBayAllocation", true);
    },
    openPDF :  function(component, event, helper) {
       var baseUrl= decodeURIComponent(window.location.hostname);
       var url = ' https://'+baseUrl+'/dmsindia/s/psa-invoicecommunitypage'; 
        window.open(url,"_blank", "width=400, height=450");
     },
    
    handleBayAllocListview : function(component, event, helper) {
        var listPage = event.getParam("listPage");
        if(listPage){
            component.set("v.newBayAllocation", false);
            
        }
    }, 
    createBayAlloc : function(component, event, helper) {
       
        if(helper.validatePartForm(component)) {
             
            helper.saverequest(component,event); 
        }
    },
    
    openBayForm : function(component, event, helper) {
       document.getElementById("myModal").style.display = "block";
       // component.set("v.calenderview", true);
         component.set("v.newBayAllocation", true);
        component.set("v.new",true);
        component.set("v.UpdateBayAllocation",false);
        component.set("v.recordId",'');     
    }, 
    ONOrder: function(component, event, helper) {
        debugger;
        component.set("v.newBayAllocation", true);
        component.set("v.UpdateBayAllocation", true);
        var target = event.getSource().get('v.value');
        component.set("v.recordId",target);
        
        document.getElementById("myModal").style.display = "block";
      //  component.set("v.calenderview", false);
        
        component.set("v.new", false);
        
        helper.getBayMasterDetails(component, event);
        
        
    },
    
    
    closeBayForm : function(component, event, helper) {
        debugger;
        document.getElementById("myModal").style.display = "none";
       
        component.find('caseIdval').set("v.value",'');
         var checkUpdate = component.get("v.UpdateBayAllocation");
        if(checkUpdate)
        {
        component.find("technicianUp").set("v.value",component.get("v.technian"));
        document.getElementById("remarksup").value = '';
        }else
        {
        component.find('BayNme').set("v.value",'');
        component.find('technician').set("v.value",'');
        component.find('startime').set("v.value",'');
        component.find('endtime').set("v.value",'');
        component.find('astartime').set("v.value",'');
        component.find('aendtime').set("v.value",'');
        document.getElementById("remarks").value = '';
        }
        
        
        component.set("v.BayNameErrmsg",'');
        component.set("v.TechnErrmsg",'');component.set("v.aEndTimeErrmsg",'');
        component.set("v.EndTimeErrmsg",'');
        component.set("v.StartTimeErrmsg",'');component.set("v.aStartTimeErrmsg",'');
        component.set("v.remarkserrmsg",'');
        
    },  
    backtoList : function(component, event, helper) {
       
        var eventListPage = component.getEvent("displayListPageParts");
           eventListPage.setParams({"listPage" : true });
        
        eventListPage.fire();
        
    }
    
})