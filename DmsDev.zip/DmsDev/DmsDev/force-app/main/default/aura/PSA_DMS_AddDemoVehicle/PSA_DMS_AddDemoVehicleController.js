({
    doInit : function(component, event, helper){
        var action = component.get("c.getInitalDemoDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.brandList", value['brand']);
                component.set("v.ordertypeList", value['orderType']);
                helper.demoLoading(component,event,helper);
            }
        });
        $A.enqueueAction(action);	
    },
    
    savePreviousTypeValue : function(component, event, helper){
        component.set("v.previousdemoType", component.find("demoType").get("v.value"));
    },
    
    enableRow : function(component, event, helper){
        var demoType = component.get("v.previousdemoType");
        helper.removeProduct(component, event, helper, demoType);
        component.find("brand").set("v.value", "");  
        component.find("variant").set("v.value", "");
        component.find("metallic").set("v.value", "");
        component.find("colour").set("v.value", "");
        component.find("intTrim").set("v.value", "");
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disBrand", "false");
        component.set("v.disVariant", "true");
        component.set("v.disMetallic", "true");
        component.set("v.disColour", "true");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");            
    },
    
    getVariant : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        component.find("variant").set("v.value", "");
        component.set("v.disVariant", "true");
        var action = component.get("c.getCarVariant");
        action.setParams({ 
            "selModel" : selectvalmodel
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.variantList", response.getReturnValue());
            component.set("v.disVariant", "false");
            }
        });
        $A.enqueueAction(action);
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        component.find("metallic").set("v.value", "");
        component.find("colour").set("v.value", "");
        component.find("intTrim").set("v.value", "");
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disMetallic", "true");
        component.set("v.disColour", "true");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
    },
    
    getmetallicList : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        component.find("metallic").set("v.value", "");
        component.set("v.disMetallic", "true");
        var action = component.get("c.getCarMetallicColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel            
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.metallicList", response.getReturnValue());
            component.set("v.disMetallic", "false");
            }
        });
        $A.enqueueAction(action);
        var demoType = component.find("demoType").get("v.value");	
        helper.removeProduct(component, event, helper, demoType);
        component.find("colour").set("v.value", "");
        component.find("intTrim").set("v.value", "");
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disColour", "true");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");        
    },
    
    getColour : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        component.find("colour").set("v.value", "");
        component.set("v.disColour", "true");
        var action = component.get("c.getCarColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.colourList", response.getReturnValue());
            component.set("v.disColour", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        component.find("intTrim").set("v.value", "");
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disIntTrim", "true");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
    },
    
    getIntTrimType : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        component.find("intTrim").set("v.value", "");
        component.set("v.disIntTrim", "true");
        var action = component.get("c.getCarIntTrimType");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.IntTrimList", response.getReturnValue());
            component.set("v.disIntTrim", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        
        component.find("Intcolour").set("v.value", "");
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disIntColour", "true");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
        
    },
    
    getIntcolourList : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        component.find("Intcolour").set("v.value", "");
        component.set("v.disIntColour", "true");
        var action = component.get("c.getCarIntColour");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.IntcolourList", response.getReturnValue());
            component.set("v.disIntColour", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        
        component.find("roof").set("v.value", "");
        component.find("pack").set("v.value", "");
        component.set("v.disRoof", "true");
        component.set("v.disPack", "true");
        
    },
    
    getRoofList : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("Intcolour").get("v.value");
        component.find("roof").set("v.value", "");
        component.set("v.disRoof", "true");
        var action = component.get("c.getCarRoof");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.RoofList", response.getReturnValue());
            component.set("v.disRoof", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        component.find("pack").set("v.value", "");
        component.set("v.disPack", "true");
        
    },
    
    getPackList : function(component, event, helper){
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("Intcolour").get("v.value");
        var roof = component.find("roof").get("v.value");
        component.find("pack").set("v.value", "");
        component.set("v.disPack", "true");
        var action = component.get("c.getCarPack");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor,
            "selRoof" : roof
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            component.set("v.PackList", response.getReturnValue());
            component.set("v.disPack", "false");
            }
        });
        $A.enqueueAction(action);	
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        
    },
    
    getId : function(component, event, helper){
        var demoType = component.find("demoType").get("v.value");
        helper.removeProduct(component, event, helper, demoType);
        var demoType = component.find("demoType").get("v.value");
        var mapFirm = component.get("v.demomapFirm");
        component.set("v.disableQuantity", false);
        component.set("v.f1disableQuantity", false);
        component.set("v.f2disableQuantity", false);
        component.set("v.f3disableQuantity", false);
        component.set("v.f4disableQuantity", false);
        component.set("v.f5disableQuantity", false);
        component.set("v.f6disableQuantity", false);
        var itemInstance = component.get("v.itemInstance");
        var selectvalmodel = component.find("brand").get("v.value");
        var selectvariant = component.find("variant").get("v.value");
        var Metallic_Non_Metallic = component.find("metallic").get("v.value");
        var color = component.find("colour").get("v.value");
        var intTrim = component.find("intTrim").get("v.value");
        var interiorcolor = component.find("Intcolour").get("v.value");
        var roof = component.find("roof").get("v.value");
        var pack = component.find("pack").get("v.value");
        component.set("v.quantity", "");
        component.set("v.f1Quantity", 0);
        component.set("v.f2Quantity", 0);
        component.set("v.f3Quantity", 0);
        component.set("v.f4Quantity", 0);
        component.set("v.f5Quantity", 0);
        component.set("v.f6Quantity", 0);
        var action = component.get("c.getProductId");
        action.setParams({ 
            "selVariant" : selectvariant,
            "selModel" : selectvalmodel,
            "selMetallic" : Metallic_Non_Metallic,
            "selColour" : color,
            "selIntTrim" : intTrim,
            "selIntcolor" : interiorcolor,
            "selRoof" : roof,
            "selPack" : pack            
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            var value = response.getReturnValue();
                if(value)
                {
                    if(typeof mapFirm[demoType] !== 'undefined')
                    {
                        var mapFirmValue = mapFirm[demoType];
                        if(mapFirmValue[value.Id])
                        {
                            component.set("v.disableQuantity", true);
                            component.set("v.f1disableQuantity", true);
                            component.set("v.f2disableQuantity", true);
                            component.set("v.f3disableQuantity", true);
                            component.set("v.f4disableQuantity", true);
                            component.set("v.f5disableQuantity", true);
                            component.set("v.f6disableQuantity", true);
                            var msg = $A.get("$Label.c.Vehicle_Duplicate_Item_Error");
                            helper.showError(component, event, helper, msg);
                        }
                        else
                            component.set("v.productId", value.Id);
                    }else
                        component.set("v.productId", value.Id);
                    
                }
                
            }
        });
        $A.enqueueAction(action);	
        
        
    },
    addProductsf : function(component, event, helper){
        var orderLimit = component.get("v.orderLimit");
        var productId = component.get("v.productId");
        var quantity = component.get("v.quantity");
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        var QtyMinus = 0;
        var limitQty = 0;
        if(typeof productId !== 'undefined' && productId != "")
        {
            var x;debugger;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.find("brand").get("v.value"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var qtyListDemo = component.get("v.qtyListDemo");
            var demomapFirm = component.get("v.demomapFirm");
            var Qty = qtyListDemo[0];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                if(xinst[productId])
                	QtyMinus = QtyMinus+xinst[productId];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }
            Qty = Qty-QtyMinus+quantity;
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.quantity", 0);
        }
        
    },
    
    addProductsf1 : function(component, event, helper){
        var orderLimit = component.get("v.orderLimit");
        var productId = component.get("v.productId");
        var quantity = component.get("v.f1Quantity");
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        var QtyMinus = 0;
        var limitQty = 0;
        if(typeof productId !== 'undefined' && productId != "")
        {
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.find("brand").get("v.value"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var qtyListDemo = component.get("v.qtyListDemo");
            var demomapFirm = component.get("v.demofmap1");
            var Qty = qtyListDemo[0];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                if(xinst[productId])
                	QtyMinus = QtyMinus+xinst[productId];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }
            Qty = Qty-QtyMinus+quantity;
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f1Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f1Quantity", 0);
        }
        
    },
    
    addProductsf2 : function(component, event, helper){
        var orderLimit = component.get("v.orderLimit");
        var productId = component.get("v.productId");
        var quantity = component.get("v.f2Quantity");
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        var QtyMinus = 0;
        var limitQty = 0;
        if(typeof productId !== 'undefined' && productId != "")
        {
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.find("brand").get("v.value"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var qtyListDemo = component.get("v.qtyListDemo");
            var demomapFirm = component.get("v.demofmap2");
            var Qty = qtyListDemo[0];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                if(xinst[productId])
                	QtyMinus = QtyMinus+xinst[productId];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }
            Qty = Qty-QtyMinus+quantity;
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f2Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f2Quantity", 0);
        }
        
    },
    
    addProductsf3 : function(component, event, helper){
        var orderLimit = component.get("v.orderLimit");
        var productId = component.get("v.productId");
        var quantity = component.get("v.f3Quantity");
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        var QtyMinus = 0;
        var limitQty = 0;
        if(typeof productId !== 'undefined' && productId != "")
        {
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.find("brand").get("v.value"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var qtyListDemo = component.get("v.qtyListDemo");
            var demomapFirm = component.get("v.demofmap3");
            var Qty = qtyListDemo[0];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                if(xinst[productId])
                	QtyMinus = QtyMinus+xinst[productId];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }
            Qty = Qty-QtyMinus+quantity;
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f3Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f3Quantity", 0);
        }
        
    },
    
    addProductsf4 : function(component, event, helper){
        var orderLimit = component.get("v.orderLimit");
        var productId = component.get("v.productId");
        var quantity = component.get("v.f4Quantity");
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        var QtyMinus = 0;
        var limitQty = 0;
        if(typeof productId !== 'undefined' && productId != "")
        {
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.find("brand").get("v.value"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var qtyListDemo = component.get("v.qtyListDemo");
            var demomapFirm = component.get("v.demofmap4");
            var Qty = qtyListDemo[0];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                if(xinst[productId])
                	QtyMinus = QtyMinus+xinst[productId];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }
            Qty = Qty-QtyMinus+quantity;
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f4Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f4Quantity", 0);
        }
        
    },
    
    addProductsf5 : function(component, event, helper){
        var orderLimit = component.get("v.orderLimit");
        var productId = component.get("v.productId");
        var quantity = component.get("v.f5Quantity");
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        var QtyMinus = 0;
        var limitQty = 0;
        if(typeof productId !== 'undefined' && productId != "")
        {
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.find("brand").get("v.value"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var qtyListDemo = component.get("v.qtyListDemo");
            var demomapFirm = component.get("v.demofmap5");
            var Qty = qtyListDemo[0];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                if(xinst[productId])
                	QtyMinus = QtyMinus+xinst[productId];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }
            Qty = Qty-QtyMinus+quantity;
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f5Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f5Quantity", 0);
        }
        
    },
    
    addProductsf6 : function(component, event, helper){
        var orderLimit = component.get("v.orderLimit");
        var productId = component.get("v.productId");
        var quantity = component.get("v.f6Quantity");
        var msg = $A.get("$Label.c.Vehicle_Order_Qtylimiterror");
        var QtyMinus = 0;
        var limitQty = 0;
        if(typeof productId !== 'undefined' && productId != "")
        {
            var x;
            for(x in orderLimit)
            {
                if(orderLimit[x].brand == component.find("brand").get("v.value"))
                    if(orderLimit[x].variant == component.find("variant").get("v.value"))
                        limitQty = orderLimit[x].quantity;
            }
            var qtyListDemo = component.get("v.qtyListDemo");
            var demomapFirm = component.get("v.demofmap6");
            var Qty = qtyListDemo[0];
            for(var key in demomapFirm)
            {
                var xinst = demomapFirm[key];
                if(xinst[productId])
                	QtyMinus = QtyMinus+xinst[productId];
                for(var key in xinst)
                    Qty = Qty+xinst[key];
            }
            Qty = Qty-QtyMinus+quantity;
            if(quantity>limitQty)
            {
                helper.showError(component, event, helper, msg);
                component.set("v.f6Quantity", QtyMinus);
            }
            else
                helper.addProducts(component, event, helper);
        }else{
            component.set("v.f6Quantity", 0);
        }
        
    },
    
    addRow : function(component, event, helper){
        var compEvent = component.getEvent("AddDeleteRowsDemo");
       	compEvent.setParams({
            "addDelete": "add",
            "rowNumber": component.get("v.rowIndex")
            
        });
        compEvent.fire();
    },
    
    DeleteRow : function(component, event, helper){
        var productId = component.get("v.productId");
        var demoType = component.find("demoType").get("v.value");
        if(typeof productId !== 'undefined' && productId != "")
        {
            var mapFirm = component.get("v.demomapFirm");
        		if(typeof mapFirm[demoType] !== 'undefined')
                {
                    var mapFirmValue = mapFirm[demoType];
                        delete mapFirmValue[productId];
                    mapFirm[demoType] = mapFirmValue;  
                }
            component.set("v.demomapFirm", mapFirm);
            
            var demofmap1 = component.get("v.demofmap1");
        		if(typeof demofmap1[demoType] !== 'undefined')
                {
                    var demofmap1Value = demofmap1[demoType];
                        delete demofmap1Value[productId];
                    demofmap1[demoType] = demofmap1Value;  
                }
            component.set("v.demofmap1", demofmap1);
            
            var demofmap2 = component.get("v.demofmap2");
        		if(typeof demofmap2[demoType] !== 'undefined')
                {
                    var demofmap2Value = demofmap2[demoType];
                        delete demofmap2Value[productId];
                    demofmap2[demoType] = demofmap2Value;  
                }
            component.set("v.demofmap2", demofmap2);
            
            var demofmap3 = component.get("v.demofmap3");
        		if(typeof demofmap3[demoType] !== 'undefined')
                {
                    var demofmap3Value = demofmap3[demoType];
                        delete demofmap3Value[productId];
                    demofmap3[demoType] = demofmap3Value;  
                }
            component.set("v.demofmap3", demofmap3);
            
            var demofmap4 = component.get("v.demofmap4");
        		if(typeof demofmap4[demoType] !== 'undefined')
                {
                    var demofmap4Value = demofmap4[demoType];
                        delete demofmap4Value[productId];
                    demofmap4[demoType] = demofmap4Value;  
                }
            component.set("v.demofmap4", demofmap4);
            
            var demofmap5 = component.get("v.demofmap5");
        		if(typeof demofmap5[demoType] !== 'undefined')
                {
                    var demofmap5Value = demofmap5[demoType];
                        delete demofmap5Value[productId];
                    demofmap5[demoType] = demofmap5Value;  
                }
            component.set("v.demofmap5", demofmap5);
            
            var demofmap6 = component.get("v.demofmap6");
        		if(typeof demofmap6[demoType] !== 'undefined')
                {
                    var demofmap6Value = demofmap6[demoType];
                        delete demofmap6Value[productId];
                    demofmap6[demoType] = demofmap6Value;  
                }
            component.set("v.demofmap6", demofmap6);
            
        }
        
        var compEvent = component.getEvent("AddDeleteRowsDemo");
       	compEvent.setParams({
            "addDelete": "del",
            "rowNumber": component.get("v.rowIndex")
            
        });
        compEvent.fire();
    },
    
})