({
    doinit : function(component, event, helper) {
        var checkUser=component.get('v.checkUser');
        if(checkUser)
        {
           component.set("v.disableGenInvoice",true);   
           component.set("v.disableEdit",true);
        }
        helper.loadAccessoriesrecords(component, event);	
        helper.checkBookingStatus(component, event, helper);
        helper.checkVDNStatus(component, event, helper);
       
    },
    addNewRow: function(component, event, helper) {
        helper.createObjectData(component, event);
    },
     checkselected: function(component, event, helper) {
         var x;
         component.set('v.disableEdit',false);
         var Accessorylist=component.get('v.Acclist');
         for(x in Accessorylist ){
             if(Accessorylist[x].disable==false && Accessorylist[x].Ischecked==true ){
                 component.set('v.disableEdit',true);
              break;   
             }
         }
         
         
     },
    removerow: function(component, event, helper) {
        var index = event.getParam("indexVar");
        var AllRowsList = component.get("v.PartsSelListEdit");
        AllRowsList.splice(index, 1);
        component.set("v.PartsSelListEdit", AllRowsList);
    },
    editacc: function(component, event, helper) {
        var x;
        component.set('v.Detailview',false);
        var RowItemList = component.get("v.PartsSelListEdit");
        var partnumberlist = component.get("v.partnumberlist");
        var acclist=component.get('v.Acclist');
        for(x in  acclist){
            if(acclist[x].Ischecked==false)
            {
                RowItemList.push({
                    'sobjectType ': 'orderitem',
                    'PSA_Part_Number__c':acclist[x].prodname,
                    'Quantity':acclist[x].invqty,
                    'Product2Id':acclist[x].partid,
                    'Id':acclist[x].pricebookid,
                    'Description': acclist[x].ptype,
                    'UnitPrice' :acclist[x].unitprice,
                    'PSA_OEMCGST__c':acclist[x].cgst,
                    'PSA_OEMIGST__c' :acclist[x].cgst,
                    'PSA_OEMSGST__c' : acclist[x].sgst,
                    'Model' :acclist[x].proddesc,
                    'HSNcode':acclist[x].prodhsn,
                    'UOM':acclist[x].produom,
                    'PSA_Taxable_Value__c' : acclist[x].totalBasicValue,
                    'PSA_Total_Tax__c' : acclist[x].totalTax,
                    'PSA_Total_Order_Value__c': acclist[x].totalInvoiceValue,
                    'PSA_Discount__c':acclist[x].discperc,
                    'PSA_Discount_Value__c' :acclist[x].totalDiscountValue
                });
            }else{
                partnumberlist.push(acclist[x]);
                
            }
            
        }
        component.set('v.PartsSelListEdit',RowItemList);
        component.set('v.partnumberlist',partnumberlist);
        if(RowItemList.length==0){
            helper.createObjectData(component, event);
            
        }
        component.set('v.submitvisible',false);
    },
    generateinvoice: function(component, event, helper) {
        var genereateinvoice=component.get('v.genereateinvoice');
        if(genereateinvoice){
            var x;
            var isvalid=false;
            var productlist=[];
            var product=component.get('v.Acclist');
            for(x in product){
                if(product[x].Ischecked==true && product[x].disable==false){
                    isvalid=true;
                    productlist.push({
                        'sobjectType ': 'orderitem',
                        'Id' : product[x].itemid,
                        'Quantity':product[x].invqty,
                        'PSA_Invoiced__c':product[x].Ischecked,
                        'Description' :product[x].ptype,
                        'OrderId' : product[x].orderId,
                        
                    });   
                }
            }
            if(isvalid){
                helper.invpoicerecordcreate(component, event,productlist); 
            }else{
                
                helper.showToast(component,event,'Norecords Selected','Error');
            } 
        }else{
            
            helper.showToast(component,event,'All parts are Invoiced','Success');
            
        }
    },
    canceledit: function(component, event, helper) {
        
        component.set('v.Detailview',true);
        var joblabourlist=component.get('v.PartsSelListEdit');
        for(var i=joblabourlist.length; i>0; i--){
            joblabourlist.splice(0, 1);
        }
        component.set("v.PartsSelListEdit",joblabourlist);
        component.set('v.submitvisible',true);
        var partnumberlist=component.get('v.partnumberlist');
        for(var i=partnumberlist.length; i>0; i--){
            partnumberlist.splice(0, 1);
        }
        component.set("v.partnumberlist",partnumberlist);
    },
    Submitrecord: function(component, event, helper) {
        var PartsSelListEdit = component.get("v.PartsSelListEdit");
        var isvalid=true;
        var finalvalidity=true;
        var childCmp = component.find("accessorychild");
        if(childCmp=='undefined' || childCmp=='' || childCmp==null){
            
        }else{
        if(childCmp.length){
            for(var i=0;i<childCmp.length;i++){
                isvalid=childCmp[i].checkValidation();
                
                if(isvalid==false){
                    finalvalidity=false; 
                }
            }
        }
        else{
           isvalid=childCmp.checkValidation();
        }
        }
        
        if(finalvalidity && isvalid ){
            helper.createaccresorryrecord(component, event,PartsSelListEdit); 
            
        }
        // component.set('v.submitvisible',true);
    }
})