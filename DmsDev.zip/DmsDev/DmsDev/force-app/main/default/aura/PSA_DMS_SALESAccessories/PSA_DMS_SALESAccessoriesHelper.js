({
    createObjectData: function(component,event) {
        var RowItemList = component.get("v.PartsSelListEdit");
        RowItemList.push({
            'sobjectType ': 'orderitem',
            'PSA_Part_Number__c':'',
            'Quantity':'',
            'Product2Id':'',
            'PrickbookentryId':'',
            'Id':'',
            'Description': '',
            'UnitPrice' :'',
            'PSA_OEMCGST__c':'',
            'PSA_OEMIGST__c' :'',
            'PSA_OEMSGST__c' : '',
            'PSA_Taxable_Value__c' :'',
            'PSA_Total_Tax__c' : '',
            'PSA_Total_Order_Value__c': '',
            'PSA_Discount__c':''
            
        });
        component.set("v.PartsSelListEdit", RowItemList);
    },
    loadAccessoriesrecords : function(component, event) {
        debugger;
        var ordid=component.get('v.RecordId');
        var action = component.get("c.getAccessorieslist");
        action.setParams({
            "orderId" : ordid
        });
        action.setCallback(this, function(response){
            var state = response.getState();     
            if (state === "SUCCESS") {
                var responseValue=response.getReturnValue();
                var x;
                var invoiced=false;
                var xlenght=responseValue.length;
                if(xlenght>0){
                    component.set('v.invoicevisible',true);
                }
                component.set('v.Acclist',responseValue);
                for(x in responseValue){
                    invoiced=responseValue[x].invoiced;
               
                    if(responseValue[x].disable==false){
                        component.set('v.genereateinvoice',true);
                        
                    } 
                }
              
                if(!invoiced){
                    
                      component.set('v.disableGenInvoice',true);
                    
                }
            
            
                }
        });
        $A.enqueueAction(action);
    },
    invpoicerecordcreate : function(component, event,productlist) {
        var action = component.get("c.invoicerecordcreate");
        var ordid=component.get('v.RecordId');
        action.setParams({
            "productrecord" : productlist,
            "ordid":ordid
        });
        action.setCallback(this, function(response){
            var state = response.getState();     
            if (state === "SUCCESS") {
                var responseValue=response.getReturnValue();
                this.loadAccessoriesrecords(component, event);
                var pdfurl ='../PSA_SALES_Accessoryinvoice?Id='+responseValue;
                window.open(pdfurl,"_blank","width=600, height=550"); 
                
            } 
        });
        $A.enqueueAction(action);
        
    },
    createaccresorryrecord : function(component, event,productlist) {
        debugger;
        var action = component.get("c.createaccessoryrecords");
        action.setParams({
            "orderitems" : productlist,
            'orderid': component.get('v.RecordId')
        });
        action.setCallback(this, function(response){
            var state = response.getState();     
            if (state === "SUCCESS") {
                var responseValue=response.getReturnValue();
                this.loadAccessoriesrecords(component, event);
                component.set('v.Detailview',true);
                var joblabourlist=component.get('v.PartsSelListEdit');
                for(var i=joblabourlist.length; i>0; i--){
                    joblabourlist.splice(0, 1);
                }
                component.set("v.PartsSelListEdit",joblabourlist);
                var partnumberlist=component.get('v.partnumberlist');
                for(var i=partnumberlist.length; i>0; i--){
                    partnumberlist.splice(0, 1);
                }
                component.set("v.partnumberlist",partnumberlist);
                component.set('v.submitvisible',true);
                this.showToast(component,event,'Accessory records updated Successfully','Success');
            } 
        });
        $A.enqueueAction(action);
    },
    showToast : function(component,event,Message,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": Message,
            "type": type
        });
        toastEvent.fire();  
    },
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid=component.get('v.RecordId');
         var action = component.get("c.checkBookingStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disableEdit",true);
                component.set("v.disableGenInvoice",true);   
                }

                
            }
        });
        $A.enqueueAction(action);	    
	 
},
    checkVDNStatus : function(component, event){
    debugger;
         var bookingid=component.get('v.RecordId');
         var action = component.get("c.checkVDNStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
                component.set("v.disableEdit",true);
                 component.set("v.disableGenInvoice",true);   
                }
 
            }
        });
        $A.enqueueAction(action);	    
	 
}
})