({
    doInit : function(component, event, helper) {   
        
        helper.getbookinglist(component, event, 'OrderNumber',' DESC',null,null,null);        
    },
    sort: function(component, event, helper) {
        
        var c=component.get("v.counting");
        var sSoql;
        if(c==2){
            sSoql = ' asc';
        } if(c==1) {
            sSoql = ' desc';}
        // alert(sSoql);
        helper.getbookinglist(component, event, 'OrderNumber',sSoql);
        
    },
    sort1: function(component, event, helper) {
        var c=component.get("v.counting1");
        var sSoql;
        if(c==2){
            sSoql = ' asc';
        } if(c==1) {
            sSoql = ' desc';}
        helper.getbookinglist(component, event, 'PSA_Invoice__c',sSoql);
        
    },
    sort2: function(component, event, helper) {
        var c=component.get("v.counting2");
        var sSoql;
        if(c==2){
            sSoql = ' asc';
        } if(c==1) {
            sSoql = ' desc';}
        helper.getbookinglist(component, event, 'PSA_Expected_Delivery_Date__c',sSoql);
        
    },
    sort3: function(component, event, helper) {
        var c=component.get("v.counting3");
        var sSoql;
        if(c==2){
            sSoql = ' asc';
        } if(c==1) {
            sSoql = ' desc';}
        helper.getbookinglist(component, event, 'PSA_Status__c',sSoql);
        
    },
    
    
    bookingview : function(component, event, helper) {
        var target = event.getSource().get('v.value');
        var compEvent = component.getEvent("bookingdetailsIdPass");
        compEvent.setParams({"currentMonthlyOrderIdoem" : target });
        compEvent.fire();        
    },
    
    bookingdetailsearch: function(component, event, helper) {        
        console.log("" + event.getSource().get("v.value"));
        var searchkeyword = event.getSource().get("v.value") == undefined ? null : event.getSource().get("v.value");
        component.set("v.searrchkeyword", searchkeyword) ;  
        if(searchkeyword=="" ||searchkeyword==null ||searchkeyword=='undefined' )
        {
          helper.getbookinglist(component, event, 'OrderNumber',' DESC',null,null,null);         
        }
        else{
        var action = component.get('c.BookingDetailsSearch');
           // alert(component.get("v.selectedsearchfieldvalue"));
        action.setParams({          
            'keyvalue' : searchkeyword,
            'selectedfield' : component.get("v.selectedsearchfieldvalue"),
            'checkUser':''
            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {               
                var records =response.getReturnValue();               
                component.set("v.paginationList", records); 
                if(response.getReturnValue().length==0){
                        component.set('v.norecords', true);
                }	else{
                    component.set('v.norecords', false);
                }
            }
        });
        $A.enqueueAction(action);
        }
    },
    
    onclickPO : function(component, event, helper) {
        var target = event.getSource().get('v.value');
        var compEvent = component.getEvent("PartReceiptIdPass");       
        compEvent.setParams({"Id" : target });        
        compEvent.fire();
    },
    
    next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var receiptslist = component.get("v.receipts");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var receiptslist = component.get("v.receipts");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
        /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var accountList = component.get("v.receipts");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
       
        helper.getbookinglist(component, event,'OrderNumber',' Desc');
        //helper.getinvoicelist(component, event);
    },
    Search:function(component, event, helper) {
           
     var fromdate=component.find("fromdate").get("v.value");
     var todate=component.find("todate").get("v.value");
       if((fromdate==''||fromdate==null || fromdate=='undefined')&&(todate=='' || todate==null || todate=='undefined')){
           helper.getbookinglist(component, event, 'OrderNumber',' Desc',null,null,null);     
       }
        else if(todate <fromdate)
        {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Warning!",
            "message": "To Date should not be less than From Date",
            "type": "Error"
        });
        toastEvent.fire();  
        }
        else
        {
             helper.getbookinglist(component, event, 'OrderNumber',' DESC',fromdate,todate,'sample'); 
        }     
          
         
       },
    getListsearch:function(component, event, helper) {
           
     var fromdate=component.find("fromdate").get("v.value");
     var todate=component.find("todate").get("v.value");
       if((fromdate==''||fromdate==null || fromdate=='undefined')&&(todate=='' || todate==null || todate=='undefined')){
           helper.getbookinglist(component, event, 'OrderNumber',' Desc',null,null,null);     
       } 
       },
    
    preventalphabets : function(component, event, helper){
        var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            component.find(id).set("v.value", val.substring(0,0));
        }
    }
})