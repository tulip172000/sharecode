({
	
    showErrormsg : function(component, event, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
    },
    showSuccessmsg : function(component, event) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "message": "Bin records created successfully!"
        });
        toastEvent.fire();
    },
    
    validate  : function(component, event, helper) {
        var id = event.getSource().getLocalId();
        var inp = component.find(id).get("v.value");
        var len;
        if(id == "binrowid" || id == "positionfromid" || id == "positiontoid"){
            len=2;}
        else{
            len=3;}
        var str = inp.toString();
        component.find(id).set("v.value", str.substring(0, len));
    },
    
     validateBinForm : function(component, event, helper){
        
        var isValid = true;
        var binzone = component.find("binzoneid").get("v.value");
        var binrow = component.find("binrowid").get("v.value");
        var fromrack = component.find("rackfromid").get("v.value");
        var torack = component.find("racktoid").get("v.value");
        var fromlevel = component.find("levelfromid").get("v.value");
        var tolevel = component.find("leveltoid").get("v.value");
        
        component.set("v.zoneErrmsg",'');
        $A.util.removeClass(binzone,"disp-block");
        $A.util.addClass(binzone,"disp-none");
        component.set("v.rowErrmsg",'');
        $A.util.removeClass(binrow,"disp-block");
        $A.util.addClass(binrow,"disp-none");
        component.set("v.rackfromErrMsg",'');  
        $A.util.removeClass(fromrack,"disp-block");
        $A.util.addClass(fromrack,"disp-none");
        component.set("v.racktoErrMsg",'');
        $A.util.removeClass(torack,"disp-block");
        $A.util.addClass(torack,"disp-none");
        component.set("v.levelfromErrmsg",'');
        $A.util.removeClass(fromlevel,"disp-block");
        $A.util.addClass(fromlevel,"disp-none");
        component.set("v.leveltoErrMsg",'');
        $A.util.removeClass(tolevel,"disp-block");
        $A.util.addClass(tolevel,"disp-none");
         
        if(binzone == 'undefined'|| binzone == '' || binzone == null){
            isValid = false;
            component.set("v.zoneErrmsg",'Required');
            $A.util.removeClass(binzone,"disp-none");
            $A.util.addClass(binzone,"disp-block");
        }
        if(binrow =='undefined'|| binrow == '' || binrow == null){
            component.set("v.rowErrmsg",'Required');
            $A.util.removeClass(binrow,"disp-none");
            $A.util.addClass(binrow,"disp-block");
            isValid = false;
        }
        if(fromrack =='undefined'|| fromrack == '' || fromrack == null){
            component.set("v.rackfromErrMsg",'Required');
            $A.util.removeClass(fromrack,"disp-none");
            $A.util.addClass(fromrack,"disp-block");
            isValid = false;
        }
        if(torack == 'undefined'|| torack == '' || torack == null){
            component.set("v.racktoErrMsg",'Required');
            $A.util.removeClass(torack,"disp-none");
            $A.util.addClass(torack,"disp-block");
            isValid = false;
        }
        if(fromlevel == 'undefined'|| fromlevel == '' || fromlevel == null){
            component.set("v.levelfromErrmsg",'Required');
            $A.util.removeClass(fromlevel,"disp-none");
            $A.util.addClass(fromlevel,"disp-block");
            isValid = false;
        }
        if(tolevel == 'undefined'|| tolevel == '' || tolevel == null){
            component.set("v.leveltoErrMsg",'Required');
            $A.util.removeClass(tolevel,"disp-none");
            $A.util.addClass(tolevel,"disp-block");
            isValid = false;
        }
         
        return isValid;
         
     },
    
    onchangevalidation : function(component, event, helper){
        var id = event.getSource().getLocalId();
        var binval;
        if(id != undefined)
        binval = component.find(id).get("v.value");
        debugger;
		if(id == 'binzoneid' && (binval != '' || binval != null)){
            component.set("v.zoneErrmsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'binzoneid'){
            component.set("v.zoneErrmsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'binrowid' && (binval != '' || binval != null)){
            component.set("v.rowErrmsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'binrowid'){
            component.set("v.rowErrmsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'rackfromid' && (binval != '' || binval != null)){
            component.set("v.rackfromErrMsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'rackfromid'){
            component.set("v.rackfromErrMsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'racktoid' && (binval != '' || binval != null)){
            component.set("v.racktoErrMsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'racktoid'){
            component.set("v.racktoErrMsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'levelfromid' && (binval != '' || binval != null)){
            component.set("v.levelfromErrmsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'levelfromid'){
            component.set("v.levelfromErrmsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'leveltoid' && (binval != '' || binval != null)){
            component.set("v.leveltoErrMsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'leveltoid'){
            component.set("v.leveltoErrMsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
    }
    
})