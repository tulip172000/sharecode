({
	CreateBinRecords : function(component, event, helper) {
        if(helper.validateBinForm(component)){
            component.set("v.spinner", true);
            var binzone = component.find("binzoneid").get("v.value");
            var binrow = component.find("binrowid").get("v.value").toUpperCase();
            var rackfrom = component.find("rackfromid").get("v.value");
            var rackto = component.find("racktoid").get("v.value");
            var levelfrom = component.find("levelfromid").get("v.value");
            var levelto = component.find("leveltoid").get("v.value");
            var positionfrom = component.find("positionfromid").get("v.value").toUpperCase();
            var positionto = component.find("positiontoid").get("v.value").toUpperCase();
                    
            
            var binzonerow = binzone+binrow;
            var racklevel = [];
            var racklevelcombinations;
            
            for(var i=rackfrom; i<=rackto; i++){
                racklevelcombinations = i.toString();
                
                for(var j=levelfrom; j<=levelto; j++){
                    racklevelcombinations += j.toString(); 
                    racklevel.push(racklevelcombinations);
                    racklevelcombinations = i.toString();
                }
                racklevelcombinations = i.toString();
            }
            
            var action = component.get("c.SaveBinrecord");
            action.setParams({
                "binName" : binzonerow,
                "lstlevelrack" : racklevel,
                "frompos" : positionfrom,
                "topos" : positionto
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state == 'SUCCESS') {
                    component.set("v.spinner", false);
                    var records =response.getReturnValue();
                    if(records.binerror == 'The Level and Rack you entered is already available in system'){
                        helper.showErrormsg(component, event, records.binerror);
                    }
                    else{
                        component.set("v.spinner", false);
                        component.set("v.bincount", records.binrecordcount);
                        component.set("v.binnamespicklist", records.lstbinrecords);
                        helper.showSuccessmsg(component, event);
                    }                                           
                    
                }
            });
            $A.enqueueAction(action);
            
        }
        
	},
    
    validate  : function(component, event, helper) {
       var charCode = event.getParams().keyCode;
          if ((charCode >= 1 && charCode <= 32)||(charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105)) { 
            return true;
       }
        else{
          var message= 'Please Input only Numbers';
          helper.showErrorToast(component,event,message);
        }
    },
    
    checkracktovalues : function(component, event, helper){
        helper.validate(component, event, helper);
        var rackfrom = component.find("rackfromid").get("v.value");
        var rackto = component.find("racktoid").get("v.value"); 
        if(rackto != null && rackto != ""){
            if(rackfrom > rackto){
                var msg = "Rack from value should not be greater than rack to value";
                helper.showErrormsg(component, event, msg);
            }
        }
        if(rackto != '' && rackto != null){
            component.set("v.racktoErrMsg",'');
            $A.util.addClass(rackto,"disp-none");
            $A.util.removeClass(rackto,"disp-block");
        }
        else{
            component.set("v.racktoErrMsg",'Required');
            $A.util.removeClass(rackto,"disp-none");
            $A.util.addClass(rackto,"disp-block");
        }
    },   
    
    checkleveltovalues : function(component, event, helper){
        //helper.validate(component, event, helper);
        var levelfrom = component.find("levelfromid").get("v.value");
        var levelto = component.find("leveltoid").get("v.value");  
        if(levelto != null && levelto != ""){
            if(levelfrom > levelto){
                var msg = "Level from value should not be greater than level to value";
                helper.showErrormsg(component, event, msg);
            }
        }
        if(levelto != '' && levelto != null){
            component.set("v.leveltoErrMsg",'');
            $A.util.addClass(levelto,"disp-none");
            $A.util.removeClass(levelto,"disp-block");
        }
        else{
            component.set("v.leveltoErrMsg",'Required');
            $A.util.removeClass(levelto,"disp-none");
            $A.util.addClass(levelto,"disp-block");
        }
    },
    
    addRow : function(component, event, helper){
        var compEvent = component.getEvent("AddDeleteBinRows");
       	compEvent.setParams({
            "addDelete": "add",
            "rowNumber": component.get("v.rowIndex")
            
        });
        compEvent.fire();
    },
    
    DeleteRow : function(component, event, helper){       
        var compEvent = component.getEvent("AddDeleteBinRows");
       	compEvent.setParams({
            "addDelete": "del",
            "rowNumber": component.get("v.rowIndex")
            
        });
        compEvent.fire();
        
    },    
    
    preventnumbers : function(component, event, helper){
        
        var a = event.getSource();
		var id = a.getLocalId();
        var charCode = event.getParams().keyCode; 
        //if ((charCode > 64 && charCode < 91)){// || (charCode > 8 && charCode < 27) ||  (charCode > 33 && charCode < 48) ){
        if((charCode > 64 && charCode < 91) || (charCode >= 8 && charCode < 27) || (charCode > 33 && charCode < 48)){
        	return true;
        }    
        else{
            component.find(id).set("v.value", '');
            var message= 'Please Input only Alphabets';
            helper.showErrormsg(component,event,message);
        }
        
    },
    
    preventalphabets : function(component, event, helper){
        /*var a = event.getSource();
		var id = a.getLocalId();
        var val = '';
        var charCode = event.getParams().keyCode; 
        if ((charCode > 104 && charCode < 222) || (charCode > 33 && charCode < 48) ){
            component.find(id).set("v.value", parseInt(val));            
        }         
        else{
            var val = component.find(id).get('v.value');
            var str = val.tostring();
            component.find(id).set("v.value", str.substring(0,0));
        }*/
        var a = event.getSource();
		var id = a.getLocalId();
        var charCode = event.getParams().keyCode;
          if ((charCode >= 1 && charCode <= 32)||(charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105)) { 
            return true;
       }
        else{
          var message= 'Please Input only Numbers';            
          helper.showErrormsg(component,event,message);
        }
    },
    
    hiderequiredfields : function(component, event, helper){
        helper.validate(component, event, helper);
        var id = event.getSource().getLocalId();
        var binval;
        if(id != undefined)
        binval = component.find(id).get("v.value");
        
		if(id == 'binzoneid' && (binval != '' && binval != null)){
            component.set("v.zoneErrmsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'binzoneid'){
            component.set("v.zoneErrmsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'binrowid' && (binval != '' && binval != null)){
            component.set("v.rowErrmsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'binrowid'){
            component.set("v.rowErrmsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'rackfromid' && (binval != '' && binval != null)){
            component.set("v.rackfromErrMsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'rackfromid'){
            component.set("v.rackfromErrMsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'racktoid' && (binval != '' && binval != null)){
            component.set("v.racktoErrMsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'racktoid'){
            component.set("v.racktoErrMsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'levelfromid' && (binval != '' && binval != null)){
            component.set("v.levelfromErrmsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'levelfromid'){
            component.set("v.levelfromErrmsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
        if(id == 'leveltoid' && (binval != '' && binval != null)){
            component.set("v.leveltoErrMsg",'');
            $A.util.addClass(binval,"disp-none");
            $A.util.removeClass(binval,"disp-block");
        }
        else if(id == 'leveltoid'){
            component.set("v.leveltoErrMsg",'Required');
            $A.util.removeClass(binval,"disp-none");
            $A.util.addClass(binval,"disp-block");
        }
    }
})