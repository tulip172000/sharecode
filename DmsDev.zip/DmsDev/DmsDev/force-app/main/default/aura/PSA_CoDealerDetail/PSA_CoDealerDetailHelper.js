({
    fetchorderitem : function(component, event) {
       debugger;
        var OrderId = component.get("v.orderId");
        var action = component.get("c.getitems");
        action.setParams({
            "orderid" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var rows = response.getReturnValue();
                
                console.log('POT List>>>>>>'+rows);
                component.set("v.partsList", rows); 
              
            }
        });
        $A.enqueueAction(action);
    },
         getloginuserInfo : function(component, event){
        var action = component.get("c.fetchLoginUserDetails");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log('user Info >>>>'+JSON.stringify(storeResponse));
                if(storeResponse.PSA_Community_Role__c =='Head Aftersales'){
                    component.set("v.RSMprofile", true);
                }
               
            }
        });
        $A.enqueueAction(action);
    },
    listPageHelper : function(component, event){
        var eventListPage = component.getEvent("displayListPageOEM");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },    
    getDealerInfo : function(component, event){
        var action = component.get("c.fetchDealerInfo");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.dealerInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    } ,
      showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
        showErrorToast : function(component,event,Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": Message,
            "type": "error"
        });
        toastEvent.fire(); 
    },
    getOrderInfo : function(component, event){  
        var action = component.get("c.fetchOrderInfo");
        action.setParams({
            "orderid" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {     
                var storeResponse = response.getReturnValue();
                component.set("v.OrderInfo", storeResponse);
               if(storeResponse.Status=='Draft')
                  component.find('Hold').set('v.value',true);
                if(storeResponse.Status=='Confirm')
                  component.find('Release').set('v.value',true);   
                if(storeResponse.Status=='Cancelled')
                  component.find('Cancel').set('v.value',true);   
            }
        });
        $A.enqueueAction(action);
    } ,
    fetchorder : function(component, event){
        var action = component.get("c.fetchordersInfo");
        action.setParams({
            "orderid" : component.get("v.orderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                for(var i=0;i<storeResponse.length;i++){
                    var ordNumber = storeResponse[i].OrderNumber;
                }
                component.set("v.OrderList", storeResponse);
                component.set("v.POnumber",ordNumber);
            }
        });
        $A.enqueueAction(action);
    } ,
     invoiceDetailList : function(component, event, helper){
       
            var action = component.get("c.getInvoiceDetails");
            action.setParams({
                "orderid" : component.get("v.orderId")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    component.set("v.invoiceDeatilList", storeResponse);
                }
            });
            $A.enqueueAction(action);
    },
    currencytowordformat : function(component, event, totalvalue){
         var action = component.get("c.currencytoword");
            action.setParams({
                "invoiceamount" : Math.roundof(totalvalue)
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                     component.set("v.totalinvamount",storeResponse);
                }
            });
            $A.enqueueAction(action);    
    }   
})