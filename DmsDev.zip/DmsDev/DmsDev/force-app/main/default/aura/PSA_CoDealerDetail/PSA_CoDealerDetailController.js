({
    Doinit : function(component, event, helper) {
        helper.fetchorderitem(component, event);
        helper.getDealerInfo(component, event);
        helper.fetchorder(component, event);
        helper.getOrderInfo(component, event);
        helper.invoiceDetailList(component, event);
        helper.getloginuserInfo(component,event);
    },
    Cancel: function(component, event, helper) {
        helper.listPageHelper(component, event);
    },
    RSMCancel: function(component, event, helper) {
        helper.listPageHelper(component, event);
    },
    oncodealerreject:function(component, event, helper){
        
        var OrderId = component.get("v.orderId");
        var action = component.get("c.fetchcodealerApprove");  
        action.setParams({
            "orderid" : component.get("v.orderId"),
            "reviewType" : "Reject"
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {       
                var Message= $A.get("$Label.c.PSA_OEM_Order_Rejected");
                helper.showErrorToast(component,event,'Codealer order rejected');               
                var rows = response.getReturnValue();
                helper.listPageHelper(component, event);;
            }
            
        });
        $A.enqueueAction(action);
    },
    oncodealerApprove:function(component, event, helper){
       
        var OrderId = component.get("v.orderId");
        var action = component.get("c.fetchcodealerApprove");    
        action.setParams({
            "orderid" : component.get("v.orderId"),
            "reviewType" : "Approve"
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {       
           
                helper.showSuccessToast(component,event,'Codealer order Approved Successfully.');               
                 helper.listPageHelper(component, event);
            }      
        });
        $A.enqueueAction(action);
    },
    
    Edit: function(component, event, helper) {  
        var ord = component.get("v.orderitemlist");
        var orderid = component.get("v.orderId"); 
        var eventListPage = component.getEvent("displayEditCodealerpage");
        eventListPage.setParams({"Id" : orderid , "ordlist1" :ord });
        eventListPage.fire();
    },
    resubmit: function(component, event, helper) {
        var OrderId = component.get("v.orderId");
        
        var action = component.get("c.oemapproval");    
        action.setParams({
            "orderid" : component.get("v.orderId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {   
                var Message= $A.get("$Label.c.Local_PO_Resubmit");
                helper.showSuccessToast(component,event,Message);                 
                var rows = response.getReturnValue();
                var compEvent = component.getEvent("displayListPageOEM");
                compEvent.setParams({"listPage" : true });
                compEvent.fire(); 
            }
        });
        $A.enqueueAction(action);
        
    },  
    onTabSelect : function(component, event, helper) {            
        var target = event.currentTarget;
        var id = target.getAttribute("id");
        var prevTab = component.get("v.currTab");
        component.set("v.currTab", id);
        var activate = component.find(id);
        var deactivate = component.find(prevTab);
        $A.util.removeClass(deactivate, "active");
        $A.util.addClass(activate, "active");         
    },   
})