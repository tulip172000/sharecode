({
    doInit : function(component, event, helper) {
        helper.mastertable(component,event);
    },
    BayEditview : function(component, event, helper) {
        
        var target = event.getSource().get('v.value');
        component.set("v.BayId",target);
        component.set("v.EditBay",true); 
    },
    handleEditPage : function(component, event, helper) {
        
        component.set("v.EditBay",false);
        helper.mastertablerefresh(component,event); 
    },
    opentechForm : function(component, event, helper) {
        debugger;
        document.getElementById("myModal").style.display = "block";
    },
    closeBayForm : function(component, event, helper) {
        debugger;
        component.set("v.baynumberErrmsg",'');
        component.set("v.BaydescErrorMsg",'');
        component.set("v.BaytypeErrmsg",'');
        //component.set("v.BaynameErrmsg",'');
        component.set("v.bayviewImage",'');
        component.find("BayNum").set("v.value", "");
        //component.find("BayName").set("v.value", "");
        component.find("Baydesc").set("v.value", "");
        component.find("Baytype").set("v.value", "--None--");
        component.find("checkbox").set("v.value", false);
        document.getElementById("myModal").style.display = "none";
        
    },
    closeEditBayForm : function(component, event, helper) {
        component.set("v.baynumberErrmsg",'');
        component.set("v.BaydescErrorMsg",'');
        component.set("v.BaytypeErrmsg",'');
        component.set("v.BaynameErrmsg",'');
        
        document.getElementById("EditModal").style.display = "none";
        
    },
    
    bayview:function(component,event,helper){ 
        debugger;
        var Baytype = component.find("Baytype").get("v.value");
        component.set("v.bayviewImage", Baytype);
    },
    
    createBay : function(component, event, helper) {
        if(helper.validatePartForm(component)) {
            helper.saverequest(component,event)  
        }
    },
    
       next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var bayslist = component.get("v.Baylist");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = bayslist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var bayslist = component.get("v.Baylist");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = bayslist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
         /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var bayList = component.get("v.Baylist");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = bayList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.mastertable(component, event);
    },
    
    bayssearch:function(component, event, helper){
        debugger;
          console.log("" + event.getSource().get("v.value"));
    	var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");  
        if(pot == null || pot == 'undefined' || pot==""){
            helper.mastertable(component,event);   
        }else{
            var action = component.get('c.findbay');
        action.setParams({
            'bayno' : pot,
          
            
        });
             action.setCallback(this, function(response){
            var state = response.getState();
            console.log(""+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                console.log("Inside "+state);
                component.set("v.paginationList", records);
            }
                 });
        $A.enqueueAction(action);
        }
    },     
      onCreditLimit: function(component, event, helper){
        var selected = event.getSource().getLocalId();
         alert(selected);
        component.set('v.credlimit',selected);
        
    },
    onactive:function(component, event, helper){
        var active=component.find("checkbox").get("v.value");
        if(active){
            component.set("v.inactivecheckbox",true);
            component.find("inactivecheckbox").set("v.value",false);
        }
        else{
             component.set("v.inactivecheckbox",false);
        }
    },
      oninactive:function(component, event, helper){
        var active=component.find("inactivecheckbox").get("v.value");
        if(active){
            component.set("v.activecheckbox",true);
            component.find("checkbox").set("v.value",false);
        }
        else{
             component.set("v.activecheckbox",false);
        }
    }
    
})