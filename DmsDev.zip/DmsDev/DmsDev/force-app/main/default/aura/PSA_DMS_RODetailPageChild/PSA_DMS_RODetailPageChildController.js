({
    addRow : function(component, event, helper){
        var compEvent = component.getEvent('AddPartRowEvt');
        compEvent.fire();  
    },
    DeleteRow : function(component, event, helper){
        
        component.find('partsAmount').set('v.value',0);
        var compEvent1 = component.getEvent("calcOTC");
        compEvent1.fire();
        var compEvent = component.getEvent("DeletePartRowEvt");
        compEvent.setParams({
            "indexVar": component.get("v.rowIndex")
        });
        compEvent.fire();
        
        
    }, 
    recordChanges : function(component, event, helper){
        debugger;
        var partName = component.get("v.selectedPartRecord");
        var partid=partName.Id;
        var priceId;
        var unitprice;
        component.set("v.partmsg",'');
        if(partid == "undefined" || partid == '' || partid == null ){
            component.set('v.PartRecord',null);
            component.find('PartNumber').set('v.value','');
            component.find('Quantity').set('v.value','');
            component.set('v.TotalAmount','');
            component.set('v.Taxamount','');
            component.set('v.igst','');
            component.set('v.cgst','');
            component.set('v.sgst','');
            component.set('v.cess','');
            component.set("v.quanityerrmsg",'');
            component.set("v.parterrmsg",'');
            component.set('v.TotalAmountIncTax','');
            component.set('v.Avilablestock','');
            component.set("v.partRateperUnit",'' );     
            component.set('v.partDescription','');
            component.set('v.PartNumbr',true);
            component.set('v.descrvisible',true);
            component.set('v.qyvisiable',true);
            component.set('v.partRateperUnit','');
            component.find('partsAmount').set('v.value',0);
            var compEvent = component.getEvent("calcOTC");
            compEvent.fire();
        }else{ 
            var partdesc=partName.PSA_Part_Description__c;
           // component.set('v.partDescription',partdesc);
            var isvalid=true; 
            var partnum=partName.Id;
            component.set("v.quanityerrmsg",'');
             component.set("v.parterrmsg",'');
             component.set('v.descrvisible',false);
            var partschecklist=component.get('v.PartsSelListEdit');
            var size = partschecklist.length;
            var action = component.get("c.getPartrate");
            action.setParams({
                "partId" : partid
            });
            action.setCallback(this, function(response){
                var state = response.getState();
               
                if (state == "SUCCESS") {
                     var value = response.getReturnValue();
                   
                    var x;
                    for(x in partschecklist){
                        if(partschecklist[x].Product2Id==value[0].Id)
                        {
                           var Message='PartNumber Already Exist' ;
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "type": "error",
                                "message": Message
                            });
                            toastEvent.fire();
                            component.getEvent("DeletePartRowEvt").setParams({
                            "indexVar" : size-1}).fire();
                            // component.set("v.spinner", false);
                            isvalid=false; 
                        }
                        
                    }
                    
                    if(isvalid){
                        var partdesc=partName.PSA_Part_Description__c;
                        
                        component.set('v.PartRecord',partName);
                        component.set('v.descrvisible',false);
                         component.set('v.partDescription',partdesc);
                        component.set('v.igst',partName.PSA_IGST__c);
                        component.set('v.cgst',partName.PSA_CGST__c);
                        component.set('v.sgst',partName.PSA_SGST__c);
                        component.set('v.cess',0);
                        component.set('v.itemInstance.UnitPrice',value[0].UnitPrice);
                        component.set("v.partRateperUnit", value[0].UnitPrice);
                        component.find('PartNumber').set('v.value', value[0].Id);
                        var avilable=partName.Inventory_Vehicles__r;
                        if(avilable!= "undefined" && avilable!= '' && avilable != null )
                         {
                          if(avilable[0].PSA_Quantity__c != 'undefined' && avilable[0].PSA_Quantity__c != '' && avilable[0].PSA_Quantity__c != null ){
                          component.set('v.qyvisiable',false);
                         }
                         }
                        component.set('v.Avilablestock',avilable[0].PSA_Quantity__c);
                    }
                }
                
            });
            $A.enqueueAction(action);
        }
    },
    descChanges : function(component, event, helper){
        debugger;
        var partName = component.get("v.selectedLookUpRecordDesc");
        var partid=partName.Id;
        component.set("v.partmsg",'');
        if(partid == "undefined" || partid == '' || partid == null ){
            
            component.set('v.PartRecord',null);
            component.find('PartNumber').set('v.value','');
            component.find('Quantity').set('v.value','');
            component.set('v.Avilablestock','');
            component.set('v.quanityerrmsg','');
            component.set('v.PartNumbr',true);
            component.set('v.partnumber1','');
            component.set('v.descrvisible',true);
            component.set('v.qyvisiable',true);
            component.set('v.Taxamount','');
            
            component.set("v.quanityerrmsg",'');
            component.set("v.parterrmsg",'');
            component.set('v.igst','');
            component.set('v.cgst','');
            component.set('v.sgst','');
            component.set('v.cess','');
            component.set('v.TotalAmountIncTax','');
            component.set('v.partRateperUnit','');
            component.find('partsAmount').set('v.value',0);
            var compEvent = component.getEvent("calcOTC");
            compEvent.fire();
            
            
        }else{
            var isvalid=true; 
            var partnum=partName.Id;
             var parNum=partName.PSA_Part_Number__c;
              component.set('v.partnumber1',parNum);
              component.set('v.PartNumbr',false);
            component.set("v.quanityerrmsg",'');
            component.set("v.parterrmsg",'');
            var partschecklist=component.get('v.PartsSelListEdit');
            var size = partschecklist.length;
            var action = component.get("c.getPartrate");
            action.setParams({
                "partId" : partid
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var value = response.getReturnValue();
                    var x;
                    for(x in partschecklist){
                        if(partschecklist[x].Product2Id==value[0].Id){
                            
                            var Message='PartNumber Already Exist' ;
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "type": "error",
                                "message": Message
                            });
                            toastEvent.fire();
                             component.getEvent("DeletePartRowEvt").setParams({
                            "indexVar" : size-1}).fire();
                            // component.set("v.spinner", false);
                            isvalid=false; 
                            
                        }
                        
                    }
                    
                    if(isvalid){
                        var partdesc=partName.PSA_Part_Description__c;
                      
                        
                        component.set('v.PartRecord',partName);
                        component.set('v.PartNumbr',false);
                       
                        component.set('v.partDescription',partdesc);
                        component.set('v.igst',partName.PSA_IGST__c);
                        component.set('v.cgst',partName.PSA_CGST__c);
                        component.set('v.sgst',partName.PSA_SGST__c);
                        component.set('v.cess',0);
                        component.set('v.itemInstance.UnitPrice',value[0].UnitPrice);
                        component.set("v.partRateperUnit", value[0].UnitPrice);
                        component.find('PartNumber').set('v.value', value[0].Id);
                        var avilable=partName.Inventory_Vehicles__r;
                        var avilable=partName.Inventory_Vehicles__r;
                       
                         if(avilable!= "undefined" && avilable!= '' && avilable != null )
                         {
                          if(avilable[0].PSA_Quantity__c != 'undefined' && avilable[0].PSA_Quantity__c != '' && avilable[0].PSA_Quantity__c != null ){
                          component.set('v.qyvisiable',false);
                         }
                         
                         }
                        component.set('v.Avilablestock',avilable[0].PSA_Quantity__c);
                    }
                }
                
            });
            $A.enqueueAction(action);
        }
    },
    getTotalAmount : function(component, event, helper){
        var partName = component.get("v.PartsSelListEdit");
        var Rate=component.get('v.partRateperUnit');
        var avalQty=component.get('v.Avilablestock');
        var qty=component.find('Quantity').get('v.value');
        component.set("v.quanityerrmsg",'');
        
        $A.util.removeClass(qty,"disp-block");
        $A.util.addClass(qty,"disp-none");
        if(qty<=0 || qty=='' || qty=='undefined'){
            component.find('Quantity').set('v.value',null);
            component.set('v.TotalAmount','');
            component.set('v.Taxamount','');
            component.set('v.TotalAmountIncTax','');
            component.set("v.quanityerrmsg",'Quantity must greater than Zero');
           /* $A.util.removeClass(qty,"disp-none");
            $A.util.addClass(qty,"disp-block");
            component.find('quantity').set('v.value',null);
            alert('s');*/
            
            component.find('partsAmount').set('v.value','');
            var compEvent = component.getEvent("calcOTC");
            compEvent.fire();
           
        }
       else if(parseInt(avalQty)< parseInt(qty)){                   
            var Message= "Quantity is Exceeded ";
            component.find('Quantity').set('v.value',null);
            component.set('v.TotalAmount','');
            component.set('v.Taxamount','');
            component.set('v.TotalAmountIncTax','');
            helper.showErrorToast(component,event,Message);
           component.find('partsAmount').set('v.value','');
            var compEvent = component.getEvent("calcOTC");
            compEvent.fire();
       }
        else{
            var total=parseInt(Rate) * parseInt(qty);
            component.set('v.TotalAmount',total);
            var partrec=component.get('v.PartRecord');
            var CGST = partrec.PSA_CGST__c;
            var SGST = partrec.PSA_SGST__c;
            var IGST = partrec.PSA_IGST__c;
            var GST = CGST+SGST;
            var GSTamt =(total/100)*GST;
            
            var totalordervalue=total+Math.round(GSTamt);
            component.set('v.Taxamount',Math.round(GSTamt));
            component.set('v.TotalAmountIncTax',totalordervalue);
            component.find('partsAmount').set('v.value',totalordervalue);
            //partName.PSA_Parts_Amounts_Exl_Tax__c;
            var compEvent = component.getEvent("calcOTC");
            compEvent.fire();
            
        }
    },
    handleValidation : function(component,event,helper){
        var isvalid=true;
        var sbins = component.find('Quantity').get('v.value');
        var part = component.find('PartNumber').get('v.value');
        component.set("v.quanityerrmsg",'');
        $A.util.removeClass(sbins,"disp-block");
        $A.util.addClass(sbins,"disp-none");
        component.set("v.parterrmsg",'');
        $A.util.removeClass(part,"disp-block");
        $A.util.addClass(part,"disp-none");
        if(sbins == 'undefined'|| sbins == '' || sbins == null){
            isvalid=false;
            component.set("v.quanityerrmsg",'This is a Required Field');
            $A.util.removeClass(sbins,"disp-none");
            $A.util.addClass(sbins,"disp-block");
        } 
        if(part == 'undefined'|| part == '' || part == null){
            isvalid=false;
            component.set("v.parterrmsg",'This is a Required Field');
            $A.util.removeClass(part,"disp-none");
            $A.util.addClass(part,"disp-block");
        } 
        return isvalid;
    },
    qtyvalidate  : function(component, event, helper) {
      
        var mobinp = component.find("Quantity").get("v.value");
        
        if ( /[^\d]/.test(mobinp)) {
            component.find("Quantity").set("v.value", '');
            component.set("v.TotalAmountIncTax", '');
            component.set("v.Taxamount", '');
            component.set("v.TotalAmount", '');
            component.find('partsAmount').set('v.value','');
            var message= 'Please Input only Numbers';
            helper.showErrorToast(component,event,message);
            var compEvent = component.getEvent("calcOTC");
            compEvent.fire();
        }
    
    },
})