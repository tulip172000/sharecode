({
    poevent : function(component , event , helper){
        var items_eve = event.getParam("items");
        component.set("v.partItems",items_eve);
        // invoke calculation function 
        helper.hlpautoCal(component , event , helper);
    },
    invoiceevent : function(component , event , helper){
        var items_eve = event.getParam("items");
        component.set("v.InvoiveDetailList",items_eve);
        // invoke calculation function 
        helper.hlpautoCalInvoice(component , event , helper);
    },
    
    doInit : function(component, event, helper) {
        var cid = component.get("v.currentId");
        
        if(component.get("v.currentId"))
        {
            //  helper.getGRNNUmber(component , event , helper);
            var action = component.get("c.loadPartReceipt");
            action.setParams({
                "id" : component.get("v.currentId")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var value = response.getReturnValue();
                    component.set("v.selectedLookUpRecordINV", value);                    
                    component.set("v.partType",'invoice');
                    component.set("v.InvoiveDetailList", value.Invoice_Details__r); 
                    component.set("v.Invoiceinfo",value);                   
                    helper.hlpautoCalInvoice(component, event, helper);
                    console.log(value.Invoice_Details__r);
                    
                    
                }
            });
            $A.enqueueAction(action);
            
        }
    },
    
    onfocusInvoice : function(component, event, helper) {
        component.set("v.partType", "invoice");
        
    },
    
    onfocusPO : function(component, event, helper) {
        var query = 'select id, OrderNumber, PSA_Quantity__c, (select id,Name,PSA_Local_Parts_Master__r.PSA_Part_Number__c,PSA_Local_Parts_Master__r.PSA_HSN_Code__c,PSA_Local_Parts_Master__r.PSA_Units__c,PSA_Rate_per_unit__c,PSA_GST__c,PSA_Net_Amount__c,PSA_Quantity__c,PSA_Dealer_Parts_Association__r.PSA_IGST__c,PSA_Dealer_Parts_Association__r.PSA_CGST__c,PSA_Dealer_Parts_Association__r.PSA_SGST__c,PSA_Local_Parts_Master__r.PSA_Part_Description__c,PSA_Shortage_Qty__c,PSA_Damaged_Qty__c,PSA_Received_Qty__c FROM Parts_Order_Item__r),Account.Id,Account.Dealer_Code__c,Account.Name,Account.BillingCity,Account.BillingState,CreatedDate,Part_Receipt_Created__c,PSA_Vendor__c,PSA_Vendor__r.Name FROM Order WHERE Part_Receipt_Created__c != true AND recordtypeid=';
        
        var status ='Approved';
        var recordtypeid =$A.get("$Label.c.Local_PO_RecordType");
        var newString = '\''+ recordtypeid + '\'';
        var statusnew='\''+ status + '\'';
        query+= newString + 'AND '+'Status__c='+statusnew+' AND OrderNumber LIKE: searchKey order by createdDate Limit 5';
        component.set("v.localquery",query);
        component.set("v.partType", "PO");        
    },
    
    recordChanges : function(component, event, helper) {
        component.set("v.partItems",{});
        component.set("v.InvoiveDetailList", {});
        var partType = component.get("v.partType");
        if(partType == "PO")
        {	
            var selectedLookUpRecord = component.get("v.selectedLookUpRecord");
            if(selectedLookUpRecord != ""){
                component.set("v.partItems", selectedLookUpRecord.Parts_Order_Item__r);
                
                helper.hlpautoCal(component , event , helper);
                
            }
        }
        else if(partType == "invoice")
        {            
            helper.hlpINVDetails(component , event , helper);            
        }
    },
    /* Vineeta Added to Fix Create GRN Controller issue */
    ctrcreatePartReceipt : function(component , event,helper){     
        helper.hlpPOGRN(component,event,helper);       
    },
    
    CalculateGRN : function(component, event, helper) {
        helper.PopulateGRNvalues(component , event , helper);    
    },
    
    createPartReceipt : function(component, event, helper) {
        debugger;
        helper.PopulateGRNvalues(component,event,helper);
        if(component.get("v.partType") == 'invoice' && calqty)
        {           
            var InvoiveDetailList = component.get("v.InvoiveDetailList");
            console.log('InvoiveDetailList'+JSON.stringify(InvoiveDetailList));            
            var action1 = component.get("c.createPartReceiptGRN");            
            action1.setParams({
                "inv" : InvoiveDetailList
            });
            
            action1.setCallback(this, function(response){                
                var state = response.getState();                
                if (state === "SUCCESS") {
                    var value = response.getReturnValue();
                    var Message= $A.get("$Label.c.GRN_Creation");
                    helper.successToast(component,event,Message);                   
                    component.set("v.GRNNumber", value.PSA_GRN_number__c);
                    component.set("v.displayCreateButton", false);                  
                    
                }
            });
            $A.enqueueAction(action1);
            
        }
        if(component.get("v.partType") == 'PO')
        {
            debugger;
            var x = component.get("v.partItems");
            var ord = component.get("v.selectedLookUpRecord");
            var action = component.get("c.createPartReceiptGRN_PO");
            var arrivaldate = component.find("arrivaldate").get("v.value");
            //var invoicenumber = component.find("invoiceNumber").get("v.value");
            action.setParams({
                "ord" : ord,
                //"invnumber":invoicenumber,
                "partItems" : component.get("v.partItems"),
                "materialvalue":component.get("v.materialValuePO"),
                "taxvalue":component.get("v.taxValuePO"),
                "invoicevalue":component.get("v.invoicevaluePO"),
                "freightvalue":component.get("v.freightvaluePO"),
                "receivedvalue":component.get("v.receivedValuePO"),
                "damagevalue":component.get("v.damagevaluePO"),
                "shortagevalue":component.get("v.shortagevaluePO"),
                "grnvalue":component.get("v.GRNvaluePO")
                
            });
            action.setCallback(this, function(response){
                var state = response.getState();            
                
                if (state === "SUCCESS") {                   
                    var value = response.getReturnValue();
                    component.set("v.GRNNumber", value.PSA_GRN_number__c);
                    var Message= $A.get("$Label.c.GRN_Creation");
                    helper.successToast(component,event,Message);                     
                    component.set("v.displayCreateButton", false);                                  
                }   
                else{
                    var errors = response.getError();                  
                }                
            });
            $A.enqueueAction(action);
        }
        
    },
    Cancel : function(component, event, helper) {
        component.set("v.GRNNumber", "");
        component.set("v.selectedLookUpRecord", "");
        component.set("v.currentId", "");
        component.set("v.partItems", "");
        component.set("v.InvoiveDetailList", "");
        component.set("v.PartGRN", false);
    },
    damageChange : function(component, event, helper) {
        if(!component.get("v.PartReceiptRecord.PSA_Report_Damage__c"))
        {
            component.set("v.PartReceiptRecord.PSA_Report_Damage_Reason__c", null);
            component.set("v.PartReceiptRecord.PSA_Report_Damage_Decription__c", null);
        }
    },
    shortageChange : function(component, event, helper) {
        if(!component.get("v.PartReceiptRecord.PSA_Report_Shortage__c"))
        {
            component.set("v.PartReceiptRecord.PSA_Report_Shortage_Reason__c", null);
            component.set("v.PartReceiptRecord.PSA_Report_Shortage_Description__c", null);
        }
    },
})