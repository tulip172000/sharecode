({
	loadAccessoriesrecords : function(component, event) {
        debugger;
        var ordid=component.get('v.RecordId');
        var action = component.get("c.getdeliveryaccessrecord");
        action.setParams({
            "orderId" : ordid
        });
        action.setCallback(this, function(response){
            var state = response.getState(); 
             
            if (state === "SUCCESS") {
                var responseValue=response.getReturnValue();
               
                component.set('v.accessoryrecord',responseValue);
            
                var orderitem=responseValue.OrderItems;
                component.find('fitmentrecord').set('v.value',responseValue.Status);
                 component.find('reqdate').set('v.value',responseValue.PSA_Request_Date__c);
                 component.find('duedate').set('v.value',responseValue.PSA_Due_Date__c);
                
                component.set('v.orderproducts',orderitem);
                 component.set('v.localproducts',responseValue.Parts_Order_Item__r);
            }else{
                 component.set('v.Submitdisable',true);
                 component.set('v.printdisabled',true);
                
                
            }
        });
        $A.enqueueAction(action);
    },
    showToast : function(component,event,Message,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": Message,
            "type": type
        });
        toastEvent.fire();  
    },
    checkBookingStatus : function(component, event){
    debugger;
         var bookingid=component.get('v.RecordId');
         var action = component.get("c.checkDeliveryStatus");
        
        action.setParams({
                "booknum" :bookingid
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
            {
                var storeResponse = response.getReturnValue();
                if(storeResponse){
               
                component.set("v.Submitdisable",true);
                component.set('v.printdisabled',true);
                  
                }
            }
        });
        $A.enqueueAction(action);	    
	 
},
})