({
	 stockrecords : function(component,event,currentyear) {
        var action = component.get("c.stockrecords");
          action.setParams({
            "yrVal": currentyear
        })
         action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.stocktargets", response.getReturnValue());
                
            };
        });
        $A.enqueueAction(action);
		
	},
})