({
	doInit : function(component, event, helper) {
        var acc = component.get("c.getaccountid");
        acc.setCallback(this, function(response){
            component.set("v.AccountId", response.getReturnValue());
        });
        $A.enqueueAction(acc);
        
        var cid = component.get("v.currentId");        
        if(component.get("v.currentId"))
        {
            //  helper.getGRNNUmber(component , event , helper);
            var action = component.get("c.loadPartReceipt");
            action.setParams({
                "id" : component.get("v.currentId")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var value = response.getReturnValue();
                    component.set("v.selectedLookUpRecordINV", value);
                    component.set("v.partType",'invoice');
                    component.set("v.InvoiveDetailList", value.Invoice_Details__r);
                    component.set("v.Invoiceinfo",value);
                    //helper.hlpautoCalInvoice(component, event, helper);
                    console.log(value.Invoice_Details__r);  
                    var invdetails = component.get("v.InvoiveDetailList");
                    var sumoftax=0;
                    var sumofinctax=0;
                    var sumofexcltax=0;
                    for(var i = 0; i < invdetails.length; i++){
                        sumoftax += invdetails[i].Tax_Amount__c;
                        sumofinctax += invdetails[i].Invoice_Amount__c;
                        sumofexcltax += invdetails[i].PSA_Taxable_Value__c;
                    }
                    component.set("v.selectedLookUpRecordINV.Tax_Amount__c", sumoftax);
                    component.set("v.selectedLookUpRecordINV.Invoice_Amount__c", sumofinctax);
                    component.set("v.selectedLookUpRecordINV.PSA_Taxable_Value__c", sumofexcltax);
                }
            });
            $A.enqueueAction(action);
            
        }
    },
    
    SavePartReceiptRecords : function(component,event,helper){  
        if(helper.validatePartreceiptForm(component, event, helper)){
            component.set("v.FinalPartreceiptrecords", null);
            component.set('v.validationcheck',true);
            var childCmp = [];
            if(component.get("v.partType") == 'Local PO'){            
                childCmp = component.find("partitemchildcmprows");
                if(childCmp.length == undefined)
                    component.find("partitemchildcmprows").saverecords();
            }else{
                childCmp = component.find("invoicedetailchildcmprows");
                if(childCmp.length == undefined)
                    component.find("invoicedetailchildcmprows").saverecords();
            }
            //var childCmp = component.find("invoicedetailchildcmprows");
            if(childCmp.length > 0){
                for(var i=0; i<childCmp.length; i++){
                    //childCmp[i].checkvalidation(); 
                    //if(component.get('v.validationcheck'))
                        childCmp[i].saverecords();
                } 
            }        
            var isvalid=component.get('v.validationcheck');
            if(isvalid)
            {  
                helper.savepartreceiptshelper(component,event);  
            }
        }
    },
    
    SaveStockPartReceiptRecords : function(component,event,helper){  
        if(helper.validatestockPartreceiptForm(component, event, helper)){
            component.set("v.FinalPartreceiptrecords", null);
            component.set('v.validationcheck',true);
            var childCmp = [];           
            childCmp = component.find("stockpartitemchildcmprows");
            if(childCmp.length == undefined)
                component.find("stockpartitemchildcmprows").saverecords();

            if(childCmp.length > 0){
                for(var i=0; i<childCmp.length; i++){
                    //childCmp[i].checkvalidation(); 
                    //if(component.get('v.validationcheck'))
                    childCmp[i].saverecords();
                } 
            }        
            var isvalid=component.get('v.validationcheck');
            if(isvalid)
            {  
                helper.savestockpartreceiptshelper(component,event);  
            }
        }
    },
    
    PartsRecordmerge : function(component,event,helper){
        var singlebinlist = event.getParam("ordlist");
        var bool = event.getParam("listPage");
        if(component.get('v.validationcheck')){
            component.set('v.validationcheck', bool)
        }
        //if(component.get("v.FinalPartreceiptrecords").length > 0){
        if(component.get("v.FinalPartreceiptrecords") != null){
			var arr = [];
        	var existingrecord = component.get("v.FinalPartreceiptrecords");
            for(var i=0; i<existingrecord.length; i++){
                arr.push(existingrecord[i]);
            }
        	arr.push(singlebinlist[0]);
            component.set("v.FinalPartreceiptrecords", arr);
        }
        else{
            component.set("v.FinalPartreceiptrecords", singlebinlist);
        }
                
    },
    
    StockrecordChanges : function(component, event, helper) {
        var cmpTarget = component.find('submitbtnstock');
        $A.util.removeClass(cmpTarget, 'disablebtn');
        component.set("v.partItems",{});
        component.set("v.orderItems",{});
        component.set("v.InvoiveDetailList", {});
        var partType = component.get("v.partType");
        
        var selectedLookUpRecordStock = component.get("v.selectedLookUpRecordStock");
        if(selectedLookUpRecordStock != "" && selectedLookUpRecordStock.OrderItems != undefined){
            component.set("v.orderItems", selectedLookUpRecordStock.OrderItems);
            if(component.get("v.partType") == 'Co-Dealer'){ 
                var orderdetails = component.get("v.orderItems");
                var sumoftax=0;
                var sumofinctax=0;
                var sumofexcltax=0;
                for(var i = 0; i < orderdetails.length; i++){
                    sumoftax += orderdetails[i].PSA_Total_Tax__c;
                    sumofinctax += orderdetails[i].PSA_Total_Order_Value__c;
                    sumofexcltax += orderdetails[i].PSA_Taxable_Value__c;
                }
                component.set("v.taxvalue", sumoftax);
                component.set("v.totalinvoicevalue", sumofinctax);
                component.set("v.invvalueexclgst", sumofexcltax);
            }
        }  
        else if(selectedLookUpRecordStock.OrderItems == null || selectedLookUpRecordStock.OrderItems == undefined){
            component.set("v.totalinvoicevalue", null); component.set("v.invvalueexclgst", null);
            component.set("v.invnumber", ""); component.set("v.taxvalue", null);
            component.set("v.podnumber", "");component.set("v.transportername", ""); 
            component.set("v.ewaybill", "");component.set("v.docketno", ""); 
            component.set("v.grndate", "");component.set("v.grnnumber", "");
            component.set("v.receiptdate", "");component.set("v.selectedLookUpRecordStock.PSA_Fulfilment_Branch_code__c", "");
            component.set("v.selectedLookUpRecordStock.PSA_Fulfilment_Branch_Location__c", "");
            component.set("v.invdateErrMsg",'');component.set("v.invnoErrmsg",'');component.set("v.ponumberErrmsg",'');
        	component.set("v.podnumberErrMsg",'');component.set("v.receiptdateErrmsg",'');
        }  
    },
    
    recordChanges : function(component, event, helper) {
        var cmpTarget = component.find('submitbtn');
        $A.util.removeClass(cmpTarget, 'disablebtn');
        component.set("v.partItems",{});
        component.set("v.InvoiveDetailList", {});
        var partType = component.get("v.partType");
        
        var selectedLookUpRecord = component.get("v.selectedLookUpRecord");
        if(selectedLookUpRecord != "" && selectedLookUpRecord.Parts_Order_Item__r != undefined){
           
            component.set("v.partItems", selectedLookUpRecord.Parts_Order_Item__r);
            var partdetails = component.get("v.partItems");
            var sumoftax=0;
            var sumofinctax=0;
            var sumofexcltax=0;
            for(var i = 0; i < partdetails.length; i++){
                sumoftax += partdetails[i].PSA_GST_Amount__c;
                sumofinctax += partdetails[i].PSA_Net_Amount__c;
                sumofexcltax += partdetails[i].PSA_Total_Amount__c;
            }
            component.set("v.taxvalue", sumoftax);
            component.set("v.totalinvoicevalue", sumofinctax);
            component.set("v.invvalueexclgst", sumofexcltax);
            component.set("v.suppliername",selectedLookUpRecord.PSA_Vendor__r.Name);
            component.set("v.disableSupplier",true);
        }
        else if(selectedLookUpRecord.Parts_Order_Item__r == null || selectedLookUpRecord.Parts_Order_Item__r == undefined){
            component.set("v.taxvalue", null);component.set("v.suppliername",null);
            component.set("v.totalinvoicevalue", null); component.set("v.disableSupplier",false);
            component.set("v.invvalueexclgst", null); component.set("v.podnumber", "");
            component.set("v.invnumber", ""); component.set("v.invdate", null);
            component.set("v.supplyplant", ""); component.set("v.suppliername", "");
            component.set("v.transportername", ""); component.set("v.ewaybill", "");
            component.set("v.docketno", ""); component.set("v.grndate", "");
            component.set("v.grnnumber", ""); component.set("v.receiptdate", "");
            component.set("v.invdateErrMsg",'');component.set("v.invnoErrmsg",'');
        	component.set("v.podnumberErrMsg",'');component.set("v.receiptdateErrmsg",'');
            component.set("v.ponumberErrmsg",'');
        }        
    },
    
    onfocusPO : function(component, event, helper) {
        //var query = 'select id, OrderNumber, (select id,Name,PSA_Local_Parts_Master__r.PSA_Part_Number__c,PSA_Local_Parts_Master__r.PSA_HSN_Code__c,PSA_Local_Parts_Master__r.PSA_Units__c,PSA_Rate_per_unit__c,PSA_GST__c,PSA_Net_Amount__c,PSA_Quantity__c,PSA_Dealer_Parts_Association__r.PSA_IGST__c,PSA_Dealer_Parts_Association__r.PSA_CGST__c,PSA_Dealer_Parts_Association__r.PSA_SGST__c,PSA_Dealer_Parts_Association__r.PSA_CESS__c,PSA_Local_Parts_Master__r.PSA_Part_Description__c,PSA_Shortage_Qty__c,PSA_Damaged_Qty__c,PSA_Received_Qty__c FROM Parts_Order_Item__r),Account.Id,Account.Dealer_Code__c,Account.Name,Account.BillingCity,Account.BillingState,CreatedDate,Part_Receipt_Created__c,PSA_Vendor__c,PSA_Vendor__r.Name FROM Order WHERE Part_Receipt_Created__c != true AND recordtypeid=';
        var query='';
        if(component.get("v.potype") == 'StockTransfer'){
         	query = 'SELECT Id, OrderNumber, (select Id, Product2Id, Product2.PSA_Part_Number__c, Product2.PSA_Part_Description__c, OrderId, Product2.PSA_HSN_Code__c, Product2.QuantityUnitOfMeasure, Quantity, UnitPrice, Product2.PSA_Min_Inv_Level__c, Product2.PSA_Max_Inv_Level__c, Product2.PSA_Reorder_Level__c, Product2.PSA_Safety_Stock__c,PSA_Indent_Qty__c,PSA_Transfer_Qty__c, PSA_Indent_Value__c, PSA_Transfer_Value__c from OrderItems), PSA_Request_Date__c, PSA_Transfer_Request_Number__c, PSA_Approver_Comments__c, PSA_Approval_Status__c, PSA_Approved_Date__c, PSA_Approved_By__c, PSA_Requested_By__c, PSA_Dealer_Remarks__c, PSA_Fulfilment_Branch_Location__c, PSA_Fulfilment_Branch_code__c, PSA_Total_Request_Value__c, PSA_Requested_Branch_Location__c, PSA_Requested_Branch_Code__c FROM Order WHERE Part_Receipt_Created__c != true AND PSA_IsTransferred__c=true AND PSA_PoType__c=';   
        }
        else if(component.get("v.potype") == 'Co-Dealer'){
			query = 'SELECT Id, OrderNumber, (select Id, PSA_Allocated_Qty__c, Product2Id, Product2.PSA_SGST__c,Product2.PSA_CGST__c, Product2.PSA_IGST__c,Product2.PSA_CESS__c,Product2.PSA_Part_Number__c, Product2.PSA_Part_Description__c, OrderId, Product2.PSA_HSN_Code__c, Product2.QuantityUnitOfMeasure, Quantity, UnitPrice, Product2.PSA_Min_Inv_Level__c, Product2.PSA_Max_Inv_Level__c, Product2.PSA_Reorder_Level__c, Product2.PSA_Safety_Stock__c,PSA_Indent_Qty__c,PSA_Transfer_Qty__c, PSA_Indent_Value__c, PSA_Transfer_Value__c, PSA_Taxable_Value__c, PSA_Total_Tax__c, PSA_Total_Order_Value__c from OrderItems where OTC_Codealer__c=true), PSA_Request_Date__c, PSA_Transfer_Request_Number__c, PSA_Approver_Comments__c, PSA_Approval_Status__c, PSA_Approved_Date__c, PSA_Approved_By__c, PSA_Requested_By__c, PSA_Dealer_Remarks__c, PSA_Fulfilment_Branch_Location__c, PSA_Fulfilment_Branch_code__c, PSA_Total_Request_Value__c, PSA_Requested_Branch_Location__c, PSA_Requested_Branch_Code__c FROM Order WHERE Part_Receipt_Created__c != true AND co_dealer_otc__c=true AND PSA_PoType__c=';               
        }
        else{
            query = 'select id, OrderNumber, (select id,Name,PSA_Order__r.Total_Order_Amount_Parts__c, PSA_Order__r.Total_Order_Value__c, PSA_Order__r.Tax_Amounts__c, PSA_Local_Parts_Master__r.PSA_Part_Number__c,PSA_Local_Parts_Master__r.PSA_HSN_Code__c,PSA_Local_Parts_Master__r.PSA_Units__c,PSA_Rate_per_unit__c,PSA_GST__c,PSA_Total_Amount__c,PSA_Net_Amount__c,PSA_GST_Amount__c,PSA_Quantity__c,PSA_Dealer_Parts_Association__r.PSA_IGST__c,PSA_Dealer_Parts_Association__r.PSA_CGST__c,PSA_Dealer_Parts_Association__r.PSA_SGST__c,PSA_Dealer_Parts_Association__r.PSA_CESS__c,PSA_Local_Parts_Master__r.PSA_Part_Description__c,PSA_Shortage_Qty__c,PSA_Damaged_Qty__c,PSA_Received_Qty__c FROM Parts_Order_Item__r),Account.Id,Account.Dealer_Code__c,Account.Name,Account.BillingCity,Account.BillingState,CreatedDate,Part_Receipt_Created__c,PSA_Vendor__c,PSA_Vendor__r.Name FROM Order WHERE Part_Receipt_Created__c != true AND PSA_PoType__c=';
        }
        var status ='Approved';
        //var recordtypeid =$A.get("$Label.c.Local_PO_RecordType");
        var potype;
        if(component.get("v.potype") == 'Local'){
            potype = "Local PO";
        }
        else if(component.get("v.potype") == 'Co-Dealer'){
            potype = "Co-Dealer";
        }
        else{
            potype = "Stock";
        }
        var newString = '\''+ potype + '\'';
        var statusnew='\''+ status + '\'';
        var accid = '\''+ component.get("v.AccountId") + '\'';
        if(component.get("v.potype") == 'StockTransfer' || component.get("v.potype") == 'Co-Dealer')
        	query+= newString + ' AND '+'AccountId='+accid+ ' AND OrderNumber LIKE: searchKey order by createdDate DESC Limit 5';
        else
        	query+= newString + ' AND '+'Status__c='+statusnew+ ' AND OrderNumber LIKE: searchKey order by createdDate DESC Limit 5';
        
        component.set("v.localquery",query);
        //component.set("v.partType", "PO");
        component.set("v.partType", potype);        
    },
    
    cancelPOtransfer : function(component,event,helper){
        component.set("v.taxvalue", null); component.set("v.totalinvoicevalue", null);
        component.set("v.invvalueexclgst", null); component.set("v.podnumber", "");
        component.set("v.invnumber", ""); component.set("v.invdate", null);
        component.set("v.supplyplant", ""); component.set("v.suppliername", "");
        component.set("v.transportername", ""); component.set("v.ewaybill", "");
        component.set("v.docketno", ""); component.set("v.grndate", "");
        component.set("v.grnnumber", ""); component.set("v.receiptdate", ""); 
        component.set("v.ponumberErrmsg",'');
        
        if(component.get("v.potype") == 'StockTransfer' || component.get("v.potype") == 'Co-Dealer'){        	
            var childCmp = component.find("partPOnostock");	
        	childCmp.clearpill(); 
            var cmpTarget = component.find('submitbtnstock');
        	$A.util.addClass(cmpTarget, 'disablebtn');
        }else{            
            var childCmp = component.find("partPOno");
        	childCmp.clearpill();  
            var cmpTarget = component.find('submitbtn');
        	$A.util.addClass(cmpTarget, 'disablebtn');
        }        
        
        component.set("v.invdateErrMsg",'');
        component.set("v.invnoErrmsg",'');
        component.set("v.podnumberErrMsg",'');
        component.set("v.receiptdateErrmsg",'');
    },
    
    canceltransfer : function(component,event,helper){        
        var backtolistviewscreen = component.getEvent("backtolistview");
        backtolistviewscreen.setParams({"ListPage" : false});
        backtolistviewscreen.fire(); 
    },
    
    disablebtn : function(component,event,helper){
        var val = event.getParam('ListPage');
		var cmpTarget = component.find('submitbtn');
        $A.util.removeClass(cmpTarget, 'disablebtn');        
    },
    
    hiderequiredfield : function(component,event,helper){        
        var id = event.getSource().getLocalId();
        var inputvalue;
        if(id != undefined){
        	inputvalue = component.find(id).get("v.value");
        }
        else{
            component.set("v.ponumberErrmsg",'');
        }
        if(id == 'invoicenumber' && (inputvalue != null || inputvalue != undefined)){
            component.set("v.invnoErrmsg",'');  
            $A.util.removeClass(inputvalue,"disp-block");
            $A.util.addClass(inputvalue,"disp-none");
        }
        else if(id == 'invoicedate' && (inputvalue != null || inputvalue != undefined)){
            component.set("v.invdateErrMsg",'');
            $A.util.removeClass(inputvalue,"disp-block");
            $A.util.addClass(inputvalue,"disp-none"); 
            var invdate = component.get("v.invdate");
            var message = 'Invoice date should not be in future!';
            var date_val = component.find("invoicedate").get("v.value");
            var date_formatter = new Date(date_val);
            var dateval = $A.localizationService.formatDate(date_formatter, "dd/MM/yyyy")
            var isvalid=true;
            if(dateval == "Invalid Date"){
                isvalid = false;
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "message": "Please enter the date in dd/mm/yyyy format!"
                });
                toastEvent.fire();
            }
            else{
            	component.find("invoicedate").set("v.value", dateval);
            }
            
            if(isvalid)
            	helper.futuredaterestriction(component,event,helper,invdate,message);
        }
        else if(id == 'podnumberPO' && (inputvalue != null || inputvalue != undefined)){
            component.set("v.podnumberErrMsg",'');
            $A.util.removeClass(inputvalue,"disp-block");
            $A.util.addClass(inputvalue,"disp-none");
        
        }
        else if(id == 'receiptdate' && (inputvalue != null || inputvalue != undefined)){
            component.set("v.receiptdateErrmsg",'');
            $A.util.removeClass(inputvalue,"disp-block");
            $A.util.addClass(inputvalue,"disp-none"); 
            var recptdate = component.get("v.receiptdate");
            var message = 'Receipt date should not be in future!';
            var date_val = component.find("receiptdate").get("v.value");
            var date_formatter = new Date(date_val);
            var dateval = $A.localizationService.formatDate(date_formatter, "dd/MM/yyyy")
            var isvalid = true;
            if(dateval == "Invalid Date"){
                isvalid = false;
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "type": "error",
                    "message": "Please enter the date in dd/mm/yyyy format!"
                });
                toastEvent.fire();
            }
            else{
            	component.find("receiptdate").set("v.value", dateval);
            }
            
            if(isvalid)
            	helper.futuredaterestriction(component,event,helper,recptdate,message);            
        }
        else{}
       
    }
    
})