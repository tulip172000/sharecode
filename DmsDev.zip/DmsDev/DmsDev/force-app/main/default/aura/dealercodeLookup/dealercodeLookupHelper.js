({
	searchHelper : function(component,event,getInputkeyWord) {
        
         var delid=component.get("v.dealerid");
      //  alert(delid);
	  // call the apex class method 
     var action = component.get("c.fetchLookUpValues");
        var objectAPIName = component.get("v.objectAPIName");
        var query = '';
        if(component.get("v.customQuery"))
            query = component.get("v.query");
      // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'ObjectName' : component.get("v.objectAPIName"),
            'query' : query
                      });
      // set a callBack    
        action.setCallback(this, function(response) {
          $A.util.removeClass(component.find("mySpinner"), "slds-show");
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
               
             
                // set searchResult list with return value from server.
                component.set("v.listOfSearchRecords", storeResponse);
               
            }
 
        });
      // enqueue the Action  
        $A.enqueueAction(action);
    
	},
})