({
	 validateVendorForm : function(component, event, helper){
        var isValid = true;
        debugger;
        var insuMster = component.get("v.insuInfo"); 
        var gstNo = insuMster.PSA_Insurance_Company_GST_Number__c;
        var insuranceName=insuMster.PSA_Insurance_Company_Name__c;
        var compMail=insuMster.PSA_Default_Email__c;
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/; 
        
        component.set("v.insuranceNameErrorMsg",'');
        $A.util.removeClass(insuranceName,"disp-block");
        $A.util.addClass(insuranceName,"disp-none"); 
        component.set("v.gstNoErrorMsg",'');
        $A.util.removeClass(gstNo,"disp-block");
        $A.util.addClass(gstNo,"disp-none");
        component.set("v.compemailError",'');
        $A.util.removeClass(compMail,"disp-block");
        $A.util.addClass(compMail,"disp-none");
         if(gstNo == 'undefined'|| gstNo == '' || gstNo == null){
            isValid = false;
            component.set("v.gstNoErrorMsg",'This is a required field');
            $A.util.removeClass(gstNo,"disp-none");
            $A.util.addClass(gstNo,"disp-block");
        }
           
         if(insuranceName == 'undefined'|| insuranceName == '' || insuranceName == null){
            isValid = false;
            component.set("v.insuranceNameErrorMsg",'This is a required field');
            $A.util.removeClass(insuranceName,"disp-none");
            $A.util.addClass(insuranceName,"disp-block");
        }
         if(compMail != 'undefined' && compMail != '' && compMail != null){
          if(!compMail.match(regExpEmailformat)){
             component.set("v.compemailError",'Please Enter a Valid Email Address');
             $A.util.removeClass(compMail,"disp-none");
             $A.util.addClass(compMail,"disp-block");
             isValid = false;
         } 
         }
          
       return  isValid;
        
        
    },
    showErrorToast : function(component,event,msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "message": msg,
            "type": "ERROR"
        });
        toastEvent.fire(); 
    },
    
    showSuccessToast : function(component,event, msg){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": msg,
            "type": "success"
        });
        toastEvent.fire();  
    },
    GstPicklist : function(component, event){      
       var action = component.get("c.fetchGstClariPicklist");
        action.setCallback(this, function(response) {
        component.set("v.gstClarfication", response.getReturnValue());
    		});
       
        $A.enqueueAction(action);
       
  },  
  fectchInsuranceData : function(component, event){  
      
      var recId = component.get("v.RecordId");
      var action = component.get("c.fectchInsuranceData");
      action.setParams({
          "recId":recId
                });
        action.setCallback(this, function(response) {
             var state=response.getState();
                console.log('save status  >>>>'+state);
                if(state  == "SUCCESS"){
                    var result=response.getReturnValue();
                   component.set("v.gstClarValue",result.PSA_GST_Classification__c);
                   component.set("v.insuInfo", result);
                }
    		});
       
        $A.enqueueAction(action);
       
  },  

})