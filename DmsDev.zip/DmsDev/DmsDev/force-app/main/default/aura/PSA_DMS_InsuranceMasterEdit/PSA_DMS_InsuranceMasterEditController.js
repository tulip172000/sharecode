({
	doInit: function(component, event, helper) 
    {
        
        helper.GstPicklist(component, event, helper) ;  
        helper.fectchInsuranceData(component, event, helper) ;
        
    },
    
    handleSaveVendor: function(component, event, helper) {
        
        if(helper.validateVendorForm(component)) {
             
             var gstClarValue = component.get("v.gstClarValue");
             component.set("v.insuInfo.PSA_GST_Classification__c",gstClarValue);
             var insuMster = component.get("v.insuInfo");
           // alert(insuMster.PSA_GST_Classification__c);
             var action = component.get("c.UpdatesaveInsurancemaster"); 
            action.setParams({
                "insuMster":insuMster
                });
            action.setCallback(this, function(response) {
                var state=response.getState();
                console.log('save status  >>>>'+state);
                if(state  == "SUCCESS"){
                    var check=response.getReturnValue()
                    if(check)
                    {
                     helper.showErrorToast(component,event,'Insurance Name and GST Number Duplicate Found');   
                    }else
                    {
                    helper.showSuccessToast(component,event,'Insurance Master Saved Successfully');                   
                    var eventListPage = component.getEvent("displayListPageParts");
                    eventListPage.setParams({"listPage" : true });
                    eventListPage.fire();
                    }
                }
                if(state  == "ERROR"){
                    var toast = $A.get("e.force:showToast");
                    if(toast){
                        toast.setParams({
                            "title": "Error",
                            "message": result.getError()[0].message
                        });
                    }
                    toast.fire();
                } 
                
            });
            $A.enqueueAction(action); 
      
        }
    },
    oncancel:function(component, event, helper) 
    {
        var eventListPage = component.getEvent("displayListPageParts");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
    editRecords:function(component, event, helper) 
    {
        component.set("v.disableButton",false);
        component.set("v.disableEdit",true);
        component.set("v.disableSave",false);
    },
    comphonevalidate  : function(component, event, helper) {
        var mobinp = component.get("v.insuInfo.PSA_Phone_number__c");
      
        if(isNaN(mobinp))
            component.set("v.insuInfo.PSA_Phone_number__c", mobinp.substring(0, mobinp.length - 1));
    },
   validateFax  : function(component, event, helper) {
        var mobinp = component.get("v.insuInfo.PSA_Default_Fax__c");
      
        if(isNaN(mobinp))
            component.set("v.insuInfo.PSA_Default_Fax__c", mobinp.substring(0, mobinp.length - 1));

    },
   validatePostal  : function(component, event, helper) {
        var mobinp = component.get("v.insuInfo.PSA_Postal_Code__c");
      
        if(isNaN(mobinp))
            component.set("v.insuInfo.PSA_Postal_Code__c", mobinp.substring(0, mobinp.length - 1));

    },
})