({
    getRoDetails : function(component,event,helper) {
        var action = component.get("c.fetchRepairOrderDetails");
        
        action.setParams({
            "recordId" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
      
            var PSA_Fuel_Level = '';
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                var flevel = value.PSA_Fuel_Level__c;
                flevel = (flevel/8)*100+'%';
                PSA_Fuel_Level = flevel;
                if(flevel == 0)
                    PSA_Fuel_Level = 'Reserve';
                //     component.set("v.PSA_Fuel_Level", PSA_Fuel_Level);
                var roId=value.Id;
                //For Data Formating
                   if(value.Asset.Insurance_Company__c!='undefined' && value.Asset.Insurance_Company__c !='' && value.Asset.Insurance_Company__c !=null)
                   {  
               		 component.set("v.insurancecompany",value.Asset.Insurance_Company__r.Name);
                }
                       var addressWrap='';
                if(value.Asset.Account.PersonMailingStreet !='undefined' && value.Asset.Account.PersonMailingStreet !='' && value.Asset.Account.PersonMailingStreet !=null)
                {
                    addressWrap= value.Asset.Account.PersonMailingStreet+','   
                }
                if(value.Asset.Account.PersonMailingCity !='undefined' && value.Asset.Account.PersonMailingCity !='' && value.Asset.Account.PersonMailingCity !=null)
                {
                    addressWrap=addressWrap+value.Asset.Account.PersonMailingCity+' '   
                }
                if(value.Asset.Account.PersonMailingPostalCode !='undefined' && value.Asset.Account.PersonMailingPostalCode !='' && value.Asset.Account.PersonMailingPostalCode !=null)
                {
                    addressWrap= addressWrap+value.Asset.Account.PersonMailingPostalCode   
                }
               // var addressWrap=value.Asset.Account.PersonMailingStreet+','
               // +value.Asset.Account.PersonMailingCity+value.Asset.Account.PersonMailingPostalCode;
                component.set("v.addressWrap",addressWrap);
               
                if(value.Asset.Account.Phone !='undefined' && value.Asset.Account.Phone !='' && value.Asset.Account.Phone !=null){
                var strph = value.Asset.Account.Phone;
                var sph=strph.replace(/[^\w\s]/gi, '');
                value.Asset.Account.Phone= sph.replace(/\s+/g,'');
             
                }
                
               
               if(value.Asset.Warranty_StartDate__c !='' && value.Asset.Warranty_StartDate__c !=null && value.Asset.Warranty_StartDate__c !='undefined')
                {
                      var wsd=$A.localizationService.formatDate(value.Asset.Warranty_StartDate__c, "dd/MM/yyyy");
                      component.set("v.wsd",wsd);
                }
                if(value.Asset.Warranty_EndDate__c !='' && value.Asset.Warranty_EndDate__c !=null && value.Asset.Warranty_EndDate__c !='undefined')
                {
                      var wed=$A.localizationService.formatDate(value.Asset.Warranty_EndDate__c, "dd/MM/yyyy");
                      component.set("v.wed",wed);
                }
                if(value.Asset.Extended_Warranty_StartDate__c !='' && value.Asset.Extended_Warranty_StartDate__c !=null && value.Asset.Extended_Warranty_StartDate__c !='undefined')
                {
                      var ewsd=$A.localizationService.formatDate(value.Asset.Extended_Warranty_StartDate__c, "dd/MM/yyyy");
                      component.set("v.ewsd",ewsd);
                }
                if(value.Asset.Extended_Warranty_EndDate__c !='' && value.Asset.Extended_Warranty_EndDate__c !=null && value.Asset.Extended_Warranty_EndDate__c !='undefined')
                {
                      var ewed=$A.localizationService.formatDate(value.Asset.Extended_Warranty_EndDate__c, "dd/MM/yyyy");
                      component.set("v.ewed",ewed);
                }
                if(value.Asset.PSA_Service_Contract_StartDate__c !='' && value.Asset.PSA_Service_Contract_StartDate__c !=null && value.Asset.PSA_Service_Contract_StartDate__c !='undefined')
                {
                      var scsd=$A.localizationService.formatDate(value.Asset.PSA_Service_Contract_StartDate__c, "dd/MM/yyyy");
                      component.set("v.scsd",scsd);
                }
                if(value.Asset.PSA_Service_Contract_EndDate__c !='' && value.Asset.PSA_Service_Contract_EndDate__c !=null && value.Asset.PSA_Service_Contract_EndDate__c !='undefined')
                {
                      var sced=$A.localizationService.formatDate(value.Asset.PSA_Service_Contract_EndDate__c, "dd/MM/yyyy");
                      component.set("v.sced",sced);
                }
                                /*var estim=value.PSA_Est_Check_Out_Date_Time__c;
                var app=value.PSA_Appointment_Date_Time__c;
                var check=value.PSA_Check_in_Date_and_Time__c;
                var estimdev=value.Estimated_Delivery__c;*/
                if(value.PSA_Est_Check_Out_Date_Time__c !='' && value.PSA_Est_Check_Out_Date_Time__c !=null && value.PSA_Est_Check_Out_Date_Time__c !='undefined')
                {
                var estimc= $A.localizationService.formatDate(value.PSA_Est_Check_Out_Date_Time__c, "dd/MM/yyyy h:mm a");
                component.set("v.estimated",estimc);
                } 
                if(value.PSA_Appointment_Date_Time__c !='' && value.PSA_Appointment_Date_Time__c !=null && value.PSA_Appointment_Date_Time__c !='undefined')
                {
                var appc= $A.localizationService.formatDate(value.PSA_Appointment_Date_Time__c, "dd/MM/yyyy h:mm a");
                component.set("v.appc",appc);
                }
                if(value.Vehicle_Arrival_Time__c !='' && value.Vehicle_Arrival_Time__c !=null && value.Vehicle_Arrival_Time__c !='undefined')
                {
                var checkc= $A.localizationService.formatDate(value.Vehicle_Arrival_Time__c, "dd/MM/yyyy h:mm a");
                component.set("v.checkc",checkc);
                }
                if(value.Estimated_Delivery__c !='' && value.Estimated_Delivery__c !=null && value.Estimated_Delivery__c != 'undefined')
                {
                var estimdevc= $A.localizationService.formatDate(value.Estimated_Delivery__c, "dd/MM/yyyy h:mm a");
                component.set("v.estimdevc",estimdevc); 
                }
                component.set("v.roId", roId);
                component.set("v.repairOrder", value);
                component.set("v.spinner", false);
                component.set("v.subStatus", value.PSA_Sub_status__c);
                
                if(value.Status=='Closed')
                {
                component.set("v.checkingRoStatus", true);
                component.set("v.disSerInfoFields", true); 
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    validatePartForm : function(component, event, helper){
    
        var isValid = true;
        var cust = component.find("customerName").get("v.value");
        var visit = component.get("v.repairOrder.PSA_Visit_Type__c");
         var checkCustdem= component.get("v.repairOrder.PSA_Customer_Confirmation_on_Add_Job__c");
        var serviceCat= component.get("v.repairOrder.PSA_Service_Category__c");
        var serviceType= component.get("v.repairOrder.PSA_Service_Type__c");
        var vehicleType= component.get("v.repairOrder.PSA_Vehicle_Brought_By__c");
        var driverType= component.get("v.repairOrder.PSA_Driver_Contact_No__c");
     
        var dat = component.find("datetime").get("v.value");
        component.set("v.CustomerErrorMsg",'');
        $A.util.removeClass(cust,"disp-block");
        $A.util.addClass(cust,"disp-none");
        component.set("v.driverTypemsg",'');
        $A.util.removeClass(cust,"disp-block");
        $A.util.addClass(cust,"disp-none");
        
        component.set("v.serviceTypemsg",'');
        $A.util.removeClass(serviceType,"disp-block");
        $A.util.addClass(serviceType,"disp-none");
        component.set("v.visitmsg",'');
        $A.util.removeClass(visit,"disp-block");
        $A.util.addClass(visit,"disp-none");
        component.set("v.serviceCatmsg",'');
        $A.util.removeClass(serviceCat,"disp-block");
        $A.util.addClass(serviceCat,"disp-none");
        component.set("v.vehicleByTypemsg",'');
        $A.util.removeClass(vehicleType,"disp-block");
        $A.util.addClass(vehicleType,"disp-none");
        component.set("v.dateErrorMsg",'');
        $A.util.removeClass(dat,"disp-block");
        $A.util.addClass(dat,"disp-none");
        
        if(checkCustdem)
        {

        if(cust == 'undefined'|| cust == '' || cust == null){
            component.set("v.CustomerErrorMsg",'This is a Required Field');
            $A.util.removeClass(cust,"disp-none");
            $A.util.addClass(cust,"disp-block");
            isValid = false;
        }
        if(dat == 'undefined'|| dat == '' || dat == null){
            component.set("v.dateErrorMsg",'This is a Required Field');
            $A.util.removeClass(dat,"disp-none");
            $A.util.addClass(dat,"disp-block");
            isValid = false;
        }
        }
        if(serviceType == 'undefined'|| serviceType == '' || serviceType == null){
            component.set("v.serviceTypemsg",'This is a Required Field');
            $A.util.removeClass(serviceType,"disp-none");
            $A.util.addClass(serviceType,"disp-block");
            isValid = false;
        }
        if(vehicleType=='Driver')
        {   
        if(driverType == 'undefined'|| driverType == '' || driverType == null){
            component.set("v.driverTypemsg",'This is a Required Field');
            $A.util.removeClass(driverType,"disp-none");
            $A.util.addClass(driverType,"disp-block");
            isValid = false;
        }
    }
        
        if(vehicleType == 'undefined'|| vehicleType == '' || vehicleType == null){
            component.set("v.vehicleByTypemsg",'This is a Required Field');
            $A.util.removeClass(vehicleType,"disp-none");
            $A.util.addClass(vehicleType,"disp-block");
            isValid = false;
        }
        if(serviceCat == 'undefined'|| serviceCat == '' || serviceCat == null){
            component.set("v.serviceCatmsg",'This is a Required Field');
            $A.util.removeClass(serviceCat,"disp-none");
            $A.util.addClass(serviceCat,"disp-block");
            isValid = false;
        }
        if(visit == 'undefined'|| visit == '' || visit == null){
           
            component.set("v.visitmsg",'This is a Required Field');
            $A.util.removeClass(visit,"disp-none");
            $A.util.addClass(visit,"disp-block");
            isValid = false;
        }
        var check=false;
        if(!isValid)
        {this.errorToast(component, event, 'Please Enter Inputs for All Required Fields');          
      }
         else{
           var joblist=component.get("v.jobActivities"); 
             var x;
             for(x in joblist){
                 if(joblist[x].PSA_Primary_Job__c==false && joblist[x].PSA_Secondary_Job__c==false&& joblist[x].PSA_Additional_Job__c==false){
                  isValid=false; 
                     check=true;
                 }
             }
         }
        if(check){
            this.errorToast(component, event, 'Please Select Primary or Secondary job in each Row');          
     
        }
        
        
        return isValid;
    },
    getJobCardActivities : function(component,event,helper) {
        
        var action = component.get("c.fetchJObCardActivities");
        action.setParams({
            "recordId" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.jobActivities", value);
            }
        });
        $A.enqueueAction(action);
    },
    
    
    
    getJobParts : function(component,event) {
        var repairorderid=component.get("v.repairOrderId");
        var action = component.get("c.fetchJobParts");
        action.setParams({
            "recordId" : repairorderid
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.jobParts", value);
               // alert(value);
                var lstjobparts = component.get("v.jobParts");
               for(var i=0; i<lstjobparts.length; i++){
                    if(lstjobparts[i].issuetype == 'Manufacturer'){
                        component.set("v.subStatus", 'Claim Pending');
                        break;
                    }                    
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    getJobcardStatusPicklist : function(component,event,helper) {
        var action = component.get("c.getPickListValuesJobCardStatus");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.jobCardstatusList", value);
            }
        });
        $A.enqueueAction(action);
    },    
     jobCardstatusSBFolderList : function(component,event,helper) {
        var action = component.get("c.getJobCardStatusSBFolder");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.jobCardstatusSBFolderList", value);
            }
        });
        $A.enqueueAction(action);
    },
    getworkOrderstatusList : function(component,event,helper) {
        var action = component.get("c.getPickListValuesworkOrderstatus");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.workOrderstatusList", value);
            }
        });
        $A.enqueueAction(action);
    },
    
    getworkOrderSubstatusList : function(component,event,helper) {
        var action = component.get("c.getPickListValuesworkOrderSubstatus");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.workOrdersubstatusList", value);
            }
        });
        $A.enqueueAction(action);
    },
    getBreakDownList : function(component,event,helper) {
        var action = component.get("c.getPickListValuesBreakDown");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.breakDownList", value);
            }
        });
        $A.enqueueAction(action);
    },
    getsourceList : function(component,event,helper) {
        var action = component.get("c.getPickListValuessource");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.sourcestatusList", value);
            }
        });
        $A.enqueueAction(action);
    },
    
    getserviceTypeList : function(component,event,helper) {
        var action = component.get("c.getPickListValuesserviceType");
        action.setParams({
            "recordId" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state == "SUCCESS") {
                
                var value = response.getReturnValue();
                
                component.set("v.serviceTypestatusList", value);
            }
        });
        $A.enqueueAction(action);
    },
    
    getserviceCategoryList : function(component,event,helper) {
        
        var action = component.get("c.getPickListValuesserviceCategory");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.serviceCategorystatusList", value);
            }
        });
        $A.enqueueAction(action);
    },
    getVisitList : function(component,event,helper) {
        var action = component.get("c.getPickListValuesVisitType");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.workOrderVisitList", value);
            }
        });
        $A.enqueueAction(action);
    },
    getModePaymentList : function(component,event,helper) {
        var action = component.get("c.getPickListValuesModePaymentType");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.PickListValuesModePaymentType", value);
            }
        });
        $A.enqueueAction(action);
    },
    getModeContactList : function(component,event,helper) {
        var action = component.get("c.getPickListValuesModeContactType");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.PickListValuesModeContact", value);
            }
        });
        $A.enqueueAction(action);
    },
    
    getRecentVisits : function(component,event,helper) {
        var action = component.get("c.fetchRecentVisits");
        action.setParams({
            "recordId" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                
             /*  for(var b =0;b<value.length;b++)
                {
                    if(value.FeedBacks__r!=null && value.FeedBacks__r !='undefined')
                {
                if(value[b].FeedBacks__r[0].PSA_Last_Visit_Recommendation__c==null ||value[b].FeedBacks__r[0].PSA_Last_Visit_Recommendation__c=='undefined')
                {
                    value[b].FeedBacks__r[0].PSA_Last_Visit_Recommendation__c='No Comments';
                }
                }*/
                 //else
                //value.FeedBacks__r[0].PSA_Last_Visit_Recommendation__c='No Comments';
            }  
                
                component.set("v.recentROs", value);
            
        });
        $A.enqueueAction(action);
    },
    getInsuranceMaster : function(component,event,helper)
    {
        var action = component.get("c.getInsuranceMaster");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.insuranceCompList", value);
            }
        });
        $A.enqueueAction(action);
  
    },
    successToast : function(component, event, helper, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "message": msg
        });
        toastEvent.fire();
    },
    
    errorToast : function(component, event, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
    },
    createObjectData: function(component, event) {
        var RowItemList = component.get("v.LineItemlist");
        RowItemList.push({
            'sobjectType ': 'WorkOrderLineItem',
            'Product2Id':'',
            'Actual_Quantity__c':'',
            'id':'',
            'PSA_Parts_Amounts_Exl_Tax__c':0,
            'UnitPrice' : ''
        });
        component.set("v.LineItemlist", RowItemList);
    },
    createjobData: function(component, event) {
        var joblist = component.get("v.Joblabourlist");
        joblist.push({
            'sobjectType ': 'PSA_Job_Labor__c',
            'PSA_Labor_Description__c' :'',
            'PSA_Hourly_Rate__c' : '',
            'PSA_Repair_time__c' :'',
            'Id':null,
            'Name' :'',
            'PSA_Time__c' : '',
            'PSA_SGST__c' :'',
            'PSA_IGST__c' :'',
            'PSA_CGST__c' :'',
            'PSA_CESS__c' :'',
            'PSA_Price_Exl_Tax__c' :'',
            'PSA_price_incl_tax__c' :'',
            'PSA_Total_Price__c' :'' 
        });
        component.set("v.Joblabourlist", joblist);
    },
    
    deleterow:function(component, event,buttonvalue) {
        
        var lineitemlist=component.get('v.LineItemlist');
        var joblabourlist=component.get('v.Joblabourlist');
        
         for(var i=joblabourlist.length; i>0; i--){
             joblabourlist.splice(0, 1);
        }
        for(var i=lineitemlist.length; i>0; i--){
            lineitemlist.splice(0, 1);
        }
        var action = component.get("c.setRepStatus");
        action.setParams({
            "recordId" : component.get("v.repairOrderId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                
            }
        });
        $A.enqueueAction(action);
  
    
        component.set("v.Joblabourlist", joblabourlist);
         component.set("v.LineItemlist", lineitemlist);
        component.find('oemshare').set('v.value',0);
        component.find('dealershare').set('v.value',0);
        component.find('customershare').set('v.value',0);
        component.find('insuranceshare').set('v.value',0);
         component.set("v.totalreturnValue", 0);
         component.set("v.sharevalue", 0);
        component.find('jobtype').set('v.value','--None--');
         component.find('issuetype').set('v.value','--None--');
         component.find('Description').set('v.value','');
         component.set("v.issuetypeerror",'');
         component.set("v.rerarkserrmsg",'');
         component.set("v.descriptionerrormsg",'');
         document.getElementById("myModal").style.display = "none";
        
        if(buttonvalue=='addanother'){
         this.createObjectData(component, event);
          this.createjobData(component, event);
          document.getElementById("myModal").style.display = "block";
            component.set("v.disablesave",false);
            
        }
       
        
    },MAX_FILE_SIZE: 4500000,
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    uploadHelper: function(component, event,parentid) {
       var fileInput = component.find("fileId").get("v.files");
        
        var file = fileInput[0];
       
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
        var objFileReader = new FileReader();
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
            self.uploadProcess(component, file, fileContents,parentid);
        });
        objFileReader.readAsDataURL(file);
    },
    checkfilesize: function(component, event) {
        var fileInput = component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }else{
            component.set('v.fileName',file.name);
        }
        var objFileReader = new FileReader();
        
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
        });
        
        objFileReader.readAsDataURL(file);
    },
    uploadProcess: function(component, file, fileContents,parentid) {
        var startPosition = 0;
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '',parentid);
    },
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId,parentid) {
       
        var getchunk = fileContents.substring(startPosition, endPosition);
        var checkFilename=component.get("v.fileName");
       
        if(checkFilename !=null)
        {
             var action = component.get("c.saveChunk");
        action.setParams({
            parentId: parentid,
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        action.setCallback(this, function(response) {
            attachId = response.getReturnValue();
            var state = response.getState();
           
            if (state === "SUCCESS") {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "Success",
            "message": "The Uploaded File successfully Saved"
        });
        toastEvent.fire();
       component.set("v.fileName", null);
                           
            }
            
        });
        $A.enqueueAction(action);
        }
    },
    
    handleWOmainstatus : function(component, event, helper){
        var jobactivities = component.get("v.jobActivities");
        for(var i=0; i<jobactivities.length; i++){
            if(jobactivities[i].PSA_Status__c == 'Open' || jobactivities[i].PSA_Status__c == 'In Progress' || jobactivities[i].PSA_Status__c == 'On Hold'){
                component.set("v.repairOrder.Status", "In Progress");
            }
            else
            {
                var completedcount=0;
                var cancelledcount=0;
                for(var j=0; j<jobactivities.length; j++){
                    if(jobactivities[j].PSA_Status__c == "Completed"){
                        completedcount++;
                    }
                    if(jobactivities[j].PSA_Status__c == "Cancelled"){
                        cancelledcount++;
                    }
                }
                if(jobactivities.length == completedcount || jobactivities.length == cancelledcount){
                    component.set("v.repairOrder.Status", "Completed");
                }  
                var cancelledcompletedcount = completedcount + cancelledcount;
                if(jobactivities.length == cancelledcompletedcount){
                    component.set("v.repairOrder.Status", "Completed");
                }
            }
            
            
        } 
    },
    validation : function(component, event){
        var Isvalid=true;
        var jobtype = component.find('jobtype').get('v.value');
        var Issuetype = component.find('issuetype').get('v.value');
        var share =component.get('v.sharevalue');
      
        var jobdesc=component.find('Description').get('v.value');
        component.set("v.rerarkserrmsg",'');
        component.set("v.descriptionerrormsg",'');
         component.set("v.issuetypeerror",'');
        $A.util.removeClass(jobtype,"disp-block");
        $A.util.addClass(jobtype,"disp-none");
         if(jobtype=='' || jobtype=='undefined'  || jobtype==null || jobtype=='--None--' ){
            Isvalid=false;
            component.set("v.rerarkserrmsg",'This is a Required Field');
            $A.util.removeClass(jobtype,"disp-none");
            $A.util.addClass(jobtype,"disp-block");
        }
        if(jobdesc=='' || jobdesc=='undefined'  || jobdesc==null){
            Isvalid=false;
            component.set("v.descriptionerrormsg",'This is a Required Field');
        }
         if(Issuetype=='' || Issuetype=='undefined'  || Issuetype==null || Issuetype=='--None--'){
               Isvalid=false;
            component.set("v.issuetypeerror",'This is a Required Field');
         }
        if(share<100){
            
            Isvalid=false;
            this.errorToast(component, event, 'The combination of OEM, Dealer, Customer & Insurance shares must and should 100 percent');          
        }
        return Isvalid;
    },
    addlineitems: function(component, event,buttonvalue) {
        component.set("v.disablesave",true);
        var repairorderid=component.get("v.repairOrderId");
        var joblabour=component.get('v.Joblabourlist');
       
         var lineitemlist=component.get('v.LineItemlist');
        component.set('v.partsdisabled',true);
        var jobtype = component.find('jobtype').get('v.value');
        var oemshareperc = component.find('oemshare').get('v.value');
        var dealershareperc = component.find('dealershare').get('v.value');
        var customershareperc = component.find('customershare').get('v.value');
        var insuranceshareperc = component.find('insuranceshare').get('v.value');
        if(insuranceshareperc=='undefined' || insuranceshareperc==null || insuranceshareperc==''){
             insuranceshareperc=0;
         }

        if(customershareperc=='undefined' || customershareperc==null || customershareperc==''){
            
             customershareperc=0;
            
            
         }
         if( dealershareperc=='undefined' || dealershareperc==null || dealershareperc==''){
             dealershareperc=0;
             
         }
         if(oemshareperc=='undefined' || oemshareperc==null || oemshareperc==''){
             oemshareperc=0;
             
         } 
        var jobdesc=component.find('Description').get('v.value');
         var jobcode=component.find('jobcode').get('v.value');
         var Issuetype = component.find('issuetype').get('v.value');
        var action = component.get("c.AddworkorderlineItems");
        action.setParams({
            "recordId" : repairorderid,
            "lineitemlist" : lineitemlist,
            "joblaourlist" : joblabour,
            "jobdescription" : jobdesc,
             "jobcode" : jobcode,
            "jobtype" : jobtype,
            "oemshare" :oemshareperc,
            "dealershareperc" :dealershareperc,
            "customershareperc" :customershareperc,
            "insuranceshareperc" :insuranceshareperc,
            "jobissuetype" :Issuetype
            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                
                this.getJobCardActivities(component,event);
                this.getJobParts(component,event);
                component.set("v.totalreturnValue", 0);
                component.set("v.sharevalue", 0);
                this.deleterow(component,event,buttonvalue);
                 component.set("v.repairOrder.Status",'In Progress');
                
            }
        });
        $A.enqueueAction(action);  
    },
    callVehicleBoughtByPicklist : function(component,event,helper) {
        var action = component.get("c.getVehicleBoughtByPicklist");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.vehicleBoughtList", value);
            }
        });
        $A.enqueueAction(action);
    },
    callDealerCategoryPrice : function(component,event,helper) {
        var action = component.get("c.getDealerCategoryPrice");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var value = response.getReturnValue();
                component.set("v.dealerCategory", value);
                }
        });
        $A.enqueueAction(action);
    },
    
})