({
    helperMethodPagination : function(component, event, pageNumber){
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.receipts").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
        if(pageNumber<=7){
            for(var i=1; i<= totalpage; i++){
                
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                paginationPageNumb.push(i);
            }
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
                paginationPageNumb.push(i);
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
    
    getinvoicelist : function(component, event) {      
        
        var action = component.get('c.getfeedback');
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set("v.feedcount", records.length); 
                component.set("v.invoicescount", records.length);                
                var pageSize = component.get("v.pageSize");
                component.set("v.receipts", records);
                component.set("v.totalSize", component.get("v.receipts").length);
                component.set("v.start",0);
                component.set("v.end",pageSize-1);
                var paginationList = [];
                if(response.getReturnValue().length < pageSize){
                    paginationList=response.getReturnValue();
                }
                else{
                    for(var i=0; i< pageSize; i++){
                        paginationList.push(response.getReturnValue()[i]); 
                    } 
                }
                
                component.set('v.paginationList', paginationList);
                this.helperMethodPagination(component, event, '1');
                var icount = component.get("v.invoicescount");
                var compEvent = component.getEvent("PartreceiptsCount");        
                compEvent.setParams({"Id" : icount });        
                compEvent.fire();
            }
        });
        $A.enqueueAction(action);
        
    },setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.partstable(component, event);
    },
    showErrorToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "message": Message,
            "type": "Error"
        });
        toastEvent.fire();  
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    opendetailrecord : function(component,event,records){
        var x;
        var astar;
        var cstar;
        var estar;
        var tstar;
        var wstar;
        
        for(x in records){
            if(records[x].Get_Rating__c=='Appointment'){
                astar=records[x].Rating__c;  
            }
            if(records[x].Get_Rating__c=='service estimation'){
                cstar=records[x].Rating__c;  
        
            } 
            if(records[x].Get_Rating__c=='satisfaction'){
                estar=records[x].Rating__c;   
            } 
            if(records[x].Get_Rating__c=='Delivery'){
                tstar=records[x].Rating__c;  
            } 
            if(records[x].Get_Rating__c=='Washing'){
                wstar=records[x].Rating__c;
                
            } 
             component.set("v.feed",records[x].PSA_FeedBack__r.PSA_Last_Visit_Recommendation__c);
        }
        if(cstar==10){
            component.set('v.cstar10',true);
        }
         if(cstar==9){
            component.set('v.cstar9',true);
        }
         if(cstar==8){
            component.set('v.cstar8',true);
        }
         if(cstar==7){
            component.set('v.cstar7',true);
        }
         if(cstar==6){
            component.set('v.cstar6',true);
        }
        if(astar==5){
            component.set('v.astar5',true);
        }
         if(cstar==4){
            component.set('v.cstar4',true);
        }
         if(cstar==3){
            component.set('v.cstar3',true);
        }
         if(cstar==2){
            component.set('v.cstar2',true);
        }
         if(cstar==1){
            component.set('v.cstar1',true);
        }
        if(astar==10){
            component.set('v.astar10',true);
        }
         if(astar==9){
            component.set('v.astar9',true);
        }
         if(astar==8){
            component.set('v.astar8',true);
        }
         if(astar==7){
            component.set('v.astar7',true);
        }
         if(astar==6){
            component.set('v.astar6',true);
        }
        if(astar==5){
            component.set('v.astar5',true);
        }
         if(astar==4){
            component.set('v.astar4',true);
        }
         if(astar==3){
            component.set('v.astar3',true);
        }
         if(astar==2){
            component.set('v.astar2',true);
        }
         if(astar==1){
            component.set('v.astar1',true);
        }
        if(estar==10){
            component.set('v.estar10',true);
        }
         if(estar==9){
            component.set('v.estar9',true);
        }
         if(estar==8){
            component.set('v.estar8',true);
        }
         if(estar==7){
            component.set('v.estar7',true);
        }
         if(estar==6){
            component.set('v.estar6',true);
        }
        if(estar==5){
            component.set('v.estar5',true);
        }
         if(estar==4){
            component.set('v.estar4',true);
        }
         if(estar==3){
            component.set('v.estar3',true);
        }
         if(estar==2){
            component.set('v.estar2',true);
        }
         if(estar==1){
            component.set('v.estar1',true);
        }
        if(tstar==10){
            component.set('v.tstar10',true);
        }
         if(tstar==9){
            component.set('v.tstar9',true);
        }
         if(tstar==8){
            component.set('v.tstar8',true);
        }
         if(tstar==7){
            component.set('v.tstar7',true);
        }
         if(tstar==6){
            component.set('v.tstar6',true);
        }
        if(tstar==5){
            component.set('v.tstar5',true);
        }
         if(tstar==4){
            tomponent.set('v.tstar4',true);
        }
         if(tstar==3){
            component.set('v.tstar3',true);
        }
         if(tstar==2){
            component.set('v.tstar2',true);
        }
         if(tstar==1){
            component.set('v.tstar1',true);
        }
        if(wstar==10){
            component.set('v.wstar10',true);
        }
         if(wstar==9){
            component.set('v.wstar9',true);
        }
         if(wstar==8){
            component.set('v.tstar8',true);
        }
         if(wstar==7){
            component.set('v.wstar7',true);
        }
         if(wstar==6){
            component.set('v.wstar6',true);
        }
        if(wstar==5){
            component.set('v.wstar5',true);
        }
         if(wstar==4){
            tomponent.set('v.wstar4',true);
        }
         if(wstar==3){
            component.set('v.wstar3',true);
        }
         if(wstar==2){
            component.set('v.wstar2',true);
        }
         if(wstar==1){
            component.set('v.wstar1',true);
        }
       
        component.set('v.detailmode',true);
         component.set("v.isModalOpen", true);
        
    }
})