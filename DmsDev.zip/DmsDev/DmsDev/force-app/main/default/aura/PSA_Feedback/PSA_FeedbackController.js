({
    
    doInit : function(component, event, helper) {
        
        helper.getinvoicelist(component, event); 
        
        
    },
    savefeedback: function(component, event, helper) {  
        try {
            var idFeedback = component.get("v.idFeedback");
            var apointmentVal= document.querySelector('input[name="apointment"]:checked').value;
            var costVal= document.querySelector('input[name="cost"]:checked').value;
            var explainVal= document.querySelector('input[name="explain"]:checked').value;
            var timeVal= document.querySelector('input[name="time"]:checked').value;
            var washVal= document.querySelector('input[name="wash"]:checked').value;
            var recomm = component.find("recommend").get("v.value");
            var action = component.get('c.savefeedbackdetails');
            action.setParams({
                "idFeedback"        :idFeedback,
                'apointmentVal'     :apointmentVal,
                'costVal'           :costVal,
                'explainVal'        :explainVal,
                'timeVal'           :timeVal,
                'washVal'           :washVal,
                'recomm'            :recomm,
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
                    var message='Feedback Details submited successfully';
                    helper.showSuccessToast(component,event,message);
                    component.set("v.isModalOpen", false);
                    var abc =component.get('v.disabled',true)
                    if(abc)
                    {
                        $A.util.addClass('addColor');  
                    }
                    helper.getinvoicelist(component, event); 
                    
                    
                }  
                
            }); 
            $A.enqueueAction(action);
        }
        catch (e) {
            var message= 'Please Provide Feedback for all';
            helper.showErrorToast(component,event,message);
            
        }
    },
    openmodal :function(component, event, helper) {  
        debugger;
        component.set("v.isModalOpen", true);
        component.set("v.feed","");
        component.set('v.detailmode', false);
        var target = event.getSource().get('v.value');
        component.set("v.idFeedback",target);
        try {
            var radiobtn = document.getElementById("astar1");
            radiobtn.checked = true;
            
        }
        catch (e) {
            //alert(e);
        }
    },
    opendetailrecord :function(component, event, helper) { 
        component.set('v.detailmode', true);
        var target = event.getSource().get('v.value');
        var action = component.get('c.getfeedbackdetailrecord');
        action.setParams({
            "feedbackid"        :target,
            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                
                helper.opendetailrecord(component, event, records);
                
            }
        });
        $A.enqueueAction(action);
        
    },
    
    closeInsurance :function(component, event, helper) {
        component.set("v.isModalOpen", false);
        component.set("v.feed","");
        component.set('v.astar1',false);
        component.set('v.astar2',false);
        component.set('v.astar3',false);
        component.set('v.astar4',false);
        component.set('v.astar5',false);
        component.set('v.astar6',false);
        component.set('v.astar7',false);
        component.set('v.astar8',false);
        component.set('v.astar9',false);
        component.set('v.astar10',false);
        component.set('v.cstar1',false);
        component.set('v.cstar2',false);
        component.set('v.cstar3',false);
        component.set('v.cstar4',false);
        component.set('v.cstar5',false);
        component.set('v.cstar6',false);
        component.set('v.cstar7',false);
        component.set('v.cstar8',false);
        component.set('v.cstar9',false);
        component.set('v.cstar10',false);
        component.set('v.estar1',false);
        component.set('v.estar2',false);
        component.set('v.estar3',false);
        component.set('v.estar4',false);
        component.set('v.estar5',false);
        component.set('v.estar6',false);
        component.set('v.estar7',false);
        component.set('v.estar8',false);
        component.set('v.estar9',false);
        component.set('v.estar10',false);
        component.set('v.wstar1',false);
        component.set('v.wstar2',false);
        component.set('v.wstar3',false);
        component.set('v.wstar4',false);
        component.set('v.wstar5',false);
        component.set('v.wstar6',false);
        component.set('v.wtar7',false);
        component.set('v.wstar8',false);
        component.set('v.wstar9',false);
        component.set('v.wstar10',false);
        component.set('v.tstar1',false);
        component.set('v.tstar2',false);
        component.set('v.tstar3',false);
        component.set('v.tstar4',false);
        component.set('v.tstar5',false);
        component.set('v.tstar6',false);
        component.set('v.tstar7',false);
        component.set('v.tstar8',false);
        component.set('v.tstar9',false);
        component.set('v.tstar10',false);
        
    },
    
    next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var receiptslist = component.get("v.receipts");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var receiptslist = component.get("v.receipts");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
        /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var accountList = component.get("v.receipts");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    repairorderView : function(component, event, helper) {
        debugger;
        var target = event.getSource().get('v.value');
        var repairEvent = component.getEvent("RepairOrderIdFeedback");
        repairEvent.setParams({"Id" : target });
        repairEvent.fire();
        
    },  
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.getinvoicelist(component, event);
    },
    partsearch: function(component, event, helper) { 
        
        console.log("" + event.getSource().get("v.value"));
        var pot = event.getSource().get("v.value") == undefined ? "" : event.getSource().get("v.value");   
        if(pot == null || pot == 'undefined' || pot==""){
            helper.getinvoicelist(component, event, helper);     
        }
        else
        {
            //alert(component.get("v.selectedsearchfieldvalue"));
            var action = component.get('c.searchfeedback');
            action.setParams({          
                'ordernumber' : pot,
                'selectedfield' : component.get("v.selectedsearchfieldvalue")
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(""+state);
                if(state == 'SUCCESS') {               
                    var records =response.getReturnValue();
                    component.set("v.paginationList", records);   
                    if(response.getReturnValue().length==0){
                        component.set('v.norecords', true);
                    }	else{
                        component.set('v.norecords', false);
                    }
                }
            });
            $A.enqueueAction(action); 
        }
    }
})