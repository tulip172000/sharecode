({
    doInit : function(component, event, helper) {
        var checkRo=component.get('v.checkingRoStatus');
        if(checkRo)
        {
           component.find('remarksid').set("v.disabled", true); 
           component.find('issuebtn').set("v.disabled", true);
           component.find('generatepicklistbtn').set("v.disabled", true);
        }
        helper.getcasenumbersfunc(component, event);
    },
    
    requisitionchange : function(component, event, helper){
        var cid = component.find("requisitionId").get("v.value");
        helper.getwolineitemsfunc(component, event, cid);
    },
    
    Issueparts : function(component,event,helper){ 
        component.set('v.validationcheck', true);
        if(helper.validatepartsconsumablesForm(component, event, helper)){
          
            var childCmp = component.find("partsconsumablesrows");
            if(childCmp.length == undefined){
                component.find("partsconsumablesrows").saverecords();
            }
            if(childCmp.length){
                for(var i=0; i<childCmp.length; i++){
                  
                    childCmp[i].saverecords();
                } 
            }
            
            var isvalid=component.get('v.validationcheck');
            if(isvalid)
            {              
            	helper.Savepartsconsumablesrecords(component,event);  
            }
            else
            {
                component.set("v.Finalpartsconsumables",[]);
            }
        }
    },
    
    Partsconsumablesmerge:function(component,event,helper){
        var singlebinlist = event.getParam("ordlist");
        var bool = event.getParam("listPage");
        if(component.get('v.validationcheck')){
            component.set('v.validationcheck', bool);
        }
        if(component.get("v.Finalpartsconsumables").length > 0){
            var arr = [];
            var existingrecord = component.get("v.Finalpartsconsumables");
            for(var i=0; i<existingrecord.length; i++){
                arr.push(existingrecord[i]);
            }
            arr.push(singlebinlist[0]);
            component.set("v.Finalpartsconsumables", arr);
        }
        else{
            component.set("v.Finalpartsconsumables", singlebinlist);
        }
        
        
    },
    
    picklistpdf : function(component, event, helper) {
        var workorderId = component.get("v.repairOrderId");
        var action = component.get("c.getWorkorderlineitems");
        
        action.setParams({
            "workordid" : workorderId  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                for(var i = 0; i < storeResponse.length; i++){
                    lineid =storeResponse[0].Id;
                    
                }
                var pdfurl ='../PSA_Picklist_Invoicepdf?id='+lineid;
                window.open(pdfurl,"_blank", "width=600, height=550"); 
             
            }
        });
        $A.enqueueAction(action);       
    },
    
    openpdf : function(component, event, helper) {
        debugger;
        var cid = component.find("requisitionId").get("v.value"); 
        var action = component.get("c.getpartreq");
        
        action.setParams({
            "caseid" : cid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                for(var i = 0; i < storeResponse.length; i++){
                    lineid =storeResponse[0].Id;
                    //alert(lineid);
                    
                }
                var pdfurl ='../testpicklist?id='+lineid;
                window.open(pdfurl,"_blank", "width=600, height=550"); 
                
            }
        });
        $A.enqueueAction(action);
    },
    
    openpdfwithcaseno : function(component, event, helper) {
        debugger;
        var cid = component.find("requisitionId").get("v.value"); 
       
        var action = component.get("c.getcaseno");
        
        action.setParams({
            "caseid" : cid  
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var lineid =''
                var storeResponse = response.getReturnValue();
                
                lineid =storeResponse.Id;
               
                
                var pdfurl ='../picklistwithcaseno?id='+lineid;
                window.open(pdfurl,"_blank", "width=600, height=550"); 
                
            }
        });
        $A.enqueueAction(action);
    },
    
    hiderequiredfields : function(component, event, helper) {
        var remarks = component.find("remarksid").get("v.value");
        if(remarks != null || remarks != undefined){
            component.set("v.remarksErrmsg",'');  
            $A.util.removeClass(remarks,"disp-block");
            $A.util.addClass(remarks,"disp-none");
        }        
    }
    
})