({
    doInit : function(component, event, helper) { 
        var query='select id,Name,PSA_GSTIN__c,DMS_Customer_ID__c,PSA_VIN_Number__c,PSA_Customer_Segment__c,PSA_Customer_Id__c,Address_line1__pc,BillingCity,BillingState FROM Account where Name LIKE: searchKey and RecordTypeId=';
        var segment='PCA Customer';//
        var recordtypeid = $A.get("$Label.c.PSA_Customer_RecordType");
        var newString = '\''+ recordtypeid + '\'';   
        query+=newString+' AND PSA_Customer_Segment__c=';
        var segmentstring='\''+ segment + '\'';
        query+= segmentstring+' order by createdDate DESC limit 5';
        component.set('v.customquery',query);      
        helper.codelarquery(component,event);
        helper.delearinfo(component,event);
        
    },  
    segmentchange : function(component, event, helper) {
        var query='select id,Name,PSA_GSTIN__c,DMS_Customer_ID__c,PSA_VIN_Number__c,PSA_Customer_Segment__c,PSA_Customer_Id__c,Address_line1__pc,BillingCity,BillingState FROM Account where Name LIKE: searchKey and RecordTypeId=';
        var segment=component.find('segment').get('v.value');
        var recordtypeid = $A.get("$Label.c.PSA_Customer_RecordType");
        var newString = '\''+ recordtypeid + '\'';   
        query+=newString+' AND PSA_Customer_Segment__c=';
        var segmentstring='\''+ segment + '\'';
        query+= segmentstring+' order by createdDate DESC limit 5';
        component.set('v.customquery',query);   
        
    },
    changeremarks : function(component, event, helper) {
        component.set('v.rerarkserrmsg','');
    },
    
    recordChanges : function(component, event, helper) {
        component.set('v.withinstate',false);
        var selectedrec=component.get("v.selectedLookUpRecord");
        var customername=selectedrec.Name;
        var OTCcustomerid = selectedrec.Id;
        var customerid = selectedrec.DMS_Customer_ID__c;
        var Billingstate = selectedrec.BillingState;
        var dealerstate = component.get('v.dealerstate');
        var customercity=selectedrec.Address_line1__pc;
        var GstNum =selectedrec.PSA_GSTIN__c;
        var segment =selectedrec.PSA_Customer_Segment__c;
        var vinnum =selectedrec.PSA_VIN_Number__c;
        var location=selectedrec.BillingCity;
        if(Billingstate==dealerstate){
            component.set('v.withinstate',true);
        }
        if(customername =='undefined' || customername =='' || customername == null) 
        { 
            component.set("v.customerid",'');
            component.set("v.customeraddress",'');
            component.set("v.GSTNumber",'');
            component.set("v.segment",'');
            component.set("v.vinnumber",'');
            component.set("v.Parttableshow",false);
            component.set("v.codealerpo",true);
            component.set("v.totalTax", 0);
            component.set("v.totalInvoiceValue", 0);
            component.set("v.totalDiscountValue", 0);
            component.set("v.rerarkserrmsg",'');
            component.set('v.sbmitdisable',false);
            component.set('v.printinvoice',true);
            component.set('v.genetareinvoice',true);
            component.find("refdocnum").set("v.value",'');
            component.find("disperc").set("v.value",'');
            component.find("disperc").set("v.value",'');
            component.find("potype").set("v.value",'');
            component.find("remarks").set("v.value",'');
            component.set('v.Invoicenumber','');
            component.find("othercharges").set("v.value",'');
            component.find("dicountauthorized").set("v.value",'');
            component.find("store").set("v.value",'');
            component.set('v.Invoicedate','');
            component.set('v.totalBasicValue','');
            component.find("partexecutive").set("v.value",'');
            var selllist=component.get('v.PartsSelListEdit');
            for(var i=selllist.length; i>0; i--){
                selllist.splice(0, 1);
            }
            
            component.set('v.PartsSelListEdit',selllist);
        }
        else{
            component.set("v.customerErrorMsg",'');
            component.find("store").set("v.value",location);
            component.set("v.OTCcustomerid",OTCcustomerid);
            component.set("v.customerid",customerid);
            component.set("v.customeraddress",customercity);
            component.set("v.GSTNumber",GstNum);
            component.set("v.segment",segment);
            component.set("v.vinnumber",vinnum);
            component.set("v.Parttableshow",true);
            component.set("v.codealerpo",false);
            helper.createObjectData(component,event);
        }
    },    
    
    recordChangesco : function(component, event, helper) {
        var selectedrec=component.get("v.selectedLookUpRecord1");
        component.set('v.withinstate',false);
        var codealerord=selectedrec.OrderNumber;
        
        if(codealerord =='undefined' || codealerord =='' || codealerord == null) 
        { 
            
            component.set("v.customername",true);
            component.set("v.customerid",'');
            component.set("v.customeraddress",'');
            component.set("v.GSTNumber",'');
            component.set("v.segment",'');
            component.set("v.vinnumber",'');
            component.set("v.Parttableshow",false);
            component.set("v.customerpo",true);
            component.set("v.totalBasicValue", '');
            component.set("v.totalTax", '');
            component.set("v.totalDiscountValue", '');
            component.set("v.totalInvoiceValue", '');
            component.set('v.sbmitdisable',false);
            component.find("potype").set("v.value",'');
            component.set('v.printinvoice',true);
            component.find("refdocnum").set("v.value",'');
            component.set('v.Invoicenumber','');
            component.set('v.Invoicedate','');
            component.find("remarks").set("v.value",'');
            component.set('v.totalBasicValue','');
            component.find("disperc").set("v.value",'');
            component.find("othercharges").set("v.value",'');
            component.find("dicountauthorized").set("v.value",'');
            component.find("partexecutive").set("v.value",'');
            component.find("store").set("v.value",'');
        }
        else{
            var location=selectedrec.Account.BillingCity;
            var dealername=selectedrec.Account.Name;
            var orderlist=selectedrec.OrderItems;
            component.set('v.customerid',selectedrec.PSA_Co_Dealer__r.Dealer_Code__c);
            component.set('v.GSTNumber',selectedrec.PSA_Co_Dealer__r.PSA_TaxNumber__c);
            component.set('v.codeapartsList',orderlist);
            helper.currentstockvalue(component,event,orderlist,location,dealername);
            var billingstate=selectedrec.PSA_Co_Dealer__r.BillingState;
            var dealerstate = component.get('v.dealerstate');
            if(billingstate==dealerstate){
                component.set('v.withinstate',true);
            }
            
        }
        
    },
    addNewRow: function(component, event, helper) {
        helper.createObjectData(component, event);
    },
    removeDeletedRow: function(component, event, helper) {
        var partnumber = event.getParam("partnumb");
        var index = event.getParam("indexVar");
        var AllRowsList = component.get("v.PartsSelListEdit");
        AllRowsList.splice(index, 1);
        component.set("v.PartsSelListEdit", AllRowsList);
        var cleaeindex=0;
        var x;
        for(x in AllRowsList){
            
            if(AllRowsList[x].Product2Id==partnumber){
                AllRowsList.splice(cleaeindex, 1);
            }
            cleaeindex++;
            
            
        }
        component.set("v.PartsSelListEdit", AllRowsList);
        if(AllRowsList.length==0){
            helper.createObjectData(component, event);  
        }
    },
    clearsamepartRow: function(component, event, helper) {
        var partnumber = event.getParam("partnumb");
        var AllRowsList = component.get("v.PartsSelListEdit");
        var cleaeindex=0;
        var x;
        for(x in AllRowsList){
            
            if(AllRowsList[x].Product2Id==partnumber){
                AllRowsList.splice(cleaeindex, 1);
            }
            cleaeindex++;
            
            
        }
        component.set("v.PartsSelListEdit", AllRowsList);
        if(AllRowsList.length==0){
            helper.createObjectData(component, event);  
        }
    },
    
    otcSave: function(component, event, helper) {
        debugger;
        var PartsSelListEdit = component.get("v.PartsSelListEdit");
        var isvalid=true;
        var childCmp = component.find("Otcsalesorderchild");
        if(childCmp.length){
            for(var i=0;i<childCmp.length;i++)
                isvalid=childCmp[i].checkValidationparts();}
        else
            isvalid=childCmp.checkValidationparts();
        
        if (helper.validateRequired(component, event)&& isvalid) {
            
            var referencedocnum = component.find("refdocnum").get("v.value");
            var segment = component.find("segment").get("v.value");    
            var partex = component.find("partexecutive").get("v.value");
            var discountauth = component.find("dicountauthorized").get("v.value");
            var otccustomer = component.get("v.OTCcustomerid");  
            var remarks = component.find("remarks").get("v.value");
            var Basicvalue=component.get('v.totalBasicValue');
            var taxvalue=component.get('v.totalTax');
            var discVal=component.get('v.totalDiscountValue');
            var totalvalue=component.get('v.totalInvoiceValue');
            Basicvalue=parseInt(Basicvalue)-parseInt(discVal);
            
            var action = component.get("c.saveOtcOrder");       
            action.setParams({
                "ListlocalItem" : component.get('v.PartsSelListEdit'),
                "recTypeid" :'OTC_Sale_Order',
                "otccust":otccustomer,
                "refdoc": referencedocnum,
                "partexecutive":partex,
                "discountauth":discountauth,
                "remarks":remarks,
                "taxablevalue" :Basicvalue,
                "taxamount" : taxvalue,
                "totalamount" : totalvalue,
                "discVal":discVal
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    helper.showSuccessToast(component,event,"Sales Order Created ");
                    var storeResponse = response.getReturnValue();
                    component.set('v.sbmitdisable',true); 
                    component.set('v.printinvoice',false);
                    component.set('v.genetareinvoice',false);
                    var order=storeResponse[0];
                    var ordid = order.Id;
                    var ordernumb=order.OrderNumber;
                    var invoicedetail=order.Invoice_Details__r;
                    var referencenumber=invoicedetail[0].PSA_Invoiceid__r.Otc_Invoice_Number__c;
                    var invoicedate=invoicedetail[0].PSA_Invoiceid__r.PSA_Invoice_Date__c;
                    component.set("v.OrderId", ordid);
                    component.find("refdocnum").set("v.value",ordernumb);
                    component.set('v.Invoicenumber',referencenumber);
                    component.set('v.Invoicedate',invoicedate);
                    
                }
            });
            $A.enqueueAction(action); 
        }
    },    
    Exit:function(component, event, helper){        
        component.find("partexecutive").set("v.value",''); 
        component.find("dicountauthorized").set("v.value",''); 
        component.find("remarks").set("v.value",'');
        component.find("segment").set("v.value",'PCA Customer');
        component.set("v.totalBasicValue", 0);
        component.set("v.totalTax", 0);
        component.find("potype").set("v.value",'');
        component.set("v.totalInvoiceValue", 0);
        component.set("v.totalDiscountValue", 0);
        component.set('v.Parttableshow',false);
        component.set("v.rerarkserrmsg",'');
        component.set('v.sbmitdisable',false);
        component.set('v.printinvoice',true);
        component.set('v.genetareinvoice',true);
        component.find("refdocnum").set("v.value",'');
        component.set('v.Invoicenumber','');
        component.find("disperc").set("v.value",'');
        component.find("othercharges").set("v.value",'');
        component.find("store").set("v.value",'');
        component.find("dicountauthorized").set("v.value",'');
        component.find("partexecutive").set("v.value",'');
        component.find("invdate").set("v.value",'');
        var selllist=component.get('v.PartsSelListEdit');
        
        for(var i=selllist.length; i>0; i--){
            selllist.splice(0, 1);
        }
        component.set('v.PartsSelListEdit',selllist);
        
        if(component.get('v.codealerpo')){
            component.set('v.customerpo',true);
            var childCmp = component.find("ponumber");
            childCmp.clearpill(); 
        }else{
            var childCmp1 = component.find("customername");
            childCmp1.clearpill();
        }
        
        
        
    },
    
    triggerCalc:function(component, event, helper){
        var PartsSelListEdit = component.get("v.PartsSelListEdit");
        var i;
        var totalBasicValue = 0;
        var totalTax = 0;
        var totalDiscountValue = 0;
        var totalInvoiceValue = 0;
        for(i in PartsSelListEdit)
        {
            var rec = PartsSelListEdit[i];
            totalBasicValue = rec.totalBasicValue+totalBasicValue;
            totalTax = rec.totalTax+totalTax;
            totalDiscountValue = rec.totalDiscountValue+totalDiscountValue;
            totalInvoiceValue = rec.totalInvoiceValue+totalInvoiceValue;
        }
        component.set("v.totalBasicValue", totalBasicValue);
        component.set("v.totalTax", totalTax);
        component.set("v.totalDiscountValue", totalDiscountValue);
        component.set("v.totalInvoiceValue", totalInvoiceValue);
    },
    triggerCodealer:function(component, event, helper){
        var PartsSelListEdit = component.get("v.codeapartsList");
        var i;
        var totalBasicValue = 0;
        var totalTax = 0;
        var totalDiscountValue = 0;
        var totalInvoiceValue = 0;
        for(i in PartsSelListEdit)
        {
            var rec = PartsSelListEdit[i];
            totalBasicValue = rec.totalBasicValue+totalBasicValue;
            totalTax = rec.totalTax+totalTax;
            totalInvoiceValue = rec.totalInvoiceValue+totalInvoiceValue;
            if(rec.totalDiscountValue==null ||rec.totalDiscountValue=='undefined')
            {
                rec.totalDiscountValue=0;
            }
            totalDiscountValue = rec.totalDiscountValue+totalDiscountValue;
        }
        component.set("v.totalBasicValue", totalBasicValue);
        component.set("v.totalTax", totalTax);
        component.set("v.totalInvoiceValue", totalInvoiceValue);
        component.set("v.totalDiscountValue", totalDiscountValue);
    },
    CoDealerSave: function(component, event, helper) {
        var Isvalid=true;
        var finalvalidity=true;
        var childCmp = component.find("codealerotc");
        var remarksvalue = component.find("remarks").get("v.value");
        
        if(childCmp.length){
            for(var i=0; i<childCmp.length; i++){
                Isvalid=childCmp[i].checkValidation();
                if(!Isvalid)
                    finalvalidity=false;
            }
            
        } else{
            Isvalid=childCmp.checkValidation();
        }
        component.set("v.rerarkserrmsg",'');
        $A.util.removeClass(remarksvalue,"disp-block");
        $A.util.addClass(remarksvalue,"disp-none");
        if(remarksvalue =='' || remarksvalue=='undefined' || remarksvalue==null){ 
            component.set("v.rerarkserrmsg",'This Required field');
            $A.util.removeClass(remarksvalue,"disp-none");
            $A.util.addClass(remarksvalue,"disp-block");
            Isvalid=false;
        }
        var Parts = component.get("v.codeapartsList");
        var x;
        var qaavialble=false;
        for(x in Parts){
            var qun=Parts[x].PSA_Allocated_Qty__c;
            if(qun=='' || qun==null || qun=='indefined'){
                
            }else{
                qaavialble=true;  
            }
            
        }
        if(!qaavialble){
            Isvalid=false;
            helper.showErrorToast(component,event,'please give invoice quantity at least one part');
        }
        
        
        if(finalvalidity && Isvalid) {
            helper.codealerotcsave(component, event);
        }
    },
    printinvoice : function(component, event, helper) {
        debugger;
        var Orderid = component.get("v.OrderId");  
        var action = component.get("c.updateitems");       
        action.setParams({
            "otcorderid" :Orderid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var pdfurl ='../PSA_OTCSaleCustomerInvoice?Id='+Orderid;
                window.open(pdfurl,"_blank","width=600, height=550"); 
                component.set('v.printinvoice',true);
                
            }
        });
        $A.enqueueAction(action);
        
    },
    dicchange : function(component, event, helper) {
        var dicpers=component.find('disperc').get('v.value');
        var otherchanges=component.find('othercharges').get('v.value');
        if(otherchanges<0 ){
            component.find('othercharges').set('v.value','');
            helper.showErrorToast(component,event,'Descount percentage is greater than Zero Only');
        }
        if(dicpers<0 ){
            component.find('disperc').set('v.value','');
            helper.showErrorToast(component,event,'Descount percentage  is greater than Zero only');
        }
        
    }
    
})