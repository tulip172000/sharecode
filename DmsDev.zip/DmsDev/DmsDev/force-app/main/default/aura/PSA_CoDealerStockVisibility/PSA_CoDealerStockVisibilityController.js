({
        doInit : function(component, event, helper) {
        helper.getCustomDealerCodes(component,event);
        helper.getCustomDealerNames(component,event);
    },
    Apply : function(component, event, helper) {
		component.set('v.submitdisable',true);
        var selectedrec=component.get("v.selectedPartRecord");
        var partNumVar=selectedrec.PSA_Product_Part_Number__c;
        var isdealername= component.get('v.dealernameFlag');
        if(isdealername)
        {
         var selectedrec=component.get("v.selectedDealerName");
         var dealerCodeVar=selectedrec.Dealer_Code__c;
        }
        else
        {
         var selectedrec=component.get("v.selectedDealerCode");
         var dealerCodeVar=selectedrec.Dealer_Code__c;
        }
        var action = component.get("c.fetchSearchDetails");
               action.setParams({ 
                "dealerCode" : dealerCodeVar,
                "partNumber" : partNumVar
               });
                action.setCallback(this, function (response) {
                var state = response.getState();
                var storeResponse = response.getReturnValue();
                if (state === "SUCCESS") {
				component.set('v.dealerInventory',storeResponse);
                var pageSize = component.get("v.pageSize");
               // component.set("v.dealerInventory", records);
                component.set("v.totalSize", component.get("v.dealerInventory").length);
                    component.set("v.start",0);
                    component.set("v.end",pageSize-1);
                    var paginationList = [];
                    if(response.getReturnValue().length < pageSize){
                        paginationList=response.getReturnValue();
                    }
                    else{
                        for(var i=0; i< pageSize; i++){
                            paginationList.push(response.getReturnValue()[i]); 
                        } 
                    } component.set('v.paginationList', paginationList);
                    helper.helperMethodPagination(component, event, '1');
                   
                }
            });
            $A.enqueueAction(action);
            },
    onPartChange : function(component, event, helper){
    var selectedrec=component.get("v.selectedPartRecord");
    var partNumber=selectedrec.PSA_Product_Part_Number__c;
        if(partNumber==null || partNumber== '' || partNumber== 'undefined'){
            var isdealername= component.get('v.dealernameFlag');
            var isdealercode= component.get('v.dealercodeFlag');
            component.set('v.submitdisable',true);
            component.set('v.dealerInventory',null);
            if(isdealercode)
            {
                var dealer=component.find('dealercode');
                dealer.clearpill();
            }
            else
            {
                 var name=component.find('dealername');
                 name.clearpill();
                 component.set('v.dealercodeFlag',true);
            }
          
            component.set('v.dealernameFlag',true);
            component.set('v.dealercodeFlag',true);
        }
        else
        {
            component.set('v.submitdisable',false);
        }
    },
    onDealerCodeChange : function(component, event, helper){
       var selectedrec=component.get("v.selectedPartRecord");
       var partNumber=selectedrec.PSA_Product_Part_Number__c;
       component.set('v.dealernameFlag',false);
        if(component.get("v.selectedDealerCode.Name") == null || component.get("v.selectedDealerCode.Name") == undefined){
      		component.set('v.dealernameFlag',true);
            component.set('v.dealerInventory',null);
            if(partNumber!=null && partNumber!= '' && partNumber!= 'undefined')
            {
                component.set('v.submitdisable',false);
            }
        }
        else if((partNumber!=null && partNumber!= '' && partNumber!= 'undefined') && (component.get("v.selectedDealerCode.Name") != null || component.get("v.selectedDealerCode.Name") != undefined))
        {
            component.set('v.submitdisable',false);
        }
    },
    onDealerNameChange : function(component, event, helper){
       var selectedrec=component.get("v.selectedPartRecord");
       var partNumber=selectedrec.PSA_Product_Part_Number__c;
      component.set('v.dealercodeFlag',false); 
        if(component.get("v.selectedDealerName.Dealer_Code__c") == null || component.get("v.selectedDealerName.Dealer_Code__c") == undefined){
      		component.set('v.dealercodeFlag',true);
            component.set('v.dealerInventory',null);
           if(partNumber!=null && partNumber!= '' && partNumber!= 'undefined')
            {
                component.set('v.submitdisable',false);
            }
        }
        else if((partNumber!=null && partNumber!= '' && partNumber!= 'undefined') && (component.get("v.selectedDealerName.Dealer_Code__c") != null || component.get("v.selectedDealerName.Dealer_Code__c") != undefined))
        {
            component.set('v.submitdisable',false);
        }

    },
         next : function(component, event, helper)
    { /*---Pagination Next Button Click--*/
        var receiptslist = component.get("v.dealerInventory");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var receiptslist = component.get("v.dealerInventory");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = receiptslist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.helperMethodPagination(component, event, parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
         /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var pageSize = component.get("v.pageSize");
        var accountList = component.get("v.dealerInventory");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.helperMethodPagination(component, event, parseInt(pagenum));//Reset Pagination
    },
    
    setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        this.Apply(component, event);
    },

})