({
      helperMethodPagination : function(component, event, pageNumber){
    
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.dealerInventory").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
        if(pageNumber<7){
            for(var i=1; i<= totalpage; i++){
                paginationPageNumb.push(i);
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
            }
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
                paginationPageNumb.push(i);
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    
    },
    getCustomDealerCodes : function(component,event)
    { 
        var query='select Dealer_Code__c,Name from Account where Dealer_Code__c!=null and Name!=null ';
        query+=' AND RecordTypeId=';
        var action = component.get("c.getDealerRecordTypeID");
           action.setCallback(this, function(response){
                var state = response.getState();
                var recordtypeid = response.getReturnValue();
                if (state === "SUCCESS") {
                var newString = '\''+ recordtypeid + '\'';   
                query+=newString+' AND Dealer_Code__c LIKE: searchKey order by createdDate DESC limit 5';
                component.set('v.customquerydealerCode',query);                }
            });
            $A.enqueueAction(action);
    },
        getCustomDealerNames : function(component,event)
    { 
        var query='select Dealer_Code__c,Name from Account where Dealer_Code__c!=null and Name!=null ';
        query+=' AND RecordTypeId=';
        var action = component.get("c.getDealerRecordTypeID");
           action.setCallback(this, function(response){
                var state = response.getState();
                var recordtypeid = response.getReturnValue();
                if (state === "SUCCESS") {
                var newString = '\''+ recordtypeid + '\'';   
                query+=newString+' AND Name LIKE: searchKey order by createdDate DESC limit 5';
                component.set('v.customquerydealerName',query);                }
            });
            $A.enqueueAction(action);
    }


})