({
    vehicledata: function(component, event) {
        debugger;
        var pageSize = component.get("v.pageSize");
        var action = component.get('c.fetchvehiclerecord');
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                //   console.log(" Records **** "+JSON.stringify(records));
                component.set("v.objectiveReclist", records);
                component.set("v.totalSize", component.get("v.objectiveReclist").length);
                component.set("v.start",0);
                component.set("v.end",pageSize-1);
                var paginationList = [];
                if(response.getReturnValue().length < pageSize){
                    paginationList=response.getReturnValue();
                }
                else{
                    for(var i=0; i< pageSize; i++){
                        paginationList.push(response.getReturnValue()[i]); 
                    } 
                }
                
                component.set('v.paginationList', paginationList);
                if(response.getReturnValue().length==0){
                    component.set('v.norecords', true);
                }
                this.Pagination(component, event,'1');
                component.set("v.spinner", false);
            }
        });
        $A.enqueueAction(action);
    },
    updateinv :function(component, event){
        debugger;
        var x;
        var isvalid= component.get('v.isvalid');
        var pageSize = component.get("v.pageSize");     
        var  paginat=component.get("v.paginationList");
        var updatedlist=component.get("v.updatedlist");
        //  alert(updatedlist);
        let myMap = new Map();
        if(updatedlist=='undefined' || updatedlist==''|| updatedlist==null){
            
        }else{
            for(x in updatedlist){
                
                myMap.set(updatedlist[x].Id,updatedlist[x]);
            }
        }	
        for(x in paginat){
            myMap.set(paginat[x].Id,paginat[x]);
            
        }
        var mapvalues=[];
        for (let value of myMap.values()) {
            mapvalues.push(value);
            
        }
        //  alert(mapvalues.length);
        
        
        var action = component.get('c.updatevehiclerecord');
        action.setParams({
            //  "vehclelist" : updatedlist,
            "paginationlist" :mapvalues
            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var Message='Records updated Successfully'; 
                this.showSuccessToast(component,event,Message);
                var records =response.getReturnValue();
                this.vehicledata(component, event);
                // component.set('v.paginationlist',records);
            }  
        });
        $A.enqueueAction(action); 
        
    },
    Pagination :function(component, event,pageNumber){
        debugger;
        var pageSize = component.get("v.pageSize");//Number Of Row Per Page
        var totalpage=Math.ceil(component.get("v.objectiveReclist").length/pageSize);//Number Of Total Pages
        var   paginationPageNumb=[];
        var cont=1;
        /*---Pagination Logic Start--*/
        if(pageNumber<=7){ 
            
            for(var i=1; i<= totalpage; i++){
                
                if(cont>7){
                    paginationPageNumb.push('...');
                    paginationPageNumb.push(totalpage);
                    break;
                }
                cont++;
                paginationPageNumb.push(i);
            }
            
        }
        else{
            paginationPageNumb.push('1');
            paginationPageNumb.push('2');
            paginationPageNumb.push('...');
            pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
            for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
                paginationPageNumb.push(i);
                
            }
            paginationPageNumb.push('...');
            paginationPageNumb.push(totalpage);
        }
        component.set('v.paginationPageNumb', null);
        component.set('v.paginationPageNumb', paginationPageNumb);
    },
    getupdatelist :function(component, event,pagelist,updatelist){
        let myMap = new Map();
        var x;
        if(updatelist=='undefined' || updatelist==''|| updatelist==null){
            
        }else{
            for(x in updatelist){
                
                myMap.set(updatelist[x].Id,updatelist[x]);
            }
        }	
        for(x in pagelist){
            myMap.set(pagelist[x].Id,pagelist[x]);
            
        }
        var mapvalues=[];
        for (let value of myMap.values()) {
            mapvalues.push(value);
            
        }
        component.set('v.updatedlist',mapvalues);  
        /*  var action = component.get('c.fetchpaginationlist');
        action.setParams({
            "vehclelist" : pagelist,
            "updlist" :updatelist
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();
                component.set('v.updatedlist',records);
            }  
        });
        $A.enqueueAction(action); */
    },
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
})