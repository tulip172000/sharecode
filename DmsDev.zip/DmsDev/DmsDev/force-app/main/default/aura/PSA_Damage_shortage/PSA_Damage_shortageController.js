({
    doInit : function(component, event, helper) {
        debugger;
        component.set('v.isvalid',false);
      component.set("v.updatedlist",'');
        helper.vehicledata(component, event); 
    },
    Save : function(component, event, helper) { 
        debugger;
        helper.updateinv(component, event);   
    },
    changevalue : function(component, event, helper) { 
        component.set("v.isvalid",true);
        
    },
    next : function(component, event, helper)
    { 
        debugger;
        var isvalid= component.get('v.isvalid');
        var pageSize = component.get("v.pageSize");
        var  paginat=component.get("v.paginationList");
         var updatedlist=component.get("v.updatedlist");
        if(isvalid){
            helper.getupdatelist(component, event,paginat,updatedlist);
        }
        component.set("v.isvalid",false);
        var objectivelist = component.get("v.objectiveReclist");
        var end = component.get("v.end");
        var start = component.get("v.start");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var paginationList = objectivelist.slice(end+1,end+parseInt(pageSize)+1);//Slicing List as page number
        start = start + parseInt(pageSize);
        end = end + parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        var currentPageNumber= component.get('v.currentPageNumber')+1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.Pagination(component, event,parseInt(currentPageNumber));
    },
    previous : function(component, event, helper)
    {
        var isvalid= component.get('v.isvalid');
        var pageSize = component.get("v.pageSize");
        var  paginat=component.get("v.paginationList");
        var updatedlist=component.get("v.updatedlist");
        if(isvalid){
            helper.getupdatelist(component, event,paginat,updatedlist);
        }
        var objectivelist = component.get("v.objectiveReclist");//All Account List
        var end = component.get("v.end");
        var start = component.get("v.start");
        var paginationList = [];
        var paginationList = objectivelist.slice(start-parseInt(pageSize),start);//Slicing List as page number
        start = start - parseInt(pageSize);
        end = end - parseInt(pageSize);
        component.set("v.start",start);
        component.set("v.end",end);
        component.set('v.paginationList', paginationList);
        component.set("v.isvalid",false);
        var currentPageNumber= component.get('v.currentPageNumber')-1;//Current Page Number
        component.set('v.currentPageNumber',currentPageNumber);
        helper.Pagination(component, event,parseInt(currentPageNumber));//Reset Pagination
    },
    currentPage: function(component, event, helper) {
        var isvalid= component.get('v.isvalid');
        var pageSize = component.get("v.pageSize");
        var  paginat=component.get("v.paginationList");
        if(isvalid){
             var updatedlist=component.get("v.updatedlist");
            helper.getupdatelist(component, event,paginat,updatedlist);
        }
        /*---Pagination Number Button Click--*/
        var selectedItem = event.currentTarget;
        var pagenum = selectedItem.dataset.record;//Current Page Number
        var accountList = component.get("v.objectiveReclist");//All Account List
        var start =(pagenum-1)*pageSize;
        var end = ((pagenum-1)*pageSize)+parseInt(pageSize)-1;
        var paginationList = accountList.slice(start,end+1);//Slicing List as page number
        component.set("v.start",start);
        component.set("v.end",end);
        component.set("v.isvalid",false);
        component.set('v.paginationList', paginationList);
        component.set('v.currentPageNumber', parseInt(pagenum));
        helper.Pagination(component, event,parseInt(pagenum));//Reset Pagination
    },
     setrecordsizeperpage: function(component, event, helper){
        var pagesize = component.find("recordperpageselect").get("v.value");
        component.set("v.pageSize",pagesize);
        helper.vehicledata(component, event, helper);
    },
})