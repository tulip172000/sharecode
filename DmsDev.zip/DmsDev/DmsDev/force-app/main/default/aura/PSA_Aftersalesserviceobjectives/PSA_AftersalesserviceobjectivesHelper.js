({
        showObjectivedetails : function(component, event, helper) {
            var pageSize = component.get("v.pageSize");
            var region = component.find("regionName").get("v.value");
            var state = component.find("stateName").get("v.value");  
            var city = component.find("cityname").get("v.value");
            var DealerName = component.find("dealerName").get("v.value");
           // var selectYear = component.find("yearselect").get("v.value");
            var selectYear = component.get("v.yearSelected");
            var action = component.get('c.getObjectives');
            action.setParams({
                "valregion": region,
                "valcity": city,
                "valstate": state,
                "varYear": selectYear,
                "varDealname":DealerName,
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(" State **** "+state);
                if(state == 'SUCCESS') {
                    var records =response.getReturnValue();
                    component.set("v.spinner", false);
                    console.log(" Records **** "+JSON.stringify(records));
                    component.set("v.objectiveReclist", records);
                    component.set("v.totalSize", component.get("v.objectiveReclist").length);
                    component.set("v.start",0);
                    component.set("v.end",pageSize-1);
                    var paginationList = [];
                    if(response.getReturnValue().length < pageSize){
                        paginationList=response.getReturnValue();
                    }
                    else{
                        for(var i=0; i< pageSize; i++){
                            paginationList.push(response.getReturnValue()[i]); 
                        } 
                    }
                    
                    component.set('v.paginationList', paginationList);
                    if(response.getReturnValue().length==0){
                        component.set('v.norecords', true);
                    }
                    this.helperMethodPagination(component, event, helper,'1');
                
                }
            });
            $A.enqueueAction(action);
              component.set("v.spinner", false);
        },
    
    getDealerListonload : function(component, event, helper) {
        debugger;
       component.set("v.spinner", true);
        component.set('v.norecords', false);
        var action = component.get("c.getAccountList");
        
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State dealer load **** "+state);
          //  if(state == 'SUCCESS') {
                var records =response.getReturnValue();  
                console.log('records@@@@@'+records);
                component.set("v.Dealercities", records);
           // }
        });
        $A.enqueueAction(action);
        component.set("v.spinner", false);   
    },
    
        getStatesList : function(component, event, helper) {
         component.set("v.spinner", true);
         component.set('v.norecords', false);
         //component.find("cityname").set("v.value","ALL"); 
         //Empty List - Nancy
         component.set("v.accountCities",[]);
         component.set("v.Dealercities",[]);
        var region = component.find("regionName").get("v.value");
       // if(region != 'ALL'){
        var action = component.get("c.getAccountBillingState");
        
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.accountStates", records);
               
            }
        });
       
        $A.enqueueAction(action);
      
    },
    getCitiesList : function(component, event, helper) {
         component.set("v.spinner", true);
        component.set('v.norecords', false);
        var region = component.find("regionName").get("v.value");
        var state = component.find("stateName").get("v.value");  
        var action = component.get("c.getAccountBillingCity");

        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(" State **** "+state);
            if(state == 'SUCCESS') {
                var records =response.getReturnValue();            
                component.set("v.accountCities", records);
                component.find("dealerName").set("v.value","ALL");
            }
        });
        $A.enqueueAction(action);
       component.set("v.spinner", false);
    },
        getAccountRegionInfo : function(component, event, helper) {
             component.set('v.norecords', false);
            var action = component.get('c.getAccountRegion');
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(" State **** "+state);
                if(state == 'SUCCESS') {
                    var records =response.getReturnValue();            
                    component.set("v.accountRegion", records);
                    
                }
                  this.getDealerListonload(component,event, helper);
                  this.getStatesList(component,event, helper);
                  this.getCitiesList(component,event, helper);
            });
            $A.enqueueAction(action);
        },
        
        getYears : function(component, event, helper)  {
            component.set('v.norecords', false);
            var action = component.get('c.getObjectiveyears');
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log(" State **** "+state);
                if(state == 'SUCCESS') {
                    var records =response.getReturnValue();            
                    component.set("v.yearlist", records);
                    var selectyr = component.find("yearselect").get("v.value");
                    if(selectyr == 'option'){
                         var curryearsel = today.getFullYear();
                    component.set("v.yearSelected", curryearsel);
                }
                    else{
                         component.set("v.yearSelected", selectyr);
                    }
                    alert(selectyr);
                }
            });
            $A.enqueueAction(action);
            
        },
        
        helperMethodPagination :function(component, event, helper,pageNumber){
            debugger;
            var pageSize = component.get("v.pageSize");//Number Of Row Per Page
            var totalpage=Math.ceil(component.get("v.objectiveReclist").length/pageSize);//Number Of Total Pages
            var   paginationPageNumb=[];
            var cont=1;
            /*---Pagination Logic Start--*/
            if(pageNumber<7){
                for(var i=1; i<= totalpage; i++){
                    paginationPageNumb.push(i);
                    if(cont>7){
                        paginationPageNumb.push('...');
                        paginationPageNumb.push(totalpage);
                        break;
                    }
                    cont++;
                }
            }
            else{
                paginationPageNumb.push('1');
                paginationPageNumb.push('2');
                paginationPageNumb.push('...');
                pageNumber=(pageNumber<=0)?2:((pageNumber>=totalpage)? (totalpage-3) :(( pageNumber==totalpage-1 )?(pageNumber = pageNumber-2):( (pageNumber==totalpage-2 ) ? (pageNumber-1):pageNumber ))) ;
                for(var i=pageNumber-2; i<=pageNumber+2 ; i++){
                    paginationPageNumb.push(i);
                }
                paginationPageNumb.push('...');
                paginationPageNumb.push(totalpage);
            }
            component.set('v.paginationPageNumb', null);
            component.set('v.paginationPageNumb', paginationPageNumb);
        }
        
    })