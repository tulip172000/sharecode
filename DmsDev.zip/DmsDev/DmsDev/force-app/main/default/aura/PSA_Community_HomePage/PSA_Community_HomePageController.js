({
	doInit : function(component, event, helper) {
		var psaProfile = component.get("v.psaProfileName");        
		var dmsProfile = component.get("v.dmsProfileName");
        var action = component.get("c.fetchLoginUserDetails");
		helper.getMenuSetUpForUser(component, event, helper);                                        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var userResponse = response.getReturnValue();
                component.set("v.userInfo", userResponse);
                var userProfileName = userResponse.Profile.Name;
                if (psaProfile.includes(userProfileName)) {
                    component.set("v.isPSAProfile", true);
                }
                else if (dmsProfile.includes(userProfileName)) {
                    component.set("v.isDMSProfile", true);
                }
            }
        });
        $A.enqueueAction(action);
	},
    
})