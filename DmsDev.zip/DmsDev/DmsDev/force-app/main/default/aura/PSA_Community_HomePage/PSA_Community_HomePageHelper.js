({
    getMenuSetUpForUser : function(component, event, helper) {
        var getElement = component.get('v.menuItem');     
        var validateMenuEvent = component.getEvent("validateMenu");
        var action = component.get("c.getUserMenuAccess");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var userResponse = response.getReturnValue();
                console.log('Respo---'+response.getReturnValue().length); // By Prashanth
                component.set("v.userMenuAccess", userResponse);
                 console.log('userMenuAccess---'+JSON.stringify(userResponse));
            }else{ // By Prashanth
                alert('Error!!'); // By Prashanth
            } // By Prashanth
        });
        $A.enqueueAction(action);
    },
})