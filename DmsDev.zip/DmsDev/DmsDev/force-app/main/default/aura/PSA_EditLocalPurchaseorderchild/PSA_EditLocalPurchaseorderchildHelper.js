({
    getPartsList : function(component, event, helper) {
        var action=component.get('c.getPartsAssociationrecords');
        action.setParams({
        }); 
        action.setCallback(this, function(response) {
            var responsevalue=response.getReturnValue();
            console.log('Vendor and Parts Wrapper >>>>>>>'+JSON.stringify(responsevalue))
            component.set('v.PartsList',responsevalue);
        });
        $A.enqueueAction(action);
    },
       showError : function(component, event, Message) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "message": Message
        });
        toastEvent.fire();
        component.set("v.spinner", false);
    },
    getPartDetails123 : function(component, event) {
           var partName11 = component.get("v.ProductInstance");
        var partName = partName11.PSA_Part_Number__c;
        component.set("v.selectedPart",partName);
        var action=component.get('c.fetchPartsDetails');
        action.setParams({
            "partId" : component.get("v.selectedPart")
        });
        action.setCallback(this, function(response) {
            var responsevalue=response.getReturnValue();
            console.log('responsevalue'+responsevalue);
            for(var i=0;i<responsevalue.length;i++){
                var partDesc = responsevalue[i].PSA_Local_Parts_Master__r.PSA_Part_Description__c;
                var hsncode=responsevalue[i].PSA_Local_Parts_Master__r.PSA_HSN_Code__c;
                var UOM=responsevalue[i].PSA_Local_Parts_Master__r.PSA_Units__c;
                var partRte = responsevalue[i].PSA_Rate_per_Unit__c;
                var pckQty = responsevalue[i].PSA_Pack_Quantity__c;
                var qty=responsevalue[i].PSA_Quantity_Per_Vehicle__c;
                var stocki =  responsevalue[i].PSA_Local_Stock__c;
                if(stocki == 'undefined'|| stocki == "--None--" || stocki == null)
                     {
                          var stock='-';

                     }
                    else
                    {
                         var stock= responsevalue[i].PSA_Local_Stock__c;

                    }
                var partTx = responsevalue[i].PSA_Tax__c;
                var igstval = responsevalue[i].PSA_IGST__c;
                var cgstval = partName11.PSA_CGST__c;
                var sgstval = responsevalue[i].PSA_SGST__c;
                var cess= responsevalue[i].PSA_CESS__c;
                  var moqi= responsevalue[i].PSA_Minimum_Order_Quantity__c;
                if(moqi == 'undefined'|| moqi == "--None--" || moqi == null)
                     {
                          var moq='-'

                     }
                    else
                    {
                         var moq=responsevalue[i].PSA_Minimum_Order_Quantity__c;

                    }
                          
               // var mul=responsevalue[i].PSA_Multiplication_Factor__c;
               // alert('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'+mul);
                
            }
            
            if(responsevalue.length){
                component.set("v.partDescription", partDesc);
                component.set("v.UOM", UOM);
                component.set("v.HSNCode", hsncode);
                 component.set("v.NetDealerPrice",partRte);
                component.set("v.partRateperUnit", partRte);         
                component.set("v.partTax", partTx);
                component.set("v.IGST", igstval);
                component.set("v.CGST", cgstval);
                component.set("v.SGST", sgstval);
                 component.set("v.CESS", cess);
                component.set("v.AvailableStock", stock);
                component.set("v.VehicleQty",qty);
                //component.set("v.BackOrderQty", "0");
                component.set("v.MinOrderQty", moq);
                component.set("v.PackQty", pckQty);
                component.set("v.Pillclear", partName);
                component.set("v.disVariant", "false");
                component.set("v.Prdname", partName);
                component.set("v.qyvisiable",false);
               // component.set("v.multnfactr",mul);
                
            }
        });
        $A.enqueueAction(action);
    },
    
})