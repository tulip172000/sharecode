({      
    doInit: function(component, event, helper) 
    {
        helper.GstPicklist(component, event, helper) ; 
        
    },
    
    handleSaveVendor: function(component, event, helper) {
        
        if(helper.validateVendorForm(component)) {
            var insuranceName=component.find("insuranceName").get("v.value");
            var primAddress = component.find("primAddress").get("v.value");
            var postalCode = component.find("postalCode").get("v.value");
            var city = component.find("city").get("v.value");
            var country = component.find("country").get("v.value");
            var primaryContact = component.find("primaryContact").get("v.value");
            var defaultFax = component.find("defaultFax").get("v.value");
            var defaultEmail = component.find("defaultEmail").get("v.value");
            var gstClassification = component.find("gstClassification").get("v.value");
            var gstNo = component.find("gstNo").get("v.value");
            var action = component.get("c.saveInsurancemaster"); 
            
            action.setParams({
                "insuranceName"     :insuranceName,
                "primAddress"       :primAddress,
                "postalCode"        :postalCode,
                "city"              :city,
                "country"           :country,
                "primaryContact"    :primaryContact,
                "defaultFax"        :defaultFax,
                "defaultEmail"      :defaultEmail,
                "gstClassification" :gstClassification,
                "gstNo"             :gstNo
            });
            action.setCallback(this, function(response) {
               
                var state=response.getState();
                 
                console.log('save status  >>>>'+state);
                if(state  == "SUCCESS"){
                    var check=response.getReturnValue()
                    if(check)
                    {
                     helper.showErrorToast(component,event,'Insurance Name and GST Number Duplicate Found');   
                    }else
                    {
                    helper.showSuccessToast(component,event,'Insurance Master Saved Successfully');                   
                    var eventListPage = component.getEvent("displayListPageVendors");
                    eventListPage.setParams({"listPage" : true });
                    eventListPage.fire();
                    }
                }
                if(state  == "ERROR"){
                    var toast = $A.get("e.force:showToast");
                    if(toast){
                        toast.setParams({
                            "title": "Error",
                            "message": result.getError()[0].message
                        });
                    }
                    toast.fire();
                } 
                
            });
            $A.enqueueAction(action); 
        }
    },
    oncancel:function(component, event, helper) {
         component.find("insuranceName").set("v.value","");
         component.find("primAddress").set("v.value","");
         component.find("postalCode").set("v.value","");
         component.find("city").set("v.value","");
         component.find("country").set("v.value","");
         component.find("primaryContact").set("v.value","");
         component.find("defaultFax").set("v.value","");
         component.find("defaultEmail").set("v.value","");
         component.find("gstClassification").set("v.value","");
         component.find("gstNo").set("v.value","");
         component.set("v.insuranceNameErrorMsg","");
         component.set("v.gstNoErrorMsg","");
   },
   cancelSaveRecord:function(component, event, helper) 
    {
        
        var eventListPage = component.getEvent("displayListPageVendors");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
    },
     comphonevalidate  : function(component, event, helper) {
        var mobinp = component.find("primaryContact").get("v.value");
      
        if(isNaN(mobinp))
            component.find("primaryContact").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
   validateFax  : function(component, event, helper) {
        var mobinp = component.find("defaultFax").get("v.value");
      
        if(isNaN(mobinp))
            component.find("defaultFax").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
   validatePostal  : function(component, event, helper) {
        var mobinp = component.find("postalCode").get("v.value");
      
        if(isNaN(mobinp))
            component.find("postalCode").set("v.value", mobinp.substring(0, mobinp.length - 1));
    },
    
})