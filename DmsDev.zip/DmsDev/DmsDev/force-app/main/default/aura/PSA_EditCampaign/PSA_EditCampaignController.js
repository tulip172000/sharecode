({
	doInit : function(component, event, helper) {
        var checkUser=component.get("v.checkUser");
        if(checkUser =='Pending for Approval')
        {
          component.set("v.disableAppcmts",false);  
          component.set("v.disableDealcmts",true);  
        }
        else{
          component.set("v.disableAppcmts",true);  
          component.set("v.disableDealcmts",false);  
        }
		helper.CampaignRecord(component, event);
        helper.CampaignRecordList(component, event);
  },
  Save : function(component, event, helper) {
      if(helper.validatePartForm(component, event)) {
      var rid=component.get("v.RecordId");
      var clists=component.get("v.OrderCampaignpartslist");
      var orderList=component.get("v.OrderCampaignList"); 
      var dealerComts=  orderList[0].PSA_Dealer_Remarks__c;
      var action = component.get('c.updateCampain');
        action.setParams({
           "wrapperlist":clists,
           "rid":rid,
            "dealerComts":dealerComts
            });
        action.setCallback(this, function(response){
            var state = response.getState();
            debugger;
            if(state == 'SUCCESS') {
                  helper.showSuccessToast(component,event,"Campaign Order Updated successfully");
                  helper.listPageHelper(component, event);
           
	}
        }); $A.enqueueAction(action);
      }
  }, 
    cancelSaveRecord: function(component, event, helper) {
        helper.listPageHelper(component, event);     
    },
    
	
     /* checkvalidation: function(component, event) {
    
        component.set("v.cnameerrmsg",'');
        var isvalid=true;
        var invlist=  component.get("v.OrderCampaignpartslist");
        var return1=[];
        var errorPush=[];
        var val=[];
        for(var i=0;i<invlist.length;i++){
            
            if(invlist[i].returnquanity==null || invlist[i].returnquanity=='undefined' || parseInt(invlist[i].issuequanity)< invlist[i].returnquanity || invlist[i].returnquanity<0)
                  {
                      return1.push('');
                  }
            
                  else{
                  return1.push(parseInt(invlist[i].issuequanity)- invlist[i].returnquanity);
                  
                  }
                  
            if(parseInt(invlist[i].issuequanity)< invlist[i].returnquanity)
            {
            
             isvalid=false;
             val.push(i);
             errorPush.push('Please enter Return Quantity less than Issued Quantity');
           //  component.set("v.cnameerrmsg","Please enter Return Quantity less than Issued Quantity");
                      
            }
            if(invlist[i].returnquanity==null || invlist[i].returnquanity=='undefined' || invlist[i].returnquanity <0)
            {
                
             isvalid=false;
             val.push(i);
            //component.set("v.cnameerrmsg","Please enter Return Quantity Greater than Zero");
             errorPush.push('Please enter Return Quantity Greater than Zero');
        
            }
            
            } 
          component.set("v.return1",return1);
          component.set("v.val",val);
          component.set("v.cnameerrmsg",errorPush);
          
           return isvalid; 
 },*/

    Reject : function(component, event, helper) {
        var rid=component.get("v.RecordId");
        var orderList=component.get("v.OrderCampaignList"); 
        var dealerComts=  orderList[0].PSA_Approver_Comments__c;
        var action = component.get('c.campainReject');
        action.setParams({
            "rid":rid,
            "dealerComts":dealerComts
            });
        action.setCallback(this, function(response){
            var state = response.getState();
            debugger;
            if(state == 'SUCCESS') {
                  helper.showError(component,event,"Campaign Order Rejected successfully");
                  helper.listPageHelper(component, event);
   }
        }); $A.enqueueAction(action);

		
  },
    Approve : function(component, event, helper) {
      var rid=component.get("v.RecordId");
      var clists=component.get("v.OrderCampaignpartslist");
      var orderList=component.get("v.OrderCampaignList"); 
      var dealerComts=  orderList[0].PSA_Approver_Comments__c;
      var action = component.get('c.campainApprove');
        action.setParams({
            "wrapperlist":clists,
            "rid":rid,
            "dealerComts":dealerComts
            
            });
        action.setCallback(this, function(response){
            var state = response.getState();
            debugger;
            if(state == 'SUCCESS') {
                  helper.showSuccessToast(component,event,"Campaign Order Approved successfully");
                  helper.listPageHelper(component, event);
           
	}
        }); $A.enqueueAction(action);
      
  },
})