({
	CampaignRecord : function(component, event) {
        var rid=component.get("v.RecordId");
        var action = component.get('c.getCampOrderslist');
        action.setParams({
            rid:rid
            });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
              
                var records =response.getReturnValue();
				component.set("v.OrderCampaignList", records); 
                component.set("v.disableSubmit", records[0].PSA_DisableSubmit__c);
                if(records[0].PSA_DisableSubmit__c)
                {
                 component.set("v.disableutility", records[0].PSA_DisableSubmit__c);
                }
                 if(records[0].Status__c=='Approved')
                {
                  component.set("v.disableDealcmts",true);   
                }
	}
        }); $A.enqueueAction(action);
		
	},
    CampaignRecordList : function(component, event) {
        var rid=component.get("v.RecordId");
        var action = component.get('c.getCampRecordslist');
        var return1=[];
        action.setParams({
            rid:rid
            });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == 'SUCCESS') {
             
                var records =response.getReturnValue();
				component.set("v.OrderCampaignpartslist", records);
          }
        }); $A.enqueueAction(action);
		
    },
    listPageHelper : function(component, event){
        var eventListPage = component.getEvent("displayListPageVendors");
        eventListPage.setParams({"listPage" : true });
        eventListPage.fire();
        
    },    
    showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    showError : function(component, event, msg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type": "error",
            "message": msg
        });
        toastEvent.fire();
       
   },
    validatePartForm: function(component, event) {
        var isvalid=true;
        var invlist=  component.get("v.OrderCampaignpartslist");
        for(var i=0;i<invlist.length;i++){
             
            if(parseInt(invlist[i].issuequanity)< invlist[i].returnquanity)
            {
             isvalid=false;
             var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
            "title": "Error",
            "message": "Please enter Return Quantity less than Issued Quantity value",
            "type": "Error"
          });
          toastEvent.fire();  
                       
            }
            if(invlist[i].returnquanity==null || invlist[i].returnquanity=='undefined' || invlist[i].returnquanity<0)
            {
             isvalid=false;
             var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
            "title": "Error",
            "message": "Please enter Return Quantity Greater than or Equal to Zero",
            "type": "Error"
          });
          toastEvent.fire();  
            }
            
       }
       return isvalid;
    
    }
})