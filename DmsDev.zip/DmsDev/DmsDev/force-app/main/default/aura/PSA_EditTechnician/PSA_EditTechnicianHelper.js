({
    validateTachForm : function(component, event, helper){
        
        debugger;
        var isValid = true;
       // var Level = component.find("Level").get("v.value");
        var Title = component.find("Title").get("v.value");
        var Firstname = component.find("Firstname").get("v.value");
        var MobileNo = component.find("MobileNo").get("v.value");
        var Emailid = component.find("Emailid").get("v.value");
        var addressline1 = component.find("addressline1").get("v.value");
        var Team = component.find("techn").get("v.value");
        var Position = component.find("Position").get("v.value");
        var Empid = component.find("Empid").get("v.value");
        var JobTitle = component.find("JobTitle").get("v.value");
        
        
       /* component.set("v.LevelErrmsg",'');
        $A.util.removeClass(Level,"disp-block");
        $A.util.addClass(Level,"disp-none");*/
        component.set("v.TitleErrmsg",'');
        $A.util.removeClass(Title,"disp-block");
        $A.util.addClass(Title,"disp-none");
        component.set("v.FirstnameErrmsg",'');  
        $A.util.removeClass(Firstname,"disp-block");
        $A.util.addClass(Firstname,"disp-none");
        component.set("v.mobilenoErrorMsg",'');
        $A.util.removeClass(MobileNo,"disp-block");
        $A.util.addClass(MobileNo,"disp-none");
        component.set("v.emailErrorMsg",'');
        $A.util.removeClass(Emailid,"disp-block");
        $A.util.addClass(Emailid,"disp-none");
        component.set("v.add1ErrorMsg",' ');
        $A.util.removeClass(addressline1,"disp-block");
        $A.util.addClass(addressline1,"disp-none");
        component.set("v.TeamErrorMsg",'');
        $A.util.removeClass(Team,"disp-block");
        $A.util.addClass(Team,"disp-none");
        component.set("v.PositionErrmsg",'');
        $A.util.removeClass(Position,"disp-block");
        $A.util.addClass(Position,"disp-none");
        component.set("v.EmpIDErrorMsg",'');
        $A.util.removeClass(Empid,"disp-block");
        $A.util.addClass(Empid,"disp-none");
        component.set("v.JobtitleErrorMsg",'');
        $A.util.removeClass(JobTitle,"disp-block");
        $A.util.addClass(JobTitle,"disp-none");
        
        
    /*    if(Level == '--None--'|| Level == '' || Level == null){
            isValid = false;
            component.set("v.LevelErrmsg",'This is a required field');
            $A.util.removeClass(Level,"disp-none");
            $A.util.addClass(Level,"disp-block");
        }*/
        if(Title =='--None--'|| Title == '' || Title == null){
            component.set("v.TitleErrmsg",'This is a required field');
            $A.util.removeClass(Title,"disp-none");
            $A.util.addClass(Title,"disp-block");
            isValid = false;
        }
        if(Firstname =='undefined'|| Firstname == '' || Firstname == null){
            component.set("v.FirstnameErrmsg",'This is a required field');
            $A.util.removeClass(Firstname,"disp-none");
            $A.util.addClass(Firstname,"disp-block");
            isValid = false;
        }
  
        if(MobileNo == 'undefined'|| MobileNo == '' || MobileNo == null){
            component.set("v.mobilenoErrorMsg",'This is a required field');
            $A.util.removeClass(MobileNo,"disp-none");
            $A.util.addClass(MobileNo,"disp-block");
            isValid = false;
        }
        if(Emailid == 'undefined'|| Emailid == '' || Emailid == null){
            component.set("v.emailErrorMsg",'This is a required field');
            $A.util.removeClass(Emailid,"disp-none");
            $A.util.addClass(Emailid,"disp-block");
            isValid = false;
        }
        if(addressline1 == 'undefined'|| addressline1 == '' || addressline1 == null){
            component.set("v.add1ErrorMsg",'This is a required field');
            $A.util.removeClass(addressline1,"disp-none");
            $A.util.addClass(addressline1,"disp-block");
            isValid = false;
        }
        if(Team == '--None--'|| Team == '' || Team == null){
            component.set("v.TeamErrorMsg",'This is a required field');
            $A.util.removeClass(Team,"disp-none");
            $A.util.addClass(Team,"disp-block");
            isValid = false;
        }
        
        if(Position == '--None--'|| Position == '' || Position == null){
            component.set("v.PositionErrmsg",'This is a required field');
            $A.util.removeClass(Position,"disp-none");
            $A.util.addClass(Position,"disp-block");
            isValid = false;
        }
        if(Empid == 'undefined'|| Empid == '' || Empid == null){
            component.set("v.EmpIDErrorMsg",'This is a required field');
            $A.util.removeClass(Empid,"disp-none");
            $A.util.addClass(Empid,"disp-block");
            isValid = false;
        }
        if(JobTitle == '--None--'|| JobTitle == '' || JobTitle == null){
            component.set("v.JobtitleErrorMsg",'This is a required field');
            $A.util.removeClass(JobTitle,"disp-none");
            $A.util.addClass(JobTitle,"disp-block");
            isValid = false;
        }
        
        return isValid;
    },
     showSuccessToast : function(component,event,Message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "message": Message,
            "type": "success"
        });
        toastEvent.fire();  
    },
    
     fetchskillvaluePicklist: function(component, event) {
        var action = component.get("c.fetchskillvaluePicklist");
        action.setCallback(this, function(response) {
        component.set("v.skillposition", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
    fetchteamPicklist: function(component, event) {
        var action = component.get("c.fetchsteamPicklist");
        action.setCallback(this, function(response) {
        component.set("v.teampick", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }, 
    fetchjobtitlePicklist: function(component, event) {
        var action = component.get("c.fetchsjobtitlePicklist");
        action.setCallback(this, function(response) {
        component.set("v.joblist", response.getReturnValue());
    		});
        $A.enqueueAction(action);
     }
     
})